import { pgTable, text, serial, jsonb, timestamp } from "drizzle-orm/pg-core";

export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  cta: string;
  href: string;
  gradient: string;
  image: string;
}

export const settingsTable = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  storeName: text("store_name").notNull().default("ShopEase"),
  logoUrl: text("logo_url"),
  logoIcon: text("logo_icon").notNull().default("ShoppingCart"),
  primaryColor: text("primary_color").notNull().default("#f97316"),
  whatsappNumber: text("whatsapp_number").notNull().default("919876543210"),
  whatsappMessage: text("whatsapp_message").notNull().default("Hi, I need help with my order"),
  supportEmail: text("support_email").notNull().default("support@shopease.com"),
  supportPhone: text("support_phone").notNull().default("+91 98765 43210"),
  storeAddress: text("store_address").notNull().default("Mumbai, India"),
  footerText: text("footer_text").notNull().default("Your trusted online shopping destination"),
  freeDeliveryThreshold: text("free_delivery_threshold").notNull().default("499"),
  deliveryFee: text("delivery_fee").notNull().default("49"),
  offerBarTexts: jsonb("offer_bar_texts").$type<string[]>().notNull().default([
    "Free delivery on orders above Rs.499",
    "Use code WELCOME10 for 10% off your first order",
  ]),
  heroSlides: jsonb("hero_slides").$type<HeroSlide[]>().notNull().default([]),
  homeTagline: text("home_tagline").notNull().default("Shop the best deals across India"),
  secondaryColor: text("secondary_color").notNull().default("#6366f1"),
  footerBg: text("footer_bg").notNull().default("#111827"),
  footerTextColor: text("footer_text_color").notNull().default("#9ca3af"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type SiteSettings = typeof settingsTable.$inferSelect;
