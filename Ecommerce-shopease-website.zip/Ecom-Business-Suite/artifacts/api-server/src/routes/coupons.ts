import { Router, type IRouter } from "express";
import { db, couponsTable } from "@workspace/db";
import { eq, and, gt } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import { ValidateCouponBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/coupons/validate", requireAuth, async (req, res): Promise<void> => {
  const parsed = ValidateCouponBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { code, cartTotal } = parsed.data;

  const [coupon] = await db
    .select()
    .from(couponsTable)
    .where(and(eq(couponsTable.code, code.toUpperCase()), eq(couponsTable.isActive, true)));

  if (!coupon) {
    res.json({ valid: false, discount: 0, discountType: "percentage", message: "Invalid coupon code" });
    return;
  }

  if (coupon.expiresAt && coupon.expiresAt < new Date()) {
    res.json({ valid: false, discount: 0, discountType: "percentage", message: "Coupon has expired" });
    return;
  }

  if (coupon.minOrderValue && cartTotal < parseFloat(coupon.minOrderValue)) {
    res.json({
      valid: false,
      discount: 0,
      discountType: coupon.discountType,
      message: `Minimum order value is Rs.${coupon.minOrderValue}`,
    });
    return;
  }

  let discountAmount = 0;
  if (coupon.discountType === "percentage") {
    discountAmount = (cartTotal * parseFloat(coupon.discount)) / 100;
    if (coupon.maxDiscount) {
      discountAmount = Math.min(discountAmount, parseFloat(coupon.maxDiscount));
    }
  } else {
    discountAmount = parseFloat(coupon.discount);
  }

  res.json({
    valid: true,
    discount: discountAmount,
    discountType: coupon.discountType,
    message: `Coupon applied! You save Rs.${discountAmount.toFixed(2)}`,
  });
});

export default router;
