import { Router, type IRouter } from "express";
import { db, cartItemsTable, productsTable, categoriesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { AddToCartBody, UpdateCartItemBody } from "@workspace/api-zod";

const router: IRouter = Router();

async function getCartData(userId: number) {
  const items = await db
    .select({
      item: cartItemsTable,
      product: productsTable,
      categoryName: categoriesTable.name,
    })
    .from(cartItemsTable)
    .leftJoin(productsTable, eq(cartItemsTable.productId, productsTable.id))
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(cartItemsTable.userId, userId));

  const cartItems = items.map((row) => ({
    id: row.item.id,
    productId: row.item.productId,
    quantity: row.item.quantity,
    price: parseFloat(row.item.price),
    product: {
      id: row.product!.id,
      name: row.product!.name,
      slug: row.product!.slug,
      description: row.product!.description,
      price: parseFloat(row.product!.price),
      originalPrice: row.product!.originalPrice ? parseFloat(row.product!.originalPrice) : null,
      discountPercent: row.product!.discountPercent,
      images: row.product!.images || [],
      categoryId: row.product!.categoryId,
      categoryName: row.categoryName || "",
      rating: parseFloat(row.product!.rating || "0"),
      reviewCount: row.product!.reviewCount || 0,
      stock: row.product!.stock || 0,
      isFeatured: row.product!.isFeatured,
      badge: row.product!.badge,
    },
  }));

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = subtotal > 499 ? 0 : 49;
  const discount = 0;
  const total = subtotal + deliveryFee - discount;

  return {
    items: cartItems,
    subtotal,
    discount,
    deliveryFee,
    total,
    itemCount: cartItems.reduce((sum, item) => sum + item.quantity, 0),
  };
}

router.get("/cart", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const cart = await getCartData(req.user!.id);
  res.json(cart);
});

router.post("/cart/items", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = AddToCartBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { productId, quantity } = parsed.data;
  const userId = req.user!.id;

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const [existing] = await db
    .select()
    .from(cartItemsTable)
    .where(and(eq(cartItemsTable.userId, userId), eq(cartItemsTable.productId, productId)));

  if (existing) {
    await db
      .update(cartItemsTable)
      .set({ quantity: existing.quantity + quantity })
      .where(eq(cartItemsTable.id, existing.id));
  } else {
    await db.insert(cartItemsTable).values({
      userId,
      productId,
      quantity,
      price: product.price,
    });
  }

  const cart = await getCartData(userId);
  res.json(cart);
});

router.put("/cart/items/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const parsed = UpdateCartItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { quantity } = parsed.data;

  if (quantity <= 0) {
    await db.delete(cartItemsTable).where(and(eq(cartItemsTable.id, id), eq(cartItemsTable.userId, req.user!.id)));
  } else {
    await db
      .update(cartItemsTable)
      .set({ quantity })
      .where(and(eq(cartItemsTable.id, id), eq(cartItemsTable.userId, req.user!.id)));
  }

  const cart = await getCartData(req.user!.id);
  res.json(cart);
});

router.delete("/cart/items/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  await db.delete(cartItemsTable).where(and(eq(cartItemsTable.id, id), eq(cartItemsTable.userId, req.user!.id)));

  const cart = await getCartData(req.user!.id);
  res.json(cart);
});

router.delete("/cart/clear", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  await db.delete(cartItemsTable).where(eq(cartItemsTable.userId, req.user!.id));
  res.json({ message: "Cart cleared" });
});

export default router;
