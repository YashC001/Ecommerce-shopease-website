import { Router, type IRouter } from "express";
import { db, productsTable, categoriesTable, reviewsTable } from "@workspace/db";
import { eq, ilike, gte, lte, and, desc, asc, sql, or } from "drizzle-orm";

const router: IRouter = Router();

function buildProduct(p: any, catName: string) {
  return {
    id: p.id,
    name: p.name,
    slug: p.slug,
    description: p.description,
    price: parseFloat(p.price),
    originalPrice: p.originalPrice ? parseFloat(p.originalPrice) : null,
    discountPercent: p.discountPercent,
    images: p.images || [],
    categoryId: p.categoryId,
    categoryName: catName,
    rating: parseFloat(p.rating || "0"),
    reviewCount: p.reviewCount || 0,
    stock: p.stock || 0,
    isFeatured: p.isFeatured,
    badge: p.badge,
  };
}

router.get("/products/featured", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(productsTable.isFeatured, true))
    .limit(10);

  const products = rows.map((r) => buildProduct(r.product, r.categoryName || ""));
  res.json(products);
});

router.get("/products/deals", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(sql`${productsTable.discountPercent} > 0`)
    .orderBy(desc(productsTable.discountPercent))
    .limit(12);

  const products = rows.map((r) => buildProduct(r.product, r.categoryName || ""));
  res.json(products);
});

router.get("/products", async (req, res): Promise<void> => {
  const {
    categoryId,
    search,
    minPrice,
    maxPrice,
    page = "1",
    limit = "20",
    featured,
    sort,
  } = req.query as Record<string, string | undefined>;

  const pageNum = parseInt(page || "1", 10);
  const limitNum = parseInt(limit || "20", 10);
  const offset = (pageNum - 1) * limitNum;

  const conditions = [];

  if (categoryId) {
    conditions.push(eq(productsTable.categoryId, parseInt(categoryId, 10)));
  }

  if (search) {
    conditions.push(
      or(
        ilike(productsTable.name, `%${search}%`),
        ilike(productsTable.description, `%${search}%`)
      )
    );
  }

  if (minPrice) {
    conditions.push(gte(productsTable.price, minPrice));
  }

  if (maxPrice) {
    conditions.push(lte(productsTable.price, maxPrice));
  }

  if (featured === "true") {
    conditions.push(eq(productsTable.isFeatured, true));
  }

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  let orderBy;
  switch (sort) {
    case "price_asc":
      orderBy = asc(productsTable.price);
      break;
    case "price_desc":
      orderBy = desc(productsTable.price);
      break;
    case "rating":
      orderBy = desc(productsTable.rating);
      break;
    case "newest":
      orderBy = desc(productsTable.createdAt);
      break;
    default:
      orderBy = desc(productsTable.createdAt);
  }

  const [countResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(productsTable)
    .where(whereClause);

  const rows = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(whereClause)
    .orderBy(orderBy)
    .limit(limitNum)
    .offset(offset);

  const products = rows.map((r) => buildProduct(r.product, r.categoryName || ""));
  const total = countResult?.count || 0;

  res.json({
    products,
    total,
    page: pageNum,
    limit: limitNum,
    totalPages: Math.ceil(total / limitNum),
  });
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid product id" });
    return;
  }

  const [row] = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(productsTable.id, id));

  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const relatedRows = await db
    .select({
      product: productsTable,
      categoryName: categoriesTable.name,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(and(eq(productsTable.categoryId, row.product.categoryId), sql`${productsTable.id} != ${id}`))
    .limit(6);

  const related = relatedRows.map((r) => buildProduct(r.product, r.categoryName || ""));

  res.json({
    ...buildProduct(row.product, row.categoryName || ""),
    specifications: row.product.specifications || {},
    relatedProducts: related,
  });
});

export default router;
