import { Router, type IRouter } from "express";
import { db, wishlistItemsTable, productsTable, categoriesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { AddToWishlistBody } from "@workspace/api-zod";

const router: IRouter = Router();

async function getWishlistData(userId: number) {
  const rows = await db
    .select({
      item: wishlistItemsTable,
      product: productsTable,
      categoryName: categoriesTable.name,
    })
    .from(wishlistItemsTable)
    .leftJoin(productsTable, eq(wishlistItemsTable.productId, productsTable.id))
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .where(eq(wishlistItemsTable.userId, userId));

  return rows.map((row) => ({
    id: row.item.id,
    productId: row.item.productId,
    addedAt: row.item.createdAt.toISOString(),
    product: {
      id: row.product!.id,
      name: row.product!.name,
      slug: row.product!.slug,
      description: row.product!.description,
      price: parseFloat(row.product!.price),
      originalPrice: row.product!.originalPrice ? parseFloat(row.product!.originalPrice) : null,
      discountPercent: row.product!.discountPercent,
      images: row.product!.images || [],
      categoryId: row.product!.categoryId,
      categoryName: row.categoryName || "",
      rating: parseFloat(row.product!.rating || "0"),
      reviewCount: row.product!.reviewCount || 0,
      stock: row.product!.stock || 0,
      isFeatured: row.product!.isFeatured,
      badge: row.product!.badge,
    },
  }));
}

router.get("/wishlist", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const wishlist = await getWishlistData(req.user!.id);
  res.json(wishlist);
});

router.post("/wishlist/items", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = AddToWishlistBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { productId } = parsed.data;
  const userId = req.user!.id;

  const [existing] = await db
    .select()
    .from(wishlistItemsTable)
    .where(and(eq(wishlistItemsTable.userId, userId), eq(wishlistItemsTable.productId, productId)));

  if (existing) {
    res.json({ id: existing.id, productId, addedAt: existing.createdAt.toISOString() });
    return;
  }

  const [item] = await db
    .insert(wishlistItemsTable)
    .values({ userId, productId })
    .returning();

  res.json({ id: item.id, productId, addedAt: item.createdAt.toISOString() });
});

router.delete("/wishlist/items/:productId", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.productId) ? req.params.productId[0] : req.params.productId;
  const productId = parseInt(rawId, 10);

  await db
    .delete(wishlistItemsTable)
    .where(and(eq(wishlistItemsTable.userId, req.user!.id), eq(wishlistItemsTable.productId, productId)));

  res.json({ message: "Removed from wishlist" });
});

export default router;
