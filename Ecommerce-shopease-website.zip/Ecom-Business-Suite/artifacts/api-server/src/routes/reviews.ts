import { Router, type IRouter } from "express";
import { db, reviewsTable, usersTable, productsTable } from "@workspace/db";
import { eq, avg, count } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { CreateReviewBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/products/:id/reviews", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const reviews = await db
    .select({
      id: reviewsTable.id,
      userId: reviewsTable.userId,
      userName: usersTable.name,
      rating: reviewsTable.rating,
      comment: reviewsTable.comment,
      createdAt: reviewsTable.createdAt,
    })
    .from(reviewsTable)
    .leftJoin(usersTable, eq(reviewsTable.userId, usersTable.id))
    .where(eq(reviewsTable.productId, id))
    .orderBy(reviewsTable.createdAt);

  res.json(reviews.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/products/:id/reviews", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const parsed = CreateReviewBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [review] = await db
    .insert(reviewsTable)
    .values({
      userId: req.user!.id,
      productId: id,
      rating: parsed.data.rating,
      comment: parsed.data.comment,
    })
    .returning();

  const [stats] = await db
    .select({
      avg: avg(reviewsTable.rating),
      cnt: count(reviewsTable.id),
    })
    .from(reviewsTable)
    .where(eq(reviewsTable.productId, id));

  await db
    .update(productsTable)
    .set({
      rating: parseFloat(stats.avg || "0").toFixed(2),
      reviewCount: Number(stats.cnt),
    })
    .where(eq(productsTable.id, id));

  res.json({
    id: review.id,
    userId: review.userId,
    userName: req.user!.name,
    rating: review.rating,
    comment: review.comment,
    createdAt: review.createdAt.toISOString(),
  });
});

export default router;
