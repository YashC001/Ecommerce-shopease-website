import { Router, type IRouter } from "express";
import { db, ordersTable, cartItemsTable, productsTable, addressesTable, couponsTable } from "@workspace/db";
import { eq, and, gt } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { CreateOrderBody, CreatePaymentOrderBody, VerifyPaymentBody } from "@workspace/api-zod";
import { createHmac } from "crypto";

const router: IRouter = Router();

const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || "rzp_test_placeholder";
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || "secret_placeholder";
const STORE_NAME = process.env.STORE_NAME || "ShopEase Store";
const STORE_ADDRESS = process.env.STORE_ADDRESS || "123 Commerce Street, Mumbai - 400001";
const STORE_PHONE = process.env.STORE_PHONE || "+91 9876543210";
const STORE_EMAIL = process.env.STORE_EMAIL || "support@shopease.com";
const STORE_GST = process.env.STORE_GST || "27AABCU9603R1ZX";

function generateOrderNumber(): string {
  return `ORD${Date.now()}${Math.floor(Math.random() * 1000)}`;
}

function formatOrder(order: any) {
  return {
    id: order.id,
    orderNumber: order.orderNumber,
    status: order.status,
    paymentStatus: order.paymentStatus,
    paymentMethod: order.paymentMethod,
    items: order.itemsSnapshot as any[],
    address: order.addressSnapshot as any,
    subtotal: parseFloat(order.subtotal),
    discount: parseFloat(order.discount),
    deliveryFee: parseFloat(order.deliveryFee),
    total: parseFloat(order.total),
    couponCode: order.couponCode,
    razorpayOrderId: order.razorpayOrderId,
    razorpayPaymentId: order.razorpayPaymentId,
    createdAt: order.createdAt.toISOString(),
    estimatedDelivery: order.estimatedDelivery?.toISOString() || null,
  };
}

router.get("/orders", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const orders = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.userId, req.user!.id))
    .orderBy(ordersTable.createdAt);

  res.json(orders.map(formatOrder).reverse());
});

router.get("/orders/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [order] = await db
    .select()
    .from(ordersTable)
    .where(and(eq(ordersTable.id, id), eq(ordersTable.userId, req.user!.id)));

  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  res.json(formatOrder(order));
});

router.get("/orders/:id/bill", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const [order] = await db
    .select()
    .from(ordersTable)
    .where(and(eq(ordersTable.id, id), eq(ordersTable.userId, req.user!.id)));

  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  res.json({
    order: formatOrder(order),
    storeName: STORE_NAME,
    storeAddress: STORE_ADDRESS,
    storePhone: STORE_PHONE,
    storeEmail: STORE_EMAIL,
    gstNumber: STORE_GST,
    billDate: order.createdAt.toISOString(),
  });
});

router.post("/orders", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userId = req.user!.id;
  const { addressId, paymentMethod, couponCode } = parsed.data;

  const [address] = await db
    .select()
    .from(addressesTable)
    .where(and(eq(addressesTable.id, addressId), eq(addressesTable.userId, userId)));

  if (!address) {
    res.status(404).json({ error: "Address not found" });
    return;
  }

  const cartItems = await db
    .select({ item: cartItemsTable, product: productsTable })
    .from(cartItemsTable)
    .leftJoin(productsTable, eq(cartItemsTable.productId, productsTable.id))
    .where(eq(cartItemsTable.userId, userId));

  if (cartItems.length === 0) {
    res.status(400).json({ error: "Cart is empty" });
    return;
  }

  const subtotal = cartItems.reduce((sum, row) => {
    return sum + parseFloat(row.item.price) * row.item.quantity;
  }, 0);

  const deliveryFee = subtotal > 499 ? 0 : 49;
  let discount = 0;

  if (couponCode) {
    const [coupon] = await db
      .select()
      .from(couponsTable)
      .where(
        and(
          eq(couponsTable.code, couponCode),
          eq(couponsTable.isActive, true),
        )
      );
    if (coupon) {
      if (coupon.discountType === "percentage") {
        discount = Math.min(
          (subtotal * parseFloat(coupon.discount)) / 100,
          coupon.maxDiscount ? parseFloat(coupon.maxDiscount) : Infinity
        );
      } else {
        discount = parseFloat(coupon.discount);
      }
    }
  }

  const total = subtotal + deliveryFee - discount;

  const itemsSnapshot = cartItems.map((row) => ({
    id: row.item.id,
    productId: row.item.productId,
    productName: row.product!.name,
    productImage: (row.product!.images || [])[0] || "",
    quantity: row.item.quantity,
    price: parseFloat(row.item.price),
    total: parseFloat(row.item.price) * row.item.quantity,
  }));

  const addressSnapshot = {
    id: address.id,
    name: address.name,
    phone: address.phone,
    addressLine1: address.addressLine1,
    addressLine2: address.addressLine2,
    city: address.city,
    state: address.state,
    pincode: address.pincode,
    landmark: address.landmark,
    latitude: address.latitude ? parseFloat(address.latitude) : null,
    longitude: address.longitude ? parseFloat(address.longitude) : null,
    isDefault: address.isDefault,
    type: address.type,
  };

  const estimatedDelivery = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000);

  const [order] = await db
    .insert(ordersTable)
    .values({
      userId,
      orderNumber: generateOrderNumber(),
      status: "confirmed",
      paymentStatus: paymentMethod === "cod" ? "pending" : "paid",
      paymentMethod,
      addressSnapshot,
      itemsSnapshot,
      subtotal: subtotal.toString(),
      discount: discount.toString(),
      deliveryFee: deliveryFee.toString(),
      total: total.toString(),
      couponCode: couponCode || null,
      razorpayOrderId: parsed.data.razorpayOrderId || null,
      razorpayPaymentId: parsed.data.razorpayPaymentId || null,
      estimatedDelivery,
    })
    .returning();

  await db.delete(cartItemsTable).where(eq(cartItemsTable.userId, userId));

  res.json(formatOrder(order));
});

router.post("/payments/create-order", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreatePaymentOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { amount, currency = "INR" } = parsed.data;

  try {
    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString("base64")}`,
      },
      body: JSON.stringify({
        amount: Math.round(amount * 100),
        currency,
        receipt: `receipt_${Date.now()}`,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json() as any;
      res.status(500).json({ error: "Failed to create payment order", details: errorData });
      return;
    }

    const razorpayOrder = await response.json() as any;

    res.json({
      id: razorpayOrder.id,
      amount: razorpayOrder.amount / 100,
      currency: razorpayOrder.currency,
      key: RAZORPAY_KEY_ID,
    });
  } catch {
    res.status(500).json({ error: "Payment service unavailable" });
  }
});

router.post("/payments/verify", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = VerifyPaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { razorpayOrderId, razorpayPaymentId, razorpaySignature, addressId, couponCode, paymentMethod } = parsed.data;

  const expectedSignature = createHmac("sha256", RAZORPAY_KEY_SECRET)
    .update(`${razorpayOrderId}|${razorpayPaymentId}`)
    .digest("hex");

  if (expectedSignature !== razorpaySignature && RAZORPAY_KEY_SECRET !== "secret_placeholder") {
    res.status(400).json({ error: "Invalid payment signature" });
    return;
  }

  const userId = req.user!.id;

  const [address] = await db
    .select()
    .from(addressesTable)
    .where(and(eq(addressesTable.id, addressId), eq(addressesTable.userId, userId)));

  if (!address) {
    res.status(404).json({ error: "Address not found" });
    return;
  }

  const cartItems = await db
    .select({ item: cartItemsTable, product: productsTable })
    .from(cartItemsTable)
    .leftJoin(productsTable, eq(cartItemsTable.productId, productsTable.id))
    .where(eq(cartItemsTable.userId, userId));

  const subtotal = cartItems.reduce((sum, row) => sum + parseFloat(row.item.price) * row.item.quantity, 0);
  const deliveryFee = subtotal > 499 ? 0 : 49;
  let discount = 0;

  if (couponCode) {
    const [coupon] = await db.select().from(couponsTable).where(eq(couponsTable.code, couponCode));
    if (coupon) {
      if (coupon.discountType === "percentage") {
        discount = Math.min(
          (subtotal * parseFloat(coupon.discount)) / 100,
          coupon.maxDiscount ? parseFloat(coupon.maxDiscount) : Infinity
        );
      } else {
        discount = parseFloat(coupon.discount);
      }
    }
  }

  const total = subtotal + deliveryFee - discount;
  const itemsSnapshot = cartItems.map((row) => ({
    id: row.item.id,
    productId: row.item.productId,
    productName: row.product!.name,
    productImage: (row.product!.images || [])[0] || "",
    quantity: row.item.quantity,
    price: parseFloat(row.item.price),
    total: parseFloat(row.item.price) * row.item.quantity,
  }));

  const addressSnapshot = {
    id: address.id,
    name: address.name,
    phone: address.phone,
    addressLine1: address.addressLine1,
    addressLine2: address.addressLine2,
    city: address.city,
    state: address.state,
    pincode: address.pincode,
    landmark: address.landmark,
    latitude: address.latitude ? parseFloat(address.latitude) : null,
    longitude: address.longitude ? parseFloat(address.longitude) : null,
    isDefault: address.isDefault,
    type: address.type,
  };

  const estimatedDelivery = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000);

  const [order] = await db
    .insert(ordersTable)
    .values({
      userId,
      orderNumber: generateOrderNumber(),
      status: "confirmed",
      paymentStatus: "paid",
      paymentMethod: paymentMethod || "razorpay",
      addressSnapshot,
      itemsSnapshot,
      subtotal: subtotal.toString(),
      discount: discount.toString(),
      deliveryFee: deliveryFee.toString(),
      total: total.toString(),
      couponCode: couponCode || null,
      razorpayOrderId,
      razorpayPaymentId,
      estimatedDelivery,
    })
    .returning();

  await db.delete(cartItemsTable).where(eq(cartItemsTable.userId, userId));

  res.json(formatOrder(order));
});

export default router;
