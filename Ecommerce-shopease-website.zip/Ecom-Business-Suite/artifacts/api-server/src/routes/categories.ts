import { Router, type IRouter } from "express";
import { db, categoriesTable, productsTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/categories", async (_req, res): Promise<void> => {
  const categories = await db
    .select({
      id: categoriesTable.id,
      name: categoriesTable.name,
      slug: categoriesTable.slug,
      image: categoriesTable.image,
      icon: categoriesTable.icon,
      productCount: sql<number>`(SELECT COUNT(*) FROM products WHERE products.category_id = categories.id)::int`,
    })
    .from(categoriesTable)
    .orderBy(categoriesTable.name);

  res.json(categories);
});

export default router;
