import { Router, type IRouter } from "express";
import { db, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

const DEFAULT_SLIDES = [
  {
    id: "1",
    title: "Biggest Sale of the Year",
    subtitle: "Up to 70% off on Electronics",
    cta: "Shop Electronics",
    href: "/products?categoryId=1",
    gradient: "from-indigo-600 via-purple-600 to-pink-500",
    image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=1200&q=80",
  },
  {
    id: "2",
    title: "New Fashion Arrivals",
    subtitle: "Latest trends at unbeatable prices",
    cta: "Explore Fashion",
    href: "/products?categoryId=2",
    gradient: "from-orange-500 via-rose-500 to-pink-600",
    image: "https://images.unsplash.com/photo-1445205170230-053b83016050?w=1200&q=80",
  },
  {
    id: "3",
    title: "Free Delivery Above Rs.499",
    subtitle: "Shop more, save more every day",
    cta: "Shop Now",
    href: "/products",
    gradient: "from-amber-500 via-orange-500 to-red-500",
    image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&q=80",
  },
];

async function ensureSettings() {
  const [existing] = await db.select().from(settingsTable).where(eq(settingsTable.id, 1));
  if (existing) {
    if (!existing.heroSlides || existing.heroSlides.length === 0) {
      await db.update(settingsTable).set({ heroSlides: DEFAULT_SLIDES }).where(eq(settingsTable.id, 1));
      return { ...existing, heroSlides: DEFAULT_SLIDES };
    }
    return existing;
  }
  const [created] = await db
    .insert(settingsTable)
    .values({
      id: 1,
      heroSlides: DEFAULT_SLIDES,
      offerBarTexts: [
        "Free delivery on orders above Rs.499",
        "Use code WELCOME10 for 10% off your first order",
        "New arrivals every week",
        "Use code FLAT50 for flat Rs.50 off",
        "5-7 day delivery across India",
      ],
    })
    .returning();
  return created;
}

router.get("/settings", async (_req, res) => {
  const settings = await ensureSettings();
  res.json(settings);
});

export default router;
export { ensureSettings };
