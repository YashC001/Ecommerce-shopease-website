import { Router, type IRouter } from "express";
import {
  db,
  reelsTable,
  reelLikesTable,
  reelCommentsTable,
  productsTable,
  usersTable,
} from "@workspace/db";
import { eq, desc, and, sql, inArray } from "drizzle-orm";
import { requireAuth, optionalAuth, type AuthRequest } from "../middlewares/auth";

const router: IRouter = Router();

// PUBLIC: list active reels with product info (and isLiked if authenticated)
router.get("/reels", optionalAuth, async (req: AuthRequest, res) => {
  const limit = Math.min(Number(req.query["limit"] ?? 50), 100);
  const offset = Number(req.query["offset"] ?? 0);

  const reels = await db
    .select({
      id: reelsTable.id,
      title: reelsTable.title,
      description: reelsTable.description,
      videoUrl: reelsTable.videoUrl,
      thumbnailUrl: reelsTable.thumbnailUrl,
      productId: reelsTable.productId,
      likeCount: reelsTable.likeCount,
      commentCount: reelsTable.commentCount,
      viewCount: reelsTable.viewCount,
      shareCount: reelsTable.shareCount,
      createdAt: reelsTable.createdAt,
      product: {
        id: productsTable.id,
        name: productsTable.name,
        slug: productsTable.slug,
        price: productsTable.price,
        originalPrice: productsTable.originalPrice,
        images: productsTable.images,
        stock: productsTable.stock,
      },
    })
    .from(reelsTable)
    .leftJoin(productsTable, eq(reelsTable.productId, productsTable.id))
    .where(eq(reelsTable.isActive, true))
    .orderBy(desc(reelsTable.sortOrder), desc(reelsTable.createdAt))
    .limit(limit)
    .offset(offset);

  // Add isLiked flag
  let likedSet = new Set<number>();
  if (req.user && reels.length > 0) {
    const reelIds = reels.map((r) => r.id);
    const likes = await db
      .select({ reelId: reelLikesTable.reelId })
      .from(reelLikesTable)
      .where(and(eq(reelLikesTable.userId, req.user.id), inArray(reelLikesTable.reelId, reelIds)));
    likedSet = new Set(likes.map((l) => l.reelId));
  }

  res.json(reels.map((r) => ({ ...r, isLiked: likedSet.has(r.id) })));
});

// PUBLIC: get single reel
router.get("/reels/:id", optionalAuth, async (req: AuthRequest, res) => {
  const id = Number(req.params.id);
  const [reel] = await db
    .select({
      id: reelsTable.id,
      title: reelsTable.title,
      description: reelsTable.description,
      videoUrl: reelsTable.videoUrl,
      thumbnailUrl: reelsTable.thumbnailUrl,
      productId: reelsTable.productId,
      likeCount: reelsTable.likeCount,
      commentCount: reelsTable.commentCount,
      viewCount: reelsTable.viewCount,
      shareCount: reelsTable.shareCount,
      createdAt: reelsTable.createdAt,
      product: {
        id: productsTable.id,
        name: productsTable.name,
        slug: productsTable.slug,
        price: productsTable.price,
        originalPrice: productsTable.originalPrice,
        images: productsTable.images,
        stock: productsTable.stock,
      },
    })
    .from(reelsTable)
    .leftJoin(productsTable, eq(reelsTable.productId, productsTable.id))
    .where(eq(reelsTable.id, id));

  if (!reel) {
    res.status(404).json({ error: "Reel not found" });
    return;
  }

  let isLiked = false;
  if (req.user) {
    const [like] = await db
      .select()
      .from(reelLikesTable)
      .where(and(eq(reelLikesTable.userId, req.user.id), eq(reelLikesTable.reelId, id)));
    isLiked = !!like;
  }

  res.json({ ...reel, isLiked });
});

// Increment view count
router.post("/reels/:id/view", async (req, res) => {
  const id = Number(req.params.id);
  await db.update(reelsTable).set({ viewCount: sql`${reelsTable.viewCount} + 1` }).where(eq(reelsTable.id, id));
  res.json({ success: true });
});

// Increment share count
router.post("/reels/:id/share", async (req, res) => {
  const id = Number(req.params.id);
  await db.update(reelsTable).set({ shareCount: sql`${reelsTable.shareCount} + 1` }).where(eq(reelsTable.id, id));
  res.json({ success: true });
});

// Toggle like (auth required)
router.post("/reels/:id/like", requireAuth, async (req: AuthRequest, res) => {
  if (!req.user) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const id = Number(req.params.id);
  const userId = req.user.id;

  const [existing] = await db
    .select()
    .from(reelLikesTable)
    .where(and(eq(reelLikesTable.userId, userId), eq(reelLikesTable.reelId, id)));

  if (existing) {
    await db.delete(reelLikesTable).where(eq(reelLikesTable.id, existing.id));
    await db.update(reelsTable).set({ likeCount: sql`GREATEST(${reelsTable.likeCount} - 1, 0)` }).where(eq(reelsTable.id, id));
    res.json({ liked: false });
  } else {
    await db.insert(reelLikesTable).values({ userId, reelId: id });
    await db.update(reelsTable).set({ likeCount: sql`${reelsTable.likeCount} + 1` }).where(eq(reelsTable.id, id));
    res.json({ liked: true });
  }
});

// List liked reels for current user
router.get("/reels/me/liked", requireAuth, async (req: AuthRequest, res) => {
  if (!req.user) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const liked = await db
    .select({
      id: reelsTable.id,
      title: reelsTable.title,
      description: reelsTable.description,
      videoUrl: reelsTable.videoUrl,
      thumbnailUrl: reelsTable.thumbnailUrl,
      productId: reelsTable.productId,
      likeCount: reelsTable.likeCount,
      likedAt: reelLikesTable.createdAt,
    })
    .from(reelLikesTable)
    .innerJoin(reelsTable, eq(reelLikesTable.reelId, reelsTable.id))
    .where(eq(reelLikesTable.userId, req.user.id))
    .orderBy(desc(reelLikesTable.createdAt));
  res.json(liked);
});

// List comments
router.get("/reels/:id/comments", async (req, res) => {
  const id = Number(req.params.id);
  const comments = await db
    .select({
      id: reelCommentsTable.id,
      text: reelCommentsTable.text,
      createdAt: reelCommentsTable.createdAt,
      user: {
        id: usersTable.id,
        name: usersTable.name,
        avatar: usersTable.avatar,
      },
    })
    .from(reelCommentsTable)
    .innerJoin(usersTable, eq(reelCommentsTable.userId, usersTable.id))
    .where(eq(reelCommentsTable.reelId, id))
    .orderBy(desc(reelCommentsTable.createdAt))
    .limit(100);
  res.json(comments);
});

// Add comment
router.post("/reels/:id/comments", requireAuth, async (req: AuthRequest, res) => {
  if (!req.user) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const id = Number(req.params.id);
  const { text } = req.body ?? {};
  if (!text || typeof text !== "string" || !text.trim()) {
    res.status(400).json({ error: "Comment text is required" });
    return;
  }
  const [created] = await db
    .insert(reelCommentsTable)
    .values({ reelId: id, userId: req.user.id, text: text.trim().slice(0, 500) })
    .returning();
  await db.update(reelsTable).set({ commentCount: sql`${reelsTable.commentCount} + 1` }).where(eq(reelsTable.id, id));
  res.json({
    id: created.id,
    text: created.text,
    createdAt: created.createdAt,
    user: { id: req.user.id, name: req.user.name, avatar: req.user.avatar },
  });
});

export default router;
