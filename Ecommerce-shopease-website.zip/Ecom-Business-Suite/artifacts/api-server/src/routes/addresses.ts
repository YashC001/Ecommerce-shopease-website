import { Router, type IRouter } from "express";
import { db, addressesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/auth";
import { CreateAddressBody } from "@workspace/api-zod";

const router: IRouter = Router();

function formatAddress(a: any) {
  return {
    id: a.id,
    name: a.name,
    phone: a.phone,
    addressLine1: a.addressLine1,
    addressLine2: a.addressLine2,
    city: a.city,
    state: a.state,
    pincode: a.pincode,
    landmark: a.landmark,
    latitude: a.latitude ? parseFloat(a.latitude) : null,
    longitude: a.longitude ? parseFloat(a.longitude) : null,
    isDefault: a.isDefault,
    type: a.type,
  };
}

router.get("/addresses", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const addresses = await db
    .select()
    .from(addressesTable)
    .where(eq(addressesTable.userId, req.user!.id));

  res.json(addresses.map(formatAddress));
});

router.post("/addresses", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreateAddressBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userId = req.user!.id;

  if (parsed.data.isDefault) {
    await db
      .update(addressesTable)
      .set({ isDefault: false })
      .where(eq(addressesTable.userId, userId));
  }

  const [address] = await db
    .insert(addressesTable)
    .values({
      ...parsed.data,
      userId,
      latitude: parsed.data.latitude?.toString(),
      longitude: parsed.data.longitude?.toString(),
    })
    .returning();

  res.json(formatAddress(address));
});

router.put("/addresses/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  const parsed = CreateAddressBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userId = req.user!.id;

  if (parsed.data.isDefault) {
    await db
      .update(addressesTable)
      .set({ isDefault: false })
      .where(eq(addressesTable.userId, userId));
  }

  const [address] = await db
    .update(addressesTable)
    .set({
      ...parsed.data,
      latitude: parsed.data.latitude?.toString(),
      longitude: parsed.data.longitude?.toString(),
    })
    .where(and(eq(addressesTable.id, id), eq(addressesTable.userId, userId)))
    .returning();

  if (!address) {
    res.status(404).json({ error: "Address not found" });
    return;
  }

  res.json(formatAddress(address));
});

router.delete("/addresses/:id", requireAuth, async (req: AuthRequest, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);

  await db
    .delete(addressesTable)
    .where(and(eq(addressesTable.id, id), eq(addressesTable.userId, req.user!.id)));

  res.json({ message: "Address deleted" });
});

export default router;
