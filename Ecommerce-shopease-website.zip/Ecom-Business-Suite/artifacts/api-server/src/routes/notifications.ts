import { Router, type IRouter, type Request, type Response } from "express";
import { db, notificationsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/notifications", async (_req: Request, res: Response) => {
  const rows = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.isActive, true))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(20);
  res.json(rows);
});

export default router;
