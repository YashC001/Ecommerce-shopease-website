import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import categoriesRouter from "./categories";
import productsRouter from "./products";
import cartRouter from "./cart";
import wishlistRouter from "./wishlist";
import addressesRouter from "./addresses";
import ordersRouter from "./orders";
import usersRouter from "./users";
import couponsRouter from "./coupons";
import reviewsRouter from "./reviews";
import adminRouter from "./admin";
import settingsRouter from "./settings";
import reelsRouter from "./reels";
import storageRouter from "./storage";
import notificationsRouter from "./notifications";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(categoriesRouter);
router.use(productsRouter);
router.use(cartRouter);
router.use(wishlistRouter);
router.use(addressesRouter);
router.use(ordersRouter);
router.use(usersRouter);
router.use(couponsRouter);
router.use(reviewsRouter);
router.use(settingsRouter);
router.use(reelsRouter);
router.use(storageRouter);
router.use(notificationsRouter);
router.use(adminRouter);

export default router;
