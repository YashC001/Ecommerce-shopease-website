import { Router, type IRouter } from "express";
import {
  db,
  usersTable,
  productsTable,
  categoriesTable,
  ordersTable,
  couponsTable,
  cartItemsTable,
  wishlistItemsTable,
  reviewsTable,
  settingsTable,
  reelsTable,
  notificationsTable,
} from "@workspace/db";
import { eq, sql, desc, gte } from "drizzle-orm";
import { requireAdmin } from "../middlewares/auth";
import { randomBytes, scryptSync } from "crypto";
import { ensureSettings } from "./settings";

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

const router: IRouter = Router();

// Bootstrap: promote first user to admin if no admins exist (no auth required for first-time setup)
router.post("/admin/bootstrap", async (_req, res) => {
  const [existing] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(usersTable)
    .where(eq(usersTable.role, "admin"));
  if ((existing?.count ?? 0) > 0) {
    res.status(403).json({ error: "Admin already exists" });
    return;
  }
  const [first] = await db.select().from(usersTable).orderBy(usersTable.id).limit(1);
  if (!first) {
    res.status(404).json({ error: "No users found" });
    return;
  }
  await db.update(usersTable).set({ role: "admin" }).where(eq(usersTable.id, first.id));
  res.json({ success: true, message: `User ${first.email} promoted to admin` });
});

router.use("/admin", requireAdmin);

router.get("/admin/stats", async (_req, res) => {
  const [orderStats] = await db
    .select({
      total: sql<number>`count(*)::int`,
      revenue: sql<string>`coalesce(sum(${ordersTable.total}), 0)::text`,
      pending: sql<number>`count(*) filter (where ${ordersTable.status} = 'pending')::int`,
    })
    .from(ordersTable);

  const [userCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(usersTable);

  const [productCount] = await db
    .select({
      count: sql<number>`count(*)::int`,
      lowStock: sql<number>`count(*) filter (where ${productsTable.stock} < 10)::int`,
    })
    .from(productsTable);

  const [categoryCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(categoriesTable);

  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const recentOrders = await db
    .select()
    .from(ordersTable)
    .where(gte(ordersTable.createdAt, since))
    .orderBy(desc(ordersTable.createdAt))
    .limit(10);

  const dailyRevenue = await db
    .select({
      day: sql<string>`to_char(${ordersTable.createdAt}, 'YYYY-MM-DD')`,
      revenue: sql<string>`coalesce(sum(${ordersTable.total}), 0)::text`,
      orders: sql<number>`count(*)::int`,
    })
    .from(ordersTable)
    .where(gte(ordersTable.createdAt, since))
    .groupBy(sql`to_char(${ordersTable.createdAt}, 'YYYY-MM-DD')`)
    .orderBy(sql`to_char(${ordersTable.createdAt}, 'YYYY-MM-DD')`);

  res.json({
    orders: {
      total: orderStats?.total ?? 0,
      pending: orderStats?.pending ?? 0,
      revenue: orderStats?.revenue ?? "0",
    },
    users: userCount?.count ?? 0,
    products: {
      total: productCount?.count ?? 0,
      lowStock: productCount?.lowStock ?? 0,
    },
    categories: categoryCount?.count ?? 0,
    recentOrders,
    dailyRevenue,
  });
});

// ---------------- PRODUCTS ----------------
router.get("/admin/products", async (_req, res) => {
  const products = await db
    .select()
    .from(productsTable)
    .orderBy(desc(productsTable.createdAt));
  res.json(products);
});

router.post("/admin/products", async (req, res) => {
  try {
    const [product] = await db.insert(productsTable).values(req.body).returning();
    res.json(product);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.put("/admin/products/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [product] = await db
      .update(productsTable)
      .set(req.body)
      .where(eq(productsTable.id, id))
      .returning();
    res.json(product);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.delete("/admin/products/:id", async (req, res) => {
  const id = Number(req.params.id);
  try {
    await db.delete(cartItemsTable).where(eq(cartItemsTable.productId, id));
    await db.delete(wishlistItemsTable).where(eq(wishlistItemsTable.productId, id));
    await db.delete(reviewsTable).where(eq(reviewsTable.productId, id));
    await db.delete(productsTable).where(eq(productsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- CATEGORIES ----------------
router.get("/admin/categories", async (_req, res) => {
  const cats = await db.select().from(categoriesTable).orderBy(categoriesTable.name);
  res.json(cats);
});

router.post("/admin/categories", async (req, res) => {
  try {
    const [cat] = await db.insert(categoriesTable).values(req.body).returning();
    res.json(cat);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.put("/admin/categories/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [cat] = await db
      .update(categoriesTable)
      .set(req.body)
      .where(eq(categoriesTable.id, id))
      .returning();
    res.json(cat);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.delete("/admin/categories/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [hasProducts] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(productsTable)
      .where(eq(productsTable.categoryId, id));
    if ((hasProducts?.count ?? 0) > 0) {
      res.status(400).json({ error: "Cannot delete category with existing products" });
      return;
    }
    await db.delete(categoriesTable).where(eq(categoriesTable.id, id));
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- ORDERS ----------------
router.get("/admin/orders", async (req, res) => {
  const status = req.query["status"] as string | undefined;
  const rows = await db
    .select({
      order: ordersTable,
      user: {
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        phone: usersTable.phone,
      },
    })
    .from(ordersTable)
    .leftJoin(usersTable, eq(ordersTable.userId, usersTable.id))
    .where(status ? eq(ordersTable.status, status) : undefined)
    .orderBy(desc(ordersTable.createdAt));
  res.json(rows.map((r) => ({ ...r.order, user: r.user })));
});

router.put("/admin/orders/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const updates: Record<string, unknown> = {};
    if (req.body.status) updates["status"] = req.body.status;
    if (req.body.paymentStatus) updates["paymentStatus"] = req.body.paymentStatus;
    const [order] = await db
      .update(ordersTable)
      .set(updates)
      .where(eq(ordersTable.id, id))
      .returning();
    res.json(order);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- USERS ----------------
router.get("/admin/users", async (_req, res) => {
  const users = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      phone: usersTable.phone,
      role: usersTable.role,
      createdAt: usersTable.createdAt,
    })
    .from(usersTable)
    .orderBy(desc(usersTable.createdAt));

  const orderCounts = await db
    .select({
      userId: ordersTable.userId,
      count: sql<number>`count(*)::int`,
      total: sql<string>`coalesce(sum(${ordersTable.total}), 0)::text`,
    })
    .from(ordersTable)
    .groupBy(ordersTable.userId);

  const map = new Map(orderCounts.map((o) => [o.userId, o]));
  res.json(
    users.map((u) => ({
      ...u,
      orderCount: map.get(u.id)?.count ?? 0,
      totalSpent: map.get(u.id)?.total ?? "0",
    })),
  );
});

router.put("/admin/users/:id/role", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const role = req.body.role === "admin" ? "admin" : "user";
    const [user] = await db
      .update(usersTable)
      .set({ role })
      .where(eq(usersTable.id, id))
      .returning({
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
      });
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- COUPONS ----------------
router.get("/admin/coupons", async (_req, res) => {
  const coupons = await db.select().from(couponsTable).orderBy(desc(couponsTable.createdAt));
  res.json(coupons);
});

router.post("/admin/coupons", async (req, res) => {
  try {
    const body = { ...req.body };
    if (body.expiresAt && typeof body.expiresAt === "string") {
      body.expiresAt = new Date(body.expiresAt);
    }
    const [c] = await db.insert(couponsTable).values(body).returning();
    res.json(c);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.put("/admin/coupons/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const body = { ...req.body };
    if (body.expiresAt && typeof body.expiresAt === "string") {
      body.expiresAt = new Date(body.expiresAt);
    }
    const [c] = await db
      .update(couponsTable)
      .set(body)
      .where(eq(couponsTable.id, id))
      .returning();
    res.json(c);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.delete("/admin/coupons/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(couponsTable).where(eq(couponsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- SETTINGS ----------------
router.get("/admin/settings", async (_req, res) => {
  const settings = await ensureSettings();
  res.json(settings);
});

router.put("/admin/settings", async (req, res) => {
  try {
    await ensureSettings();
    const body = { ...req.body };
    delete body.id;
    delete body.updatedAt;
    const [updated] = await db
      .update(settingsTable)
      .set(body)
      .where(eq(settingsTable.id, 1))
      .returning();
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- CREATE ADMIN ----------------
router.post("/admin/users", async (req, res) => {
  try {
    const { name, email, phone, password, role } = req.body;
    if (!name || !email || !password) {
      res.status(400).json({ error: "Name, email and password are required" });
      return;
    }
    const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));
    if (existing) {
      res.status(409).json({ error: "Email already registered" });
      return;
    }
    const [user] = await db
      .insert(usersTable)
      .values({
        name,
        email,
        phone: phone || "",
        password: hashPassword(password),
        role: role === "admin" ? "admin" : "user",
      })
      .returning({
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        role: usersTable.role,
      });
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- RESET USER PASSWORD ----------------
router.put("/admin/users/:id/password", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { password } = req.body;
    if (!password || password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters" });
      return;
    }
    await db.update(usersTable).set({ password: hashPassword(password) }).where(eq(usersTable.id, id));
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- REELS CRUD ----------------
router.get("/admin/reels", async (_req, res) => {
  const rows = await db
    .select({
      id: reelsTable.id,
      title: reelsTable.title,
      description: reelsTable.description,
      videoUrl: reelsTable.videoUrl,
      thumbnailUrl: reelsTable.thumbnailUrl,
      productId: reelsTable.productId,
      likeCount: reelsTable.likeCount,
      commentCount: reelsTable.commentCount,
      viewCount: reelsTable.viewCount,
      shareCount: reelsTable.shareCount,
      isActive: reelsTable.isActive,
      sortOrder: reelsTable.sortOrder,
      createdAt: reelsTable.createdAt,
      product: {
        id: productsTable.id,
        name: productsTable.name,
        slug: productsTable.slug,
        price: productsTable.price,
        images: productsTable.images,
      },
    })
    .from(reelsTable)
    .leftJoin(productsTable, eq(reelsTable.productId, productsTable.id))
    .orderBy(desc(reelsTable.sortOrder), desc(reelsTable.createdAt));
  res.json(rows);
});

router.post("/admin/reels", async (req, res) => {
  try {
    const { title, description, videoUrl, thumbnailUrl, productId, isActive, sortOrder } = req.body;
    if (!videoUrl) {
      res.status(400).json({ error: "videoUrl is required" });
      return;
    }
    const [created] = await db
      .insert(reelsTable)
      .values({
        title: title ?? "",
        description: description ?? "",
        videoUrl,
        thumbnailUrl: thumbnailUrl ?? null,
        productId: productId ?? null,
        isActive: isActive ?? true,
        sortOrder: sortOrder ?? 0,
      })
      .returning();
    res.json(created);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.put("/admin/reels/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const body = { ...req.body };
    delete body.id;
    delete body.createdAt;
    delete body.updatedAt;
    delete body.likeCount;
    delete body.commentCount;
    delete body.viewCount;
    delete body.shareCount;
    delete body.product;
    const [updated] = await db.update(reelsTable).set(body).where(eq(reelsTable.id, id)).returning();
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.delete("/admin/reels/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(reelsTable).where(eq(reelsTable.id, id));
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// ---------------- P&L REPORT ----------------
router.get("/admin/pl", async (req, res) => {
  const days = Number(req.query["days"] ?? 30);
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const orders = await db
    .select({
      id: ordersTable.id,
      total: ordersTable.total,
      subtotal: ordersTable.subtotal,
      discount: ordersTable.discount,
      deliveryFee: ordersTable.deliveryFee,
      itemsSnapshot: ordersTable.itemsSnapshot,
      status: ordersTable.status,
      createdAt: ordersTable.createdAt,
    })
    .from(ordersTable)
    .where(gte(ordersTable.createdAt, since))
    .orderBy(desc(ordersTable.createdAt));

  const products = await db
    .select({ id: productsTable.id, cost: productsTable.cost, name: productsTable.name })
    .from(productsTable);
  const costMap = new Map(products.map((p) => [p.id, parseFloat(p.cost)]));

  let totalRevenue = 0;
  let totalCogs = 0;
  let totalDiscount = 0;
  let totalDelivery = 0;
  let cancelledRevenue = 0;
  const dailyMap: Record<string, { revenue: number; cogs: number; profit: number; orders: number }> = {};
  const productSales: Record<number, { name: string; qty: number; revenue: number; cogs: number; profit: number }> = {};

  for (const o of orders) {
    const items = (o.itemsSnapshot as Array<{ productId?: number; price: string | number; quantity: number; name: string }>) || [];
    const orderRevenue = parseFloat(o.total);
    let orderCogs = 0;
    for (const item of items) {
      const cost = costMap.get(item.productId ?? -1) ?? 0;
      const itemCogs = cost * item.quantity;
      const itemRev = parseFloat(String(item.price)) * item.quantity;
      orderCogs += itemCogs;
      if (item.productId) {
        const ps = productSales[item.productId] ?? { name: item.name, qty: 0, revenue: 0, cogs: 0, profit: 0 };
        ps.qty += item.quantity;
        ps.revenue += itemRev;
        ps.cogs += itemCogs;
        ps.profit = ps.revenue - ps.cogs;
        productSales[item.productId] = ps;
      }
    }

    if (o.status === "cancelled") {
      cancelledRevenue += orderRevenue;
      continue;
    }

    totalRevenue += orderRevenue;
    totalCogs += orderCogs;
    totalDiscount += parseFloat(o.discount);
    totalDelivery += parseFloat(o.deliveryFee);

    const day = (o.createdAt instanceof Date ? o.createdAt : new Date(o.createdAt))
      .toISOString()
      .slice(0, 10);
    const d = dailyMap[day] ?? { revenue: 0, cogs: 0, profit: 0, orders: 0 };
    d.revenue += orderRevenue;
    d.cogs += orderCogs;
    d.profit = d.revenue - d.cogs;
    d.orders += 1;
    dailyMap[day] = d;
  }

  const grossProfit = totalRevenue - totalCogs;
  const margin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

  const topProducts = Object.entries(productSales)
    .map(([id, v]) => ({ productId: Number(id), ...v }))
    .sort((a, b) => b.profit - a.profit)
    .slice(0, 10);

  res.json({
    days,
    totalRevenue: totalRevenue.toFixed(2),
    totalCogs: totalCogs.toFixed(2),
    grossProfit: grossProfit.toFixed(2),
    margin: margin.toFixed(2),
    totalDiscount: totalDiscount.toFixed(2),
    totalDelivery: totalDelivery.toFixed(2),
    cancelledRevenue: cancelledRevenue.toFixed(2),
    orderCount: orders.length,
    daily: Object.entries(dailyMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([day, v]) => ({ day, ...v })),
    topProducts,
  });
});

// ─── NOTIFICATIONS ────────────────────────────────────────────────────────────

router.get("/admin/notifications", async (_req, res) => {
  const rows = await db
    .select()
    .from(notificationsTable)
    .orderBy(desc(notificationsTable.createdAt));
  res.json(rows);
});

router.post("/admin/notifications", async (req, res) => {
  const { title, body, type, ctaText, ctaUrl } = req.body;
  if (!title || !body) {
    res.status(400).json({ error: "title and body are required" });
    return;
  }
  const [row] = await db
    .insert(notificationsTable)
    .values({ title, body, type: type ?? "info", ctaText: ctaText ?? null, ctaUrl: ctaUrl ?? null })
    .returning();
  res.json(row);
});

router.put("/admin/notifications/:id", async (req, res) => {
  const id = Number(req.params.id);
  const { title, body, type, isActive, ctaText, ctaUrl } = req.body;
  const [row] = await db
    .update(notificationsTable)
    .set({ title, body, type, isActive, ctaText, ctaUrl })
    .where(eq(notificationsTable.id, id))
    .returning();
  res.json(row);
});

router.delete("/admin/notifications/:id", async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(notificationsTable).where(eq(notificationsTable.id, id));
  res.json({ ok: true });
});

export default router;
