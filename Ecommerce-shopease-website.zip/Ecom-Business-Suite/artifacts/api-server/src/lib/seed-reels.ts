import { db, reelsTable, productsTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { logger } from "./logger";

const SAMPLES = [
  {
    title: "Unbox the new Galaxy S23 Ultra",
    description: "108MP camera, S-Pen included. Official launch in India 🇮🇳",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=600&h=1000&fit=crop",
    productMatch: "samsung",
  },
  {
    title: "Apple AirPods Pro - Active Noise Cancel",
    description: "Up to 2x more noise cancellation. Spatial audio you can feel.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=600&h=1000&fit=crop",
    productMatch: "airpods",
  },
  {
    title: "boAt Rockerz 550 Bass Test 🔥",
    description: "20-hour battery + thumping bass. Perfect daily companion.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=600&h=1000&fit=crop",
    productMatch: "boat",
  },
  {
    title: "Nike Air Max 270 - Run in Style",
    description: "Maximum cushioning, all day comfort. Made for the streets.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&h=1000&fit=crop",
    productMatch: "nike",
  },
  {
    title: "Glow up with Himalaya Neem",
    description: "Daily face wash for clear, healthy skin. 100% Ayurvedic.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600&h=1000&fit=crop",
    productMatch: "himalaya",
  },
  {
    title: "Perfect rice in 20 mins",
    description: "Prestige Iris Plus - One pot, endless meals.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=600&h=1000&fit=crop",
    productMatch: "rice cooker",
  },
  {
    title: "Harry Potter - The complete journey",
    description: "All 7 books, beautifully boxed. The perfect gift ✨",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600&h=1000&fit=crop",
    productMatch: "harry potter",
  },
  {
    title: "Crush leg day with Boldfit gloves",
    description: "Premium grip + wrist support. Train heavier, train safer.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=1000&fit=crop",
    productMatch: "gym",
  },
];

export async function seedSampleReels(): Promise<void> {
  try {
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(reelsTable);

    if (count > 0) {
      logger.info({ count }, "Reels already exist, skipping sample seed");
      return;
    }

    const products = await db
      .select({ id: productsTable.id, name: productsTable.name })
      .from(productsTable);

    const findProductId = (keyword: string): number | null => {
      const k = keyword.toLowerCase();
      const match = products.find((p) => p.name.toLowerCase().includes(k));
      return match?.id ?? null;
    };

    const rows = SAMPLES.map((s, idx) => ({
      title: s.title,
      description: s.description,
      videoUrl: s.videoUrl,
      thumbnailUrl: s.thumbnailUrl,
      productId: findProductId(s.productMatch),
      isActive: true,
      sortOrder: SAMPLES.length - idx,
      likeCount: Math.floor(Math.random() * 500) + 50,
      viewCount: Math.floor(Math.random() * 5000) + 500,
      commentCount: Math.floor(Math.random() * 50) + 5,
      shareCount: Math.floor(Math.random() * 100) + 10,
    }));

    await db.insert(reelsTable).values(rows);
    logger.info({ inserted: rows.length }, "Sample reels seeded");
  } catch (err) {
    logger.error({ err }, "Failed to seed sample reels");
  }
}
