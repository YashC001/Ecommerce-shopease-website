import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomBytes, scryptSync } from "crypto";
import { logger } from "./logger";

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export async function seedDefaultAdmin() {
  const email = process.env["ADMIN_EMAIL"] ?? "admin@shopease.in";
  const password = process.env["ADMIN_PASSWORD"] ?? "ShopEase@Admin2026!";
  try {
    const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));
    if (existing) {
      // Only ensure the role is admin; never overwrite an existing password on boot
      if (existing.role !== "admin") {
        await db.update(usersTable).set({ role: "admin" }).where(eq(usersTable.id, existing.id));
        logger.info({ email }, "Existing user promoted to admin");
      }
    } else {
      await db.insert(usersTable).values({
        name: "Admin",
        email,
        phone: "",
        password: hashPassword(password),
        role: "admin",
      });
      logger.info({ email }, "Default admin created with strong password");
    }
  } catch (err) {
    logger.error({ err }, "Failed to seed default admin");
  }
}
