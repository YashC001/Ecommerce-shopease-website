import app from "./app";
import { logger } from "./lib/logger";
import { seedDefaultAdmin } from "./lib/seed-admin";
import { seedSampleReels } from "./lib/seed-reels";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  seedDefaultAdmin().catch((err) => logger.error({ err }, "Seed failed"));
  seedSampleReels().catch((err) => logger.error({ err }, "Reels seed failed"));
});
