import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { Play, Heart, Eye } from "lucide-react";

interface ReelLite {
  id: number;
  title: string;
  thumbnailUrl: string | null;
  videoUrl: string;
  likeCount: number;
  viewCount: number;
}

const BASE = `${import.meta.env.BASE_URL}api`;

export function ReelsCarousel() {
  const [reels, setReels] = useState<ReelLite[]>([]);
  const scrollerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch(`${BASE}/reels?limit=20`)
      .then((r) => r.json())
      .then((data: ReelLite[]) => setReels(Array.isArray(data) ? data : []))
      .catch(() => {});
  }, []);

  if (reels.length === 0) return null;

  return (
    <section className="py-6 px-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-bold text-gray-900">Shop the Reels</h2>
        <Link href="/reels" className="text-sm text-orange-600 font-medium" data-testid="link-all-reels">
          View All →
        </Link>
      </div>
      <div
        ref={scrollerRef}
        className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 snap-x snap-mandatory scrollbar-hide"
        style={{ scrollbarWidth: "none" }}
      >
        {reels.map((r) => (
          <Link
            key={r.id}
            href={`/reels/${r.id}`}
            className="flex-shrink-0 w-32 sm:w-36 snap-start"
            data-testid={`reel-thumb-${r.id}`}
          >
            <div className="relative aspect-[9/16] rounded-xl overflow-hidden bg-gray-900 shadow-md">
              {r.thumbnailUrl ? (
                <img src={r.thumbnailUrl} alt={r.title} className="w-full h-full object-cover" loading="lazy" />
              ) : (
                <video src={r.videoUrl} className="w-full h-full object-cover" muted preload="metadata" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
              <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-sm rounded-full p-1.5">
                <Play className="h-3 w-3 text-white fill-white" />
              </div>
              <div className="absolute bottom-2 left-2 right-2 text-white">
                <div className="text-xs font-medium line-clamp-2 mb-1">{r.title || "Watch now"}</div>
                <div className="flex items-center gap-2 text-[10px] opacity-90">
                  <span className="flex items-center gap-0.5"><Eye className="h-2.5 w-2.5" /> {r.viewCount}</span>
                  <span className="flex items-center gap-0.5"><Heart className="h-2.5 w-2.5" /> {r.likeCount}</span>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
