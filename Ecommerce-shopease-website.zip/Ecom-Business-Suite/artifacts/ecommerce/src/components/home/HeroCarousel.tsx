import { useState, useEffect } from "react";
import { Link } from "wouter";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useSettings } from "@/hooks/useSettings";

const FALLBACK_SLIDE = {
  id: "default",
  title: "Welcome to ShopEase",
  subtitle: "Quality products at unbeatable prices",
  cta: "Shop Now",
  href: "/products",
  gradient: "from-orange-500 via-rose-500 to-pink-600",
  image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&q=80",
};

export function HeroCarousel() {
  const settings = useSettings();
  const slides = settings?.heroSlides?.length ? settings.heroSlides : [FALLBACK_SLIDE];
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (slides.length <= 1) return;
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [slides.length]);

  useEffect(() => {
    if (current >= slides.length) setCurrent(0);
  }, [slides.length, current]);

  const prev = () => setCurrent((c) => (c - 1 + slides.length) % slides.length);
  const next = () => setCurrent((c) => (c + 1) % slides.length);

  const slide = slides[current] ?? slides[0];

  return (
    <div className="relative overflow-hidden rounded-xl md:rounded-2xl" style={{ height: "clamp(180px, 40vw, 360px)" }}>
      {slides.map((s, i) => (
        <div
          key={s.id}
          className={`absolute inset-0 transition-all duration-700 ease-in-out ${
            i === current ? "opacity-100 scale-100" : "opacity-0 scale-105"
          }`}
        >
          <img src={s.image} alt={s.title} className="w-full h-full object-cover" />
          <div className={`absolute inset-0 bg-gradient-to-r ${s.gradient} opacity-75`} />
        </div>
      ))}

      <div className="absolute inset-0 flex items-center px-6 sm:px-10 md:px-14">
        <div className="text-white max-w-md">
          <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold mb-1 sm:mb-2 leading-tight drop-shadow">
            {slide.title}
          </h2>
          <p className="text-sm sm:text-base md:text-lg mb-3 sm:mb-4 text-white/90 drop-shadow">
            {slide.subtitle}
          </p>
          <Link href={slide.href}>
            <button className="bg-white text-gray-900 font-semibold px-4 sm:px-6 py-2 sm:py-2.5 rounded-full text-sm sm:text-base shadow-lg hover:shadow-xl hover:bg-gray-50 transition-all active:scale-95">
              {slide.cta}
            </button>
          </Link>
        </div>
      </div>

      {slides.length > 1 && (
        <>
          <button
            onClick={prev}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/30 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/50 transition-all"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={next}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/30 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/50 transition-all"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`rounded-full transition-all ${
                  i === current ? "w-5 h-2 bg-white" : "w-2 h-2 bg-white/50"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
