import { Link, useLocation, useRoute } from "wouter";
import { useEffect, useState } from "react";
import {
  LayoutDashboard,
  Image as ImageIcon,
  Video as VideoIcon,
  Settings as SettingsIcon,
  TrendingUp,
  UserCog,
  Package,
  ShoppingBag,
  Users,
  Tags,
  Ticket,
  LogOut,
  Menu,
  X,
  Store,
  Bell,
  Megaphone,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { adminFetch } from "@/lib/admin-api";
import { getToken, removeToken } from "@/lib/auth";

interface MeResponse {
  id: number;
  name: string;
  email: string;
  role: string;
}

const navItems = [
  { path: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { path: "/admin/products", label: "Products", icon: Package },
  { path: "/admin/categories", label: "Categories", icon: Tags },
  { path: "/admin/orders", label: "Orders", icon: ShoppingBag },
  { path: "/admin/users", label: "Users", icon: Users },
  { path: "/admin/coupons", label: "Coupons", icon: Ticket },
  { path: "/admin/carousel", label: "Carousel", icon: ImageIcon },
  { path: "/admin/reels", label: "vidview", icon: VideoIcon },
  { path: "/admin/notifications", label: "Notifications", icon: Bell },
  { path: "/admin/campaigns", label: "Campaigns", icon: Megaphone },
  { path: "/admin/pl", label: "P&L Report", icon: TrendingUp },
  { path: "/admin/settings", label: "Settings", icon: SettingsIcon },
  { path: "/admin/account", label: "My Account", icon: UserCog },
];

function NavLink({ item, currentPath, onClick }: { item: typeof navItems[number]; currentPath: string; onClick?: () => void }) {
  const active = item.exact ? currentPath === item.path : currentPath.startsWith(item.path);
  const Icon = item.icon;
  return (
    <Link href={item.path} onClick={onClick}>
      <div
        className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
          active ? "bg-orange-500 text-white" : "text-gray-700 hover:bg-orange-50"
        }`}
        data-testid={`admin-nav-${item.label.toLowerCase()}`}
      >
        <Icon className="h-4 w-4" />
        {item.label}
      </div>
    </Link>
  );
}

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location, navigate] = useLocation();
  const [, params] = useRoute("/admin/:rest*");
  void params;
  const [authorized, setAuthorized] = useState<boolean | null>(null);
  const [user, setUser] = useState<MeResponse | null>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!getToken()) {
      navigate("/admin/login");
      return;
    }
    adminFetch<MeResponse>("/auth/me")
      .then((u) => {
        if (u.role !== "admin") {
          setAuthorized(false);
        } else {
          setUser(u);
          setAuthorized(true);
        }
      })
      .catch(() => setAuthorized(false));
  }, [navigate]);

  if (authorized === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-gray-500">Loading admin panel...</div>
      </div>
    );
  }

  if (!authorized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="bg-white p-8 rounded-lg shadow-sm max-w-md text-center">
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-gray-600 mb-6">
            You do not have permission to access the admin panel.
          </p>
          <Link href="/">
            <Button className="bg-orange-500 hover:bg-orange-600">Go Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleLogout = () => {
    removeToken();
    navigate("/admin/login");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile menu button */}
      <button
        type="button"
        className="md:hidden fixed top-3 left-3 z-50 bg-white border border-gray-200 rounded-md p-2 shadow"
        onClick={() => setOpen((o) => !o)}
        aria-label="Toggle navigation"
        data-testid="button-admin-menu"
      >
        {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      {/* Sidebar */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-64 bg-white border-r border-gray-200 transform transition-transform md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="p-5 border-b border-gray-200">
          <Link href="/admin">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="bg-orange-500 text-white rounded-md p-1.5">
                <Store className="h-5 w-5" />
              </div>
              <div>
                <div className="font-bold text-gray-900">ShopEase</div>
                <div className="text-xs text-gray-500">Admin Panel</div>
              </div>
            </div>
          </Link>
        </div>

        <nav className="p-3 space-y-1">
          {navItems.map((item) => (
            <NavLink key={item.path} item={item} currentPath={location} onClick={() => setOpen(false)} />
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200 bg-white">
          {user && (
            <div className="mb-3 text-xs">
              <div className="font-medium text-gray-900 truncate">{user.name}</div>
              <div className="text-gray-500 truncate">{user.email}</div>
            </div>
          )}
          <Button
            variant="outline"
            className="w-full"
            onClick={handleLogout}
            data-testid="button-admin-logout"
          >
            <LogOut className="h-4 w-4 mr-2" /> Logout
          </Button>
          <Link href="/">
            <Button variant="ghost" className="w-full mt-2 text-orange-600">
              View Store
            </Button>
          </Link>
        </div>
      </aside>

      {open && (
        <div
          className="md:hidden fixed inset-0 bg-black/40 z-30"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Main */}
      <main className="flex-1 md:ml-0 ml-0 overflow-x-hidden pb-10">
        <div className="max-w-7xl mx-auto p-4 md:p-8 pt-16 md:pt-8">{children}</div>
      </main>
    </div>
  );
}
