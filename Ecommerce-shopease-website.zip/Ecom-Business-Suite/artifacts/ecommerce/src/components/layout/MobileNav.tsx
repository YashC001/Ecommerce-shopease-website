import { Link, useLocation } from "wouter";
import { Home, Grid3X3, Video, ShoppingCart, User } from "lucide-react";
import { useGetCart, getGetCartQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/useAuth";

export function MobileNav() {
  const [location] = useLocation();
  const { isAuthenticated } = useAuth();
  const { data: cart } = useGetCart({
    query: { enabled: isAuthenticated, queryKey: getGetCartQueryKey() },
  });

  const cartCount = cart?.itemCount || 0;

  const items = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/products", icon: Grid3X3, label: "Shop" },
    { href: "/reels", icon: Video, label: "Reels" },
    { href: "/cart", icon: ShoppingCart, label: "Cart", badge: cartCount },
    { href: isAuthenticated ? "/profile" : "/login", icon: User, label: isAuthenticated ? "Account" : "Login" },
  ];

  return (
    <div className="mobile-nav sm:hidden">
      <div className="flex items-center justify-around py-2">
        {items.map(({ href, icon: Icon, label, badge }) => {
          const isActive = location === href || (href !== "/" && location.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className={`flex flex-col items-center gap-0.5 px-4 py-1 rounded-lg transition-colors relative ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}
              data-testid={`mobile-nav-${label.toLowerCase()}`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {badge && badge > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-primary text-primary-foreground text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                    {badge > 9 ? "9+" : badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-medium">{label}</span>
              {isActive && <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
