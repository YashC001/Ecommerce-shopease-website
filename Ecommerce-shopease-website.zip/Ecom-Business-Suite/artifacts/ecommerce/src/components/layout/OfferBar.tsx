import { Tag } from "lucide-react";
import { useSettings } from "@/hooks/useSettings";

export function OfferBar() {
  const settings = useSettings();
  const offers = settings?.offerBarTexts ?? ["Free delivery on orders above Rs.499"];
  const text = offers.join("   |   ");

  return (
    <div className="bg-primary text-primary-foreground text-xs py-1.5 overflow-hidden">
      <div className="marquee-container">
        <div className="marquee-track">
          {[...Array(2)].map((_, i) => (
            <span key={i} className="flex items-center gap-2 px-4">
              <Tag className="w-3 h-3 flex-shrink-0" />
              {text}
              &nbsp;&nbsp;&nbsp;
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
