import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { ShoppingCart, User, Search, Menu, X, Heart, ChevronDown, MessageCircle, Bell } from "lucide-react";
import { useGetCategories, useGetCart, getGetCartQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/useAuth";
import { useSettings } from "@/hooks/useSettings";
import { Input } from "@/components/ui/input";

interface NavbarProps {
  onSearchChange?: (q: string) => void;
}

interface AppNotification {
  id: number;
  title: string;
  body: string;
  type: string;
  ctaText: string | null;
  ctaUrl: string | null;
  createdAt: string;
}

const DISMISSED_KEY = "shopease_dismissed_notifs";
const BASE = `${import.meta.env.BASE_URL}api`;

function getDismissed(): Set<number> {
  try {
    return new Set(JSON.parse(localStorage.getItem(DISMISSED_KEY) ?? "[]") as number[]);
  } catch {
    return new Set();
  }
}

function addDismissed(id: number) {
  const s = getDismissed();
  s.add(id);
  localStorage.setItem(DISMISSED_KEY, JSON.stringify([...s]));
}

const TYPE_DOT: Record<string, string> = {
  info: "bg-blue-500",
  offer: "bg-orange-500",
  warning: "bg-yellow-500",
  success: "bg-green-500",
};

export function Navbar({ onSearchChange }: NavbarProps) {
  const [, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [catOpen, setCatOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [dismissed, setDismissed] = useState<Set<number>>(getDismissed);
  const notifRef = useRef<HTMLDivElement>(null);

  const { user, isAuthenticated } = useAuth();
  const settings = useSettings();
  const { data: categories } = useGetCategories();
  const { data: cart } = useGetCart({
    query: { enabled: isAuthenticated, queryKey: getGetCartQueryKey() },
  });

  const cartCount = cart?.itemCount || 0;
  const unread = notifications.filter((n) => !dismissed.has(n.id)).length;

  useEffect(() => {
    fetch(`${BASE}/notifications`)
      .then((r) => r.json())
      .then((data) => setNotifications(data as AppNotification[]))
      .catch(() => {});
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const dismissAll = () => {
    notifications.forEach((n) => addDismissed(n.id));
    setDismissed(new Set(notifications.map((n) => n.id)));
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
    }
  };

  const WHATSAPP_NUMBER = settings?.whatsappNumber ?? "919876543210";
  const WHATSAPP_MSG = settings?.whatsappMessage ?? "Hi, I need help with my order";
  const STORE_NAME = settings?.storeName ?? "ShopEase";
  const LOGO_URL = settings?.logoUrl;

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-40 border-b border-border">
      <div className="max-w-7xl mx-auto px-3 sm:px-4">
        <div className="flex items-center h-14 gap-2">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0 flex items-center gap-1.5 mr-2">
            {LOGO_URL ? (
              <img src={LOGO_URL} alt={STORE_NAME} className="h-8 w-auto object-contain" />
            ) : (
              <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
                <ShoppingCart className="w-4 h-4 text-white" />
              </div>
            )}
            <span className="font-bold text-lg text-foreground hidden sm:block">{STORE_NAME}</span>
          </Link>

          {/* Category Dropdown */}
          <div className="relative hidden md:block flex-shrink-0">
            <button
              onClick={() => setCatOpen(!catOpen)}
              className="flex items-center gap-1 text-sm font-medium text-foreground hover:text-primary transition-colors px-3 py-2 rounded-lg hover:bg-accent"
              data-testid="nav-categories-btn"
            >
              Categories <ChevronDown className="w-3.5 h-3.5" />
            </button>
            {catOpen && (
              <div className="absolute top-full left-0 mt-1 bg-white rounded-xl shadow-xl border border-border z-50 min-w-[200px] py-2">
                {categories?.map((cat) => (
                  <Link
                    key={cat.id}
                    href={`/products?categoryId=${cat.id}`}
                    onClick={() => setCatOpen(false)}
                    className="block px-4 py-2.5 text-sm hover:bg-accent hover:text-accent-foreground transition-colors"
                    data-testid={`nav-category-${cat.id}`}
                  >
                    {cat.name}
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Search - desktop */}
          <form onSubmit={handleSearch} className="flex-1 hidden sm:block max-w-lg">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 h-9 bg-muted/50 border-0 focus-visible:ring-1 focus-visible:ring-primary"
                data-testid="nav-search-input"
              />
            </div>
          </form>

          <div className="flex items-center gap-1 ml-auto">
            {/* Mobile search */}
            <button
              className="sm:hidden p-2 rounded-lg hover:bg-accent transition-colors"
              onClick={() => setSearchOpen(!searchOpen)}
              data-testid="nav-search-mobile-btn"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* WhatsApp Support */}
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MSG)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg hover:bg-green-50 transition-colors text-green-600"
              data-testid="nav-whatsapp-btn"
              title="WhatsApp Support"
            >
              <MessageCircle className="w-5 h-5" />
            </a>

            {/* Notification Bell */}
            {notifications.length > 0 && (
              <div className="relative" ref={notifRef}>
                <button
                  onClick={() => setNotifOpen(!notifOpen)}
                  className="relative p-2 rounded-lg hover:bg-accent transition-colors"
                  data-testid="nav-notif-btn"
                >
                  <Bell className="w-5 h-5" />
                  {unread > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[9px] font-bold rounded-full min-w-[16px] h-4 flex items-center justify-center px-1">
                      {unread > 9 ? "9+" : unread}
                    </span>
                  )}
                </button>

                {notifOpen && (
                  <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-xl border border-border z-50 overflow-hidden">
                    <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                      <span className="font-semibold text-sm text-gray-900">Notifications</span>
                      {unread > 0 && (
                        <button
                          onClick={dismissAll}
                          className="text-xs text-orange-600 hover:underline"
                        >
                          Mark all read
                        </button>
                      )}
                    </div>
                    <div className="max-h-80 overflow-y-auto divide-y divide-gray-100">
                      {notifications.map((n) => {
                        const isRead = dismissed.has(n.id);
                        return (
                          <div
                            key={n.id}
                            className={`px-4 py-3 ${isRead ? "opacity-60" : "bg-orange-50/40"}`}
                          >
                            <div className="flex items-start gap-2">
                              <span
                                className={`mt-1.5 h-2 w-2 rounded-full flex-shrink-0 ${
                                  TYPE_DOT[n.type] ?? "bg-gray-400"
                                }`}
                              />
                              <div className="flex-1 min-w-0">
                                <div className="text-sm font-medium text-gray-900 leading-snug">
                                  {n.title}
                                </div>
                                <div className="text-xs text-gray-600 mt-0.5 leading-relaxed">
                                  {n.body}
                                </div>
                                {n.ctaText && n.ctaUrl && (
                                  <Link
                                    href={n.ctaUrl}
                                    onClick={() => {
                                      addDismissed(n.id);
                                      setDismissed(getDismissed());
                                      setNotifOpen(false);
                                    }}
                                    className="text-xs text-orange-600 font-medium mt-1 inline-block hover:underline"
                                  >
                                    {n.ctaText} →
                                  </Link>
                                )}
                              </div>
                              {!isRead && (
                                <button
                                  onClick={() => {
                                    addDismissed(n.id);
                                    setDismissed(getDismissed());
                                  }}
                                  className="text-gray-400 hover:text-gray-600 flex-shrink-0"
                                >
                                  <X className="h-3.5 w-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Wishlist */}
            <Link
              href="/wishlist"
              className="p-2 rounded-lg hover:bg-accent transition-colors hidden sm:flex items-center"
              data-testid="nav-wishlist-btn"
            >
              <Heart className="w-5 h-5" />
            </Link>

            {/* Cart */}
            <Link
              href="/cart"
              className="relative p-2 rounded-lg hover:bg-accent transition-colors"
              data-testid="nav-cart-btn"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-primary text-primary-foreground text-[10px] font-bold rounded-full min-w-[16px] h-4 flex items-center justify-center px-1" data-testid="cart-badge">
                  {cartCount > 99 ? "99+" : cartCount}
                </span>
              )}
            </Link>

            {/* User */}
            <Link
              href={isAuthenticated ? "/profile" : "/login"}
              className="p-2 rounded-lg hover:bg-accent transition-colors hidden sm:flex items-center"
              data-testid="nav-user-btn"
            >
              {isAuthenticated && user ? (
                <div className="w-7 h-7 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
                  {user.name?.charAt(0)?.toUpperCase()}
                </div>
              ) : (
                <User className="w-5 h-5" />
              )}
            </Link>

            {/* Mobile menu */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-accent transition-colors"
              onClick={() => setMenuOpen(!menuOpen)}
              data-testid="nav-menu-btn"
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile search bar */}
        {searchOpen && (
          <div className="sm:hidden pb-3">
            <form onSubmit={handleSearch}>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 h-9 bg-muted/50"
                  autoFocus
                  data-testid="nav-search-mobile-input"
                />
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Mobile drawer menu */}
      {menuOpen && (
        <div className="md:hidden border-t bg-white px-4 py-3">
          <div className="grid grid-cols-2 gap-2 mb-3">
            <Link href="/profile" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent text-sm">
              <User className="w-4 h-4" /> {isAuthenticated ? "My Profile" : "Login / Register"}
            </Link>
            <Link href="/wishlist" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent text-sm">
              <Heart className="w-4 h-4" /> Wishlist
            </Link>
            <Link href="/orders" onClick={() => setMenuOpen(false)} className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent text-sm">
              <ShoppingCart className="w-4 h-4" /> My Orders
            </Link>
          </div>
          <div className="border-t pt-3">
            <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">Categories</p>
            <div className="grid grid-cols-2 gap-1">
              {categories?.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/products?categoryId=${cat.id}`}
                  onClick={() => setMenuOpen(false)}
                  className="text-sm py-1.5 px-2 rounded hover:bg-accent hover:text-accent-foreground transition-colors"
                  data-testid={`mobile-category-${cat.id}`}
                >
                  {cat.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
