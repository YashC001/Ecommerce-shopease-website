import { useState } from "react";
import { Link } from "wouter";
import { Heart, Star, ShoppingCart, Zap } from "lucide-react";
import { useAddToCart, useAddToWishlist, useRemoveFromWishlist, getGetCartQueryKey, getGetWishlistQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";

interface Product {
  id: number;
  name: string;
  slug: string;
  price: number;
  originalPrice?: number | null;
  discountPercent?: number | null;
  images: string[];
  rating: number;
  reviewCount: number;
  stock: number;
  badge?: string | null;
  categoryName?: string;
}

interface ProductCardProps {
  product: Product;
  wishlisted?: boolean;
}

export function ProductCard({ product, wishlisted: initialWishlisted = false }: ProductCardProps) {
  const queryClient = useQueryClient();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [wishlisted, setWishlisted] = useState(initialWishlisted);
  const [imageError, setImageError] = useState(false);

  const addToCart = useAddToCart({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        toast({ title: "Added to cart!", description: product.name });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      },
    },
  });

  const addToWishlist = useAddToWishlist({
    mutation: {
      onSuccess: () => {
        setWishlisted(true);
        queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
        toast({ title: "Added to wishlist!" });
      },
    },
  });

  const removeFromWishlist = useRemoveFromWishlist({
    mutation: {
      onSuccess: () => {
        setWishlisted(false);
        queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
        toast({ title: "Removed from wishlist" });
      },
    },
  });

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthenticated) {
      setLocation("/login");
      return;
    }
    if (wishlisted) {
      removeFromWishlist.mutate({ productId: product.id });
    } else {
      addToWishlist.mutate({ data: { productId: product.id } });
    }
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthenticated) {
      setLocation("/login");
      return;
    }
    addToCart.mutate({ data: { productId: product.id, quantity: 1 } });
  };

  const image = imageError || !product.images?.[0] ? "https://placehold.co/300x300?text=No+Image" : product.images[0];

  return (
    <Link href={`/products/${product.id}`} data-testid={`card-product-${product.id}`}>
      <div className="product-card bg-white rounded-xl overflow-hidden border border-border cursor-pointer group">
        {/* Image */}
        <div className="relative aspect-square overflow-hidden bg-gray-50">
          <img
            src={image}
            alt={product.name}
            onError={() => setImageError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            data-testid={`img-product-${product.id}`}
          />
          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {product.discountPercent && product.discountPercent > 0 && (
              <Badge className="bg-red-500 text-white text-[10px] py-0 px-1.5 font-bold">
                -{product.discountPercent}%
              </Badge>
            )}
            {product.badge && (
              <Badge className="bg-primary text-primary-foreground text-[10px] py-0 px-1.5 font-bold">
                {product.badge}
              </Badge>
            )}
          </div>
          {/* Wishlist button */}
          <button
            onClick={handleWishlist}
            className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-sm hover:bg-white transition-all"
            data-testid={`btn-wishlist-${product.id}`}
          >
            <Heart
              className={`w-4 h-4 transition-colors ${wishlisted ? "fill-red-500 text-red-500" : "text-gray-400"}`}
            />
          </button>
        </div>

        {/* Info */}
        <div className="p-3">
          <p className="text-xs text-muted-foreground mb-0.5">{product.categoryName}</p>
          <p className="font-medium text-sm line-clamp-2 mb-1.5 text-foreground" data-testid={`text-product-name-${product.id}`}>
            {product.name}
          </p>

          {/* Rating */}
          <div className="flex items-center gap-1 mb-2">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-3 h-3 ${star <= Math.round(product.rating) ? "star-filled" : "star-empty"}`}
                />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">({product.reviewCount})</span>
          </div>

          {/* Price */}
          <div className="flex items-center gap-2 mb-2.5">
            <span className="font-bold text-base text-foreground" data-testid={`text-price-${product.id}`}>
              Rs.{product.price.toLocaleString()}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-xs text-muted-foreground line-through">
                Rs.{product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          {/* Add to cart */}
          <Button
            size="sm"
            className="w-full h-8 text-xs"
            onClick={handleAddToCart}
            disabled={addToCart.isPending || product.stock === 0}
            data-testid={`btn-add-cart-${product.id}`}
          >
            {product.stock === 0 ? (
              "Out of Stock"
            ) : addToCart.isPending ? (
              "Adding..."
            ) : (
              <>
                <ShoppingCart className="w-3.5 h-3.5 mr-1" /> Add to Cart
              </>
            )}
          </Button>
        </div>
      </div>
    </Link>
  );
}
