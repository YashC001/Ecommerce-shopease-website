import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import { OfferBar } from "@/components/layout/OfferBar";
import { Navbar } from "@/components/layout/Navbar";
import { MobileNav } from "@/components/layout/MobileNav";

import Home from "@/pages/home";
import Products from "@/pages/products";
import ProductDetail from "@/pages/product-detail";
import Cart from "@/pages/cart";
import Checkout from "@/pages/checkout";
import OrderSuccess from "@/pages/order-success";
import Orders from "@/pages/orders";
import Wishlist from "@/pages/wishlist";
import Profile from "@/pages/profile";
import Login from "@/pages/login";
import Register from "@/pages/register";
import NotFound from "@/pages/not-found";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminProducts from "@/pages/admin/products";
import AdminCategories from "@/pages/admin/categories";
import AdminOrders from "@/pages/admin/orders";
import AdminUsers from "@/pages/admin/users";
import AdminCoupons from "@/pages/admin/coupons";
import AdminSettings from "@/pages/admin/settings";
import AdminCarousel from "@/pages/admin/carousel";
import AdminPL from "@/pages/admin/pl";
import AdminLogin from "@/pages/admin/login";
import AdminAccount from "@/pages/admin/account";
import AdminReels from "@/pages/admin/reels";
import AdminNotifications from "@/pages/admin/notifications";
import AdminCampaigns from "@/pages/admin/campaigns";
import ReelsViewer from "@/pages/reels";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 2,
      retry: 1,
    },
  },
});

function ProductDetailWrapper({ params }: { params: { id: string } }) {
  return <ProductDetail id={params.id} />;
}

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <OfferBar />
      <Navbar />
      <main className="flex-1">{children}</main>
      <MobileNav />
    </div>
  );
}

function FullPageLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      {children}
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => <Layout><Home /></Layout>} />
      <Route path="/products" component={() => <Layout><Products /></Layout>} />
      <Route path="/products/:id" component={(props) => <Layout><ProductDetailWrapper params={props.params} /></Layout>} />
      <Route path="/cart" component={() => <Layout><Cart /></Layout>} />
      <Route path="/checkout" component={() => <Layout><Checkout /></Layout>} />
      <Route path="/order-success" component={() => <Layout><OrderSuccess /></Layout>} />
      <Route path="/orders" component={() => <Layout><Orders /></Layout>} />
      <Route path="/wishlist" component={() => <Layout><Wishlist /></Layout>} />
      <Route path="/profile" component={() => <Layout><Profile /></Layout>} />
      <Route path="/login" component={() => <FullPageLayout><Login /></FullPageLayout>} />
      <Route path="/register" component={() => <FullPageLayout><Register /></FullPageLayout>} />
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/" component={AdminDashboard} />
      <Route path="/admin/products" component={AdminProducts} />
      <Route path="/admin/categories" component={AdminCategories} />
      <Route path="/admin/orders" component={AdminOrders} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/coupons" component={AdminCoupons} />
      <Route path="/admin/carousel" component={AdminCarousel} />
      <Route path="/admin/settings" component={AdminSettings} />
      <Route path="/admin/pl" component={AdminPL} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/account" component={AdminAccount} />
      <Route path="/admin/reels" component={AdminReels} />
      <Route path="/admin/notifications" component={AdminNotifications} />
      <Route path="/admin/campaigns" component={AdminCampaigns} />
      <Route path="/reels" component={() => <FullPageLayout><ReelsViewer /></FullPageLayout>} />
      <Route path="/reels/:id" component={(props) => <FullPageLayout><ReelsViewer initialId={Number(props.params.id)} /></FullPageLayout>} />
      <Route component={() => <Layout><NotFound /></Layout>} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
