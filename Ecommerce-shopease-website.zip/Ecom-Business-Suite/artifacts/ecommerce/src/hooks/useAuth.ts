import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useGetMe, useLogin, useRegister, useLogout, getGetMeQueryKey } from "@workspace/api-client-react";

export function useAuth() {
  const queryClient = useQueryClient();
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("auth_token"));

  const { data: user, isLoading, refetch } = useGetMe({
    query: {
      enabled: !!token,
      queryKey: getGetMeQueryKey(),
      retry: false,
    },
  });

  const loginMutation = useLogin({
    mutation: {
      onSuccess: (data: any) => {
        localStorage.setItem("auth_token", data.token);
        setToken(data.token);
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      },
    },
  });

  const registerMutation = useRegister({
    mutation: {
      onSuccess: (data: any) => {
        localStorage.setItem("auth_token", data.token);
        setToken(data.token);
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      },
    },
  });

  const logoutMutation = useLogout({
    mutation: {
      onSuccess: () => {
        localStorage.removeItem("auth_token");
        setToken(null);
        queryClient.clear();
      },
    },
  });

  return {
    user: token ? user : null,
    token,
    isLoading: !!token && isLoading,
    isAuthenticated: !!token && !!user,
    login: loginMutation.mutate,
    register: registerMutation.mutate,
    logout: () => logoutMutation.mutate({}),
    loginPending: loginMutation.isPending,
    registerPending: registerMutation.isPending,
  };
}
