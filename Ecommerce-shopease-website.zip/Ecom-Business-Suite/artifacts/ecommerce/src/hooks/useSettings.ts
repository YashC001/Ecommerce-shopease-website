import { useEffect, useState } from "react";

export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  cta: string;
  href: string;
  gradient: string;
  image: string;
}

export interface SiteSettings {
  storeName: string;
  logoUrl: string | null;
  logoIcon: string;
  primaryColor: string;
  secondaryColor: string;
  whatsappNumber: string;
  whatsappMessage: string;
  supportEmail: string;
  supportPhone: string;
  storeAddress: string;
  footerText: string;
  footerBg: string;
  footerTextColor: string;
  freeDeliveryThreshold: string;
  deliveryFee: string;
  offerBarTexts: string[];
  heroSlides: HeroSlide[];
  homeTagline: string;
}

const BASE = `${import.meta.env.BASE_URL}api`;

let cached: SiteSettings | null = null;
const listeners = new Set<(s: SiteSettings) => void>();

function applyThemeColors(settings: SiteSettings) {
  const root = document.documentElement;
  if (settings.primaryColor) {
    root.style.setProperty("--color-brand-primary", settings.primaryColor);
  }
  if (settings.secondaryColor) {
    root.style.setProperty("--color-brand-secondary", settings.secondaryColor);
  }
}

export async function refreshSettings(): Promise<SiteSettings> {
  const res = await fetch(`${BASE}/settings`);
  const data = (await res.json()) as SiteSettings;
  cached = data;
  listeners.forEach((l) => l(data));
  applyThemeColors(data);
  return data;
}

export function useSettings(): SiteSettings | null {
  const [settings, setSettings] = useState<SiteSettings | null>(cached);

  useEffect(() => {
    listeners.add(setSettings);
    if (!cached) {
      refreshSettings().catch(() => {});
    } else {
      applyThemeColors(cached);
    }
    return () => {
      listeners.delete(setSettings);
    };
  }, []);

  return settings;
}
