import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { Filter, SlidersHorizontal, X, ChevronDown, Search } from "lucide-react";
import { useGetProducts, useGetCategories, getGetProductsQueryKey } from "@workspace/api-client-react";
import { ProductCard } from "@/components/products/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ProductsPage() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] || "");

  const [categoryId, setCategoryId] = useState<string>(params.get("categoryId") || "");
  const [search, setSearch] = useState<string>(params.get("search") || "");
  const [sort, setSort] = useState<string>(params.get("sort") || "");
  const [page, setPage] = useState(1);
  const [filterOpen, setFilterOpen] = useState(false);
  const [searchInput, setSearchInput] = useState(params.get("search") || "");

  const { data: categories } = useGetCategories();

  const queryParams = {
    ...(categoryId ? { categoryId: parseInt(categoryId) } : {}),
    ...(search ? { search } : {}),
    ...(sort ? { sort } : {}),
    page,
    limit: 24,
  };

  const { data: productsData, isLoading } = useGetProducts(queryParams, {
    query: { queryKey: getGetProductsQueryKey(queryParams) }
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(searchInput);
    setPage(1);
  };

  const handleCategoryChange = (val: string) => {
    setCategoryId(val === "all" ? "" : val);
    setPage(1);
  };

  const selectedCategory = categories?.find(c => String(c.id) === categoryId);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 pb-24 sm:pb-8">
      {/* Header */}
      <div className="mb-4">
        <h1 className="text-lg sm:text-xl font-bold text-foreground">
          {selectedCategory ? selectedCategory.name : "All Products"}
        </h1>
        <p className="text-xs text-muted-foreground">
          {productsData ? `${productsData.total} products found` : "Loading..."}
        </p>
      </div>

      {/* Filter bar */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <form onSubmit={handleSearch} className="flex-1 min-w-0 max-w-xs">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pl-8 h-9 text-sm"
              data-testid="products-search-input"
            />
          </div>
        </form>

        <Select value={categoryId || "all"} onValueChange={handleCategoryChange}>
          <SelectTrigger className="h-9 w-36 text-sm" data-testid="category-select">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories?.map((cat) => (
              <SelectItem key={cat.id} value={String(cat.id)}>{cat.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={sort || "default"} onValueChange={(val) => { setSort(val === "default" ? "" : val); setPage(1); }}>
          <SelectTrigger className="h-9 w-32 text-sm" data-testid="sort-select">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="default">Relevance</SelectItem>
            <SelectItem value="price_asc">Price: Low to High</SelectItem>
            <SelectItem value="price_desc">Price: High to Low</SelectItem>
            <SelectItem value="rating">Top Rated</SelectItem>
            <SelectItem value="newest">Newest First</SelectItem>
          </SelectContent>
        </Select>

        {(categoryId || search || sort) && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => { setCategoryId(""); setSearch(""); setSearchInput(""); setSort(""); setPage(1); }}
            className="h-9 text-xs text-muted-foreground"
            data-testid="btn-clear-filters"
          >
            <X className="w-3.5 h-3.5 mr-1" /> Clear
          </Button>
        )}
      </div>

      {/* Products Grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i}>
              <Skeleton className="aspect-square rounded-xl mb-2" />
              <Skeleton className="h-3 w-3/4 mb-1" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </div>
      ) : productsData?.products?.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-5xl mb-4">🛍️</div>
          <h3 className="text-base font-medium mb-1">No products found</h3>
          <p className="text-sm text-muted-foreground mb-4">Try changing your search or filters</p>
          <Button onClick={() => { setCategoryId(""); setSearch(""); setSort(""); }} variant="outline">
            Clear Filters
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {productsData?.products?.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}

      {/* Pagination */}
      {productsData && productsData.totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-8">
          <Button
            variant="outline"
            size="sm"
            disabled={page <= 1}
            onClick={() => setPage(p => p - 1)}
            data-testid="btn-prev-page"
          >
            Previous
          </Button>
          <span className="text-sm text-muted-foreground">
            Page {page} of {productsData.totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            disabled={page >= productsData.totalPages}
            onClick={() => setPage(p => p + 1)}
            data-testid="btn-next-page"
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
}
