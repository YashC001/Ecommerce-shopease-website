import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { MapPin, Plus, Home, Briefcase, Building, Check, Navigation, ChevronRight } from "lucide-react";
import { useGetAddresses, useCreateAddress, useGetCart, useCreatePaymentOrder, useCreateOrder, useValidateCoupon, getGetCartQueryKey, getGetAddressesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

declare global {
  interface Window {
    Razorpay: any;
  }
}

function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) { resolve(true); return; }
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export default function CheckoutPage() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [selectedAddressId, setSelectedAddressId] = useState<number | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [locating, setLocating] = useState(false);
  const [detectedLocation, setDetectedLocation] = useState<{ lat: number; lng: number; city?: string; state?: string } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<"razorpay" | "cod">("razorpay");
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number } | null>(null);
  const [processing, setProcessing] = useState(false);

  const [form, setForm] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    addressLine1: "",
    addressLine2: "",
    city: "",
    state: "",
    pincode: "",
    landmark: "",
    type: "Home",
    isDefault: false,
    latitude: undefined as number | undefined,
    longitude: undefined as number | undefined,
  });

  const { data: addresses, isLoading: addressesLoading } = useGetAddresses({
    query: { enabled: isAuthenticated }
  });
  const { data: cart } = useGetCart({
    query: { enabled: isAuthenticated, queryKey: getGetCartQueryKey() }
  });

  const createAddress = useCreateAddress({
    mutation: {
      onSuccess: (addr: any) => {
        setSelectedAddressId(addr.id);
        setShowAddForm(false);
        queryClient.invalidateQueries({ queryKey: getGetAddressesQueryKey() });
        toast({ title: "Address saved!" });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      },
    },
  });

  const createPaymentOrder = useCreatePaymentOrder();
  const createOrder = useCreateOrder();

  const validateCoupon = useValidateCoupon({
    mutation: {
      onSuccess: (data: any) => {
        if (data.valid) {
          setAppliedCoupon({ code: couponCode.toUpperCase(), discount: data.discount });
          toast({ title: "Coupon applied!", description: data.message });
        } else {
          toast({ title: "Invalid coupon", description: data.message, variant: "destructive" });
        }
      },
    },
  });

  useEffect(() => {
    if (addresses && addresses.length > 0 && !selectedAddressId) {
      const def = addresses.find(a => a.isDefault);
      setSelectedAddressId(def?.id || addresses[0].id);
    }
  }, [addresses]);

  useEffect(() => {
    if (!isAuthenticated) setLocation("/login");
  }, [isAuthenticated]);

  const detectLocation = () => {
    setLocating(true);
    if (!navigator.geolocation) {
      toast({ title: "Geolocation not supported by your browser" });
      setLocating(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude: lat, longitude: lng } = pos.coords;
        setDetectedLocation({ lat, lng });
        setForm(f => ({ ...f, latitude: lat, longitude: lng }));

        try {
          const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
          const data = await r.json();
          const city = data.address?.city || data.address?.town || data.address?.village || "";
          const state = data.address?.state || "";
          const pincode = data.address?.postcode || "";
          setDetectedLocation({ lat, lng, city, state });
          setForm(f => ({ ...f, city: city || f.city, state: state || f.state, pincode: pincode || f.pincode }));
          toast({ title: "Location detected!", description: `${city}, ${state}` });
        } catch {
          toast({ title: "Location detected", description: `Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)}` });
        }
        setLocating(false);
      },
      (err) => {
        toast({ title: "Could not detect location", variant: "destructive" });
        setLocating(false);
      },
      { timeout: 10000 }
    );
  };

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    createAddress.mutate({ data: form });
  };

  const getTotal = () => {
    if (!cart) return 0;
    return cart.total - (appliedCoupon?.discount || 0);
  };

  const handlePayment = async () => {
    if (!selectedAddressId) {
      toast({ title: "Please select an address", variant: "destructive" });
      return;
    }
    if (!cart || cart.items.length === 0) {
      toast({ title: "Cart is empty", variant: "destructive" });
      return;
    }

    setProcessing(true);

    if (paymentMethod === "cod") {
      createOrder.mutate({
        data: {
          addressId: selectedAddressId,
          paymentMethod: "cod",
          couponCode: appliedCoupon?.code,
        },
      }, {
        onSuccess: (order: any) => {
          setLocation(`/order-success?orderId=${order.id}`);
        },
        onError: (err: any) => {
          toast({ title: "Order failed", description: err.message, variant: "destructive" });
          setProcessing(false);
        },
      });
      return;
    }

    const loaded = await loadRazorpay();
    if (!loaded) {
      toast({ title: "Payment gateway failed to load", variant: "destructive" });
      setProcessing(false);
      return;
    }

    createPaymentOrder.mutate({
      data: { amount: getTotal(), currency: "INR" }
    }, {
      onSuccess: (payOrder: any) => {
        const options = {
          key: payOrder.key,
          amount: payOrder.amount * 100,
          currency: payOrder.currency,
          name: "ShopEase",
          description: "Purchase",
          order_id: payOrder.id,
          handler: async (response: any) => {
            createOrder.mutate({
              data: {
                addressId: selectedAddressId!,
                paymentMethod: "razorpay",
                couponCode: appliedCoupon?.code,
                razorpayOrderId: payOrder.id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature,
              },
            }, {
              onSuccess: (order: any) => {
                setLocation(`/order-success?orderId=${order.id}`);
              },
              onError: (err: any) => {
                toast({ title: "Order failed after payment", description: err.message, variant: "destructive" });
                setProcessing(false);
              },
            });
          },
          prefill: { name: user?.name, email: user?.email, contact: user?.phone },
          theme: { color: "#f97316" },
          modal: { ondismiss: () => setProcessing(false) },
        };
        const rzp = new window.Razorpay(options);
        rzp.open();
      },
      onError: (err: any) => {
        toast({ title: "Payment initialization failed", description: err.message, variant: "destructive" });
        setProcessing(false);
      },
    });
  };

  const typeIcon = (t: string) => {
    if (t === "Work") return <Briefcase className="w-3.5 h-3.5" />;
    if (t === "Other") return <Building className="w-3.5 h-3.5" />;
    return <Home className="w-3.5 h-3.5" />;
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-4 py-4 pb-28 sm:pb-8">
      <h1 className="text-lg font-bold mb-4">Checkout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          {/* Delivery Address */}
          <div className="bg-white rounded-xl border border-border p-4">
            <h2 className="text-sm font-semibold mb-3 flex items-center gap-1.5"><MapPin className="w-4 h-4 text-primary" /> Delivery Address</h2>

            {addressesLoading ? (
              <Skeleton className="h-20 rounded-lg" />
            ) : (
              <div className="space-y-2">
                {addresses?.map((addr) => (
                  <button
                    key={addr.id}
                    onClick={() => setSelectedAddressId(addr.id)}
                    className={`w-full text-left p-3 rounded-lg border-2 transition-all ${
                      selectedAddressId === addr.id ? "border-primary bg-primary/5" : "border-border hover:border-primary/30"
                    }`}
                    data-testid={`address-${addr.id}`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5 mb-0.5">
                          {typeIcon(addr.type)}
                          <span className="text-xs font-semibold">{addr.type}</span>
                          {addr.isDefault && <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded font-medium">Default</span>}
                        </div>
                        <p className="text-sm font-medium">{addr.name} · {addr.phone}</p>
                        <p className="text-xs text-muted-foreground">
                          {addr.addressLine1}{addr.addressLine2 ? `, ${addr.addressLine2}` : ""}<br />
                          {addr.city}, {addr.state} - {addr.pincode}
                          {addr.landmark && ` · ${addr.landmark}`}
                        </p>
                      </div>
                      {selectedAddressId === addr.id && (
                        <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                    </div>
                  </button>
                ))}

                <button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="w-full flex items-center gap-2 p-3 rounded-lg border-2 border-dashed border-border hover:border-primary/50 text-sm text-muted-foreground hover:text-primary transition-all"
                  data-testid="btn-add-address"
                >
                  <Plus className="w-4 h-4" /> Add New Address
                </button>
              </div>
            )}

            {/* Add address form */}
            {showAddForm && (
              <form onSubmit={handleSaveAddress} className="mt-4 space-y-3 border-t pt-4">
                {/* Location detect button */}
                <div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="mb-3 text-xs gap-1.5"
                    onClick={detectLocation}
                    disabled={locating}
                    data-testid="btn-detect-location"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    {locating ? "Detecting..." : "Detect My Location"}
                  </Button>
                  {detectedLocation && (
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg text-xs text-green-700 mb-2">
                      <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>
                        {detectedLocation.city && detectedLocation.state
                          ? `${detectedLocation.city}, ${detectedLocation.state}`
                          : `Lat: ${detectedLocation.lat.toFixed(4)}, Lng: ${detectedLocation.lng.toFixed(4)}`}
                      </span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground">Full Name *</label>
                    <Input value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} required className="h-9 text-sm mt-1" placeholder="Your Name" data-testid="input-address-name" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground">Phone *</label>
                    <Input value={form.phone} onChange={e => setForm(f => ({...f, phone: e.target.value}))} required className="h-9 text-sm mt-1" placeholder="+91 99999 99999" data-testid="input-address-phone" />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-muted-foreground">Address Line 1 *</label>
                  <Input value={form.addressLine1} onChange={e => setForm(f => ({...f, addressLine1: e.target.value}))} required className="h-9 text-sm mt-1" placeholder="Flat/House No, Street" data-testid="input-address-line1" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground">Address Line 2</label>
                  <Input value={form.addressLine2} onChange={e => setForm(f => ({...f, addressLine2: e.target.value}))} className="h-9 text-sm mt-1" placeholder="Area, Colony (optional)" data-testid="input-address-line2" />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground">City *</label>
                    <Input value={form.city} onChange={e => setForm(f => ({...f, city: e.target.value}))} required className="h-9 text-sm mt-1" placeholder="City" data-testid="input-address-city" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground">State *</label>
                    <Input value={form.state} onChange={e => setForm(f => ({...f, state: e.target.value}))} required className="h-9 text-sm mt-1" placeholder="State" data-testid="input-address-state" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground">Pincode *</label>
                    <Input value={form.pincode} onChange={e => setForm(f => ({...f, pincode: e.target.value}))} required className="h-9 text-sm mt-1" placeholder="000000" data-testid="input-address-pincode" />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-muted-foreground">Landmark</label>
                  <Input value={form.landmark} onChange={e => setForm(f => ({...f, landmark: e.target.value}))} className="h-9 text-sm mt-1" placeholder="Near landmark (optional)" data-testid="input-address-landmark" />
                </div>

                <div>
                  <label className="text-xs font-medium text-muted-foreground">Address Type</label>
                  <div className="flex gap-2 mt-1">
                    {["Home", "Work", "Other"].map(t => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setForm(f => ({...f, type: t}))}
                        className={`flex-1 h-8 text-xs rounded-lg border transition-all ${form.type === t ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary/50"}`}
                        data-testid={`btn-type-${t.toLowerCase()}`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 pt-1">
                  <Button type="submit" size="sm" className="flex-1" disabled={createAddress.isPending} data-testid="btn-save-address">
                    {createAddress.isPending ? "Saving..." : "Save Address"}
                  </Button>
                  <Button type="button" size="sm" variant="outline" onClick={() => setShowAddForm(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            )}
          </div>

          {/* Payment Method */}
          <div className="bg-white rounded-xl border border-border p-4">
            <h2 className="text-sm font-semibold mb-3">Payment Method</h2>
            <div className="space-y-2">
              <button
                onClick={() => setPaymentMethod("razorpay")}
                className={`w-full flex items-center gap-3 p-3 rounded-lg border-2 transition-all text-left ${paymentMethod === "razorpay" ? "border-primary bg-primary/5" : "border-border"}`}
                data-testid="btn-payment-razorpay"
              >
                <div className={`w-4 h-4 rounded-full border-2 ${paymentMethod === "razorpay" ? "border-primary bg-primary" : "border-gray-300"} flex items-center justify-center flex-shrink-0`}>
                  {paymentMethod === "razorpay" && <div className="w-2 h-2 rounded-full bg-white" />}
                </div>
                <div>
                  <p className="text-sm font-medium">Online Payment</p>
                  <p className="text-xs text-muted-foreground">Cards, UPI, NetBanking via Razorpay</p>
                </div>
              </button>
              <button
                onClick={() => setPaymentMethod("cod")}
                className={`w-full flex items-center gap-3 p-3 rounded-lg border-2 transition-all text-left ${paymentMethod === "cod" ? "border-primary bg-primary/5" : "border-border"}`}
                data-testid="btn-payment-cod"
              >
                <div className={`w-4 h-4 rounded-full border-2 ${paymentMethod === "cod" ? "border-primary bg-primary" : "border-gray-300"} flex items-center justify-center flex-shrink-0`}>
                  {paymentMethod === "cod" && <div className="w-2 h-2 rounded-full bg-white" />}
                </div>
                <div>
                  <p className="text-sm font-medium">Cash on Delivery</p>
                  <p className="text-xs text-muted-foreground">Pay when you receive your order</p>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="space-y-3">
          {/* Coupon */}
          <div className="bg-white rounded-xl border border-border p-4">
            <h3 className="text-sm font-semibold mb-2">Apply Coupon</h3>
            {appliedCoupon ? (
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold bg-green-100 text-green-700 px-2 py-0.5 rounded">{appliedCoupon.code}</span>
                <button onClick={() => setAppliedCoupon(null)} className="text-xs text-destructive">Remove</button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Input
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="Coupon code"
                  className="h-8 text-xs"
                  data-testid="input-checkout-coupon"
                />
                <Button size="sm" variant="outline" className="h-8 text-xs flex-shrink-0" onClick={() => validateCoupon.mutate({ data: { code: couponCode, cartTotal: cart?.subtotal || 0 } })} disabled={validateCoupon.isPending} data-testid="btn-checkout-apply-coupon">
                  Apply
                </Button>
              </div>
            )}
          </div>

          {/* Summary */}
          {cart && (
            <div className="bg-white rounded-xl border border-border p-4 space-y-2">
              <h3 className="text-sm font-semibold mb-3">Order Summary</h3>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>Rs.{cart.subtotal.toLocaleString()}</span>
              </div>
              {appliedCoupon && (
                <div className="flex justify-between text-sm text-green-600">
                  <span>Coupon discount</span>
                  <span>-Rs.{appliedCoupon.discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Delivery</span>
                <span className={cart.deliveryFee === 0 ? "text-green-600 font-medium" : ""}>{cart.deliveryFee === 0 ? "FREE" : `Rs.${cart.deliveryFee}`}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold">
                <span>Total</span>
                <span data-testid="checkout-total">Rs.{getTotal().toFixed(0)}</span>
              </div>
            </div>
          )}

          <Button
            className="w-full h-12 font-semibold text-base"
            onClick={handlePayment}
            disabled={processing || !selectedAddressId || !cart || cart.items.length === 0}
            data-testid="btn-pay-now"
          >
            {processing ? "Processing..." : paymentMethod === "cod" ? "Place Order" : "Pay Now"}
            {!processing && <ChevronRight className="w-4 h-4 ml-1" />}
          </Button>
          <p className="text-[10px] text-center text-muted-foreground">Secured by Razorpay · 256-bit SSL encryption</p>
        </div>
      </div>
    </div>
  );
}
