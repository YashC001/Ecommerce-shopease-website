import { useEffect, useRef, useState, useCallback } from "react";
import { Link, useLocation } from "wouter";
import { Heart, MessageCircle, Share2, ShoppingCart, Bookmark, X, Send, Volume2, VolumeX, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useAddToCart, useAddToWishlist, getGetCartQueryKey, getGetWishlistQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

interface ReelProduct {
  id: number;
  name: string;
  slug: string;
  price: string;
  originalPrice: string | null;
  images: string[];
  stock: number;
}

interface Reel {
  id: number;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string | null;
  productId: number | null;
  likeCount: number;
  commentCount: number;
  viewCount: number;
  shareCount: number;
  product: ReelProduct | null;
  isLiked: boolean;
}

interface Comment {
  id: number;
  text: string;
  createdAt: string;
  user: { id: number; name: string; avatar: string | null };
}

const BASE = `${import.meta.env.BASE_URL}api`;
const PAGE_SIZE = 6;

function authHeaders(): HeadersInit {
  const token = localStorage.getItem("auth_token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export default function ReelsViewerPage({ initialId }: { initialId?: number } = {}) {
  const [, navigate] = useLocation();
  const [reels, setReels] = useState<Reel[]>([]);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);
  const [muted, setMuted] = useState(true);
  const [commentsOpen, setCommentsOpen] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<Map<number, HTMLDivElement>>(new Map());
  const videoRefs = useRef<Map<number, HTMLVideoElement>>(new Map());
  const viewedReels = useRef<Set<number>>(new Set());

  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return;
    setLoading(true);
    try {
      const offset = reels.length;
      const res = await fetch(`${BASE}/reels?limit=${PAGE_SIZE}&offset=${offset}`, { headers: authHeaders() });
      const data: Reel[] = await res.json();
      if (!Array.isArray(data) || data.length === 0) {
        setHasMore(false);
      } else {
        setReels((prev) => {
          const ids = new Set(prev.map((r) => r.id));
          const merged = [...prev];
          for (const r of data) if (!ids.has(r.id)) merged.push(r);
          return merged;
        });
        if (data.length < PAGE_SIZE) setHasMore(false);
      }
    } finally {
      setLoading(false);
    }
  }, [loading, hasMore, reels.length]);

  useEffect(() => {
    loadMore();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Once reels load, scroll to initialId if provided
  useEffect(() => {
    if (!initialId || reels.length === 0) return;
    const el = itemRefs.current.get(initialId);
    if (el) el.scrollIntoView({ behavior: "auto" });
  }, [initialId, reels.length]);

  // Intersection observer to detect active reel & infinite scroll
  useEffect(() => {
    const root = containerRef.current;
    if (!root) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          const idx = Number((entry.target as HTMLElement).dataset.idx);
          const reel = reels[idx];
          if (!reel) continue;
          const video = videoRefs.current.get(reel.id);
          if (entry.isIntersecting && entry.intersectionRatio > 0.6) {
            setActiveIdx(idx);
            video?.play().catch(() => {});
            // Increment view once per session
            if (!viewedReels.current.has(reel.id)) {
              viewedReels.current.add(reel.id);
              fetch(`${BASE}/reels/${reel.id}/view`, { method: "POST" }).catch(() => {});
            }
            // Trigger infinite scroll near end
            if (idx >= reels.length - 2 && hasMore && !loading) {
              loadMore();
            }
          } else {
            video?.pause();
          }
        }
      },
      { root, threshold: [0, 0.6, 1] },
    );

    itemRefs.current.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [reels, hasMore, loading, loadMore]);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-3 bg-gradient-to-b from-black/60 to-transparent">
        <button
          onClick={() => navigate("/")}
          className="text-white p-2 rounded-full bg-black/30 backdrop-blur-sm"
          data-testid="button-close-reels"
        >
          <X className="h-5 w-5" />
        </button>
        <h1 className="text-white font-bold text-base">Reels</h1>
        <button
          onClick={() => setMuted((m) => !m)}
          className="text-white p-2 rounded-full bg-black/30 backdrop-blur-sm"
          data-testid="button-toggle-mute"
        >
          {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
        </button>
      </div>

      <div
        ref={containerRef}
        className="flex-1 overflow-y-scroll snap-y snap-mandatory"
        style={{ scrollSnapType: "y mandatory" }}
      >
        {reels.map((reel, idx) => (
          <ReelItem
            key={reel.id}
            reel={reel}
            idx={idx}
            muted={muted}
            isActive={activeIdx === idx}
            onLikeChange={(liked) => {
              setReels((prev) =>
                prev.map((r) =>
                  r.id === reel.id
                    ? { ...r, isLiked: liked, likeCount: r.likeCount + (liked ? 1 : -1) }
                    : r,
                ),
              );
            }}
            onCommentClick={() => setCommentsOpen(reel.id)}
            onCommentAdded={() => {
              setReels((prev) => prev.map((r) => (r.id === reel.id ? { ...r, commentCount: r.commentCount + 1 } : r)));
            }}
            registerEl={(el) => {
              if (el) itemRefs.current.set(reel.id, el);
              else itemRefs.current.delete(reel.id);
            }}
            registerVideo={(el) => {
              if (el) videoRefs.current.set(reel.id, el);
              else videoRefs.current.delete(reel.id);
            }}
          />
        ))}
        {loading && (
          <div className="h-full snap-start flex items-center justify-center text-white/70">Loading more reels...</div>
        )}
        {!hasMore && reels.length === 0 && (
          <div className="h-full snap-start flex items-center justify-center text-white/70">No reels yet.</div>
        )}
      </div>

      {commentsOpen !== null && (
        <CommentsSheet reelId={commentsOpen} onClose={() => setCommentsOpen(null)} />
      )}
    </div>
  );
}

function ReelItem({
  reel,
  idx,
  muted,
  isActive,
  onLikeChange,
  onCommentClick,
  onCommentAdded: _onCommentAdded,
  registerEl,
  registerVideo,
}: {
  reel: Reel;
  idx: number;
  muted: boolean;
  isActive: boolean;
  onLikeChange: (liked: boolean) => void;
  onCommentClick: () => void;
  onCommentAdded: () => void;
  registerEl: (el: HTMLDivElement | null) => void;
  registerVideo: (el: HTMLVideoElement | null) => void;
}) {
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const [showFullDesc, setShowFullDesc] = useState(false);
  const videoElRef = useRef<HTMLVideoElement | null>(null);

  const addToCart = useAddToCart({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        toast({ title: "Added to cart" });
      },
      onError: () => toast({ title: "Failed to add to cart", variant: "destructive" }),
    },
  });

  const addToWishlist = useAddToWishlist({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
        toast({ title: "Added to wishlist" });
      },
      onError: () => toast({ title: "Failed to add to wishlist", variant: "destructive" }),
    },
  });

  const handleLike = async () => {
    if (!isAuthenticated) {
      toast({ title: "Sign in to like reels" });
      navigate("/login");
      return;
    }
    const res = await fetch(`${BASE}/reels/${reel.id}/like`, { method: "POST", headers: authHeaders() });
    if (res.ok) {
      const data = await res.json();
      onLikeChange(!!data.liked);
    }
  };

  const handleShare = async () => {
    const url = `${window.location.origin}${import.meta.env.BASE_URL}reels/${reel.id}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: reel.title || "Check out this reel", url });
      } else {
        await navigator.clipboard.writeText(url);
        toast({ title: "Link copied to clipboard" });
      }
      fetch(`${BASE}/reels/${reel.id}/share`, { method: "POST" }).catch(() => {});
    } catch {
      // user cancelled
    }
  };

  const handleAddToCart = () => {
    if (!reel.product) return;
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    addToCart.mutate({ data: { productId: reel.product.id, quantity: 1 } });
  };

  const handleAddToWishlist = () => {
    if (!reel.product) return;
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    addToWishlist.mutate({ data: { productId: reel.product.id } });
  };

  const handleBuyNow = () => {
    if (!reel.product) return;
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    addToCart.mutate(
      { data: { productId: reel.product.id, quantity: 1 } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
          navigate("/checkout");
        },
      },
    );
  };

  const togglePlayPause = () => {
    const v = videoElRef.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => {});
    else v.pause();
  };

  return (
    <div
      ref={registerEl}
      data-idx={idx}
      className="relative w-full h-full snap-start snap-always flex items-center justify-center"
      style={{ height: "100dvh" }}
    >
      <video
        ref={(el) => {
          videoElRef.current = el;
          registerVideo(el);
        }}
        src={reel.videoUrl}
        poster={reel.thumbnailUrl ?? undefined}
        className="w-full h-full object-contain bg-black"
        loop
        muted={muted}
        playsInline
        preload={isActive ? "auto" : "metadata"}
        onClick={togglePlayPause}
      />

      {/* Right action rail */}
      <div className="absolute right-2 bottom-32 flex flex-col items-center gap-4 text-white">
        <button onClick={handleLike} className="flex flex-col items-center" data-testid={`button-like-${reel.id}`}>
          <div className="bg-black/30 backdrop-blur-sm rounded-full p-2.5">
            <Heart className={`h-6 w-6 ${reel.isLiked ? "fill-red-500 text-red-500" : ""}`} />
          </div>
          <span className="text-xs mt-1 font-medium">{reel.likeCount}</span>
        </button>
        <button onClick={onCommentClick} className="flex flex-col items-center" data-testid={`button-comment-${reel.id}`}>
          <div className="bg-black/30 backdrop-blur-sm rounded-full p-2.5">
            <MessageCircle className="h-6 w-6" />
          </div>
          <span className="text-xs mt-1 font-medium">{reel.commentCount}</span>
        </button>
        <button onClick={handleShare} className="flex flex-col items-center" data-testid={`button-share-${reel.id}`}>
          <div className="bg-black/30 backdrop-blur-sm rounded-full p-2.5">
            <Share2 className="h-6 w-6" />
          </div>
          <span className="text-xs mt-1 font-medium">Share</span>
        </button>
        {reel.product && (
          <button onClick={handleAddToWishlist} className="flex flex-col items-center" data-testid={`button-wishlist-${reel.id}`}>
            <div className="bg-black/30 backdrop-blur-sm rounded-full p-2.5">
              <Bookmark className="h-6 w-6" />
            </div>
            <span className="text-xs mt-1 font-medium">Save</span>
          </button>
        )}
      </div>

      {/* Bottom info & product card */}
      <div className="absolute left-0 right-0 bottom-0 p-3 pb-6 bg-gradient-to-t from-black/85 via-black/40 to-transparent text-white">
        <div className="pr-16">
          {reel.title && <div className="font-semibold text-sm mb-1">{reel.title}</div>}
          {reel.description && (
            <div
              className={`text-xs opacity-90 ${showFullDesc ? "" : "line-clamp-2"}`}
              onClick={() => setShowFullDesc((v) => !v)}
            >
              {reel.description}
            </div>
          )}
        </div>

        {reel.product && (
          <div className="mt-3 bg-white text-gray-900 rounded-xl p-2.5 flex items-center gap-2.5 shadow-lg">
            <Link href={`/products/${reel.product.id}`} className="flex-shrink-0">
              <img
                src={reel.product.images?.[0]}
                alt={reel.product.name}
                className="w-12 h-12 rounded-lg object-cover bg-gray-100"
              />
            </Link>
            <Link href={`/products/${reel.product.id}`} className="flex-1 min-w-0">
              <div className="text-xs font-medium line-clamp-1">{reel.product.name}</div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="font-bold text-sm">Rs. {parseFloat(reel.product.price).toLocaleString("en-IN")}</span>
                {reel.product.originalPrice && parseFloat(reel.product.originalPrice) > parseFloat(reel.product.price) && (
                  <span className="text-[10px] text-gray-500 line-through">
                    Rs. {parseFloat(reel.product.originalPrice).toLocaleString("en-IN")}
                  </span>
                )}
              </div>
            </Link>
            <div className="flex flex-col gap-1.5 flex-shrink-0">
              <button
                onClick={handleBuyNow}
                disabled={reel.product.stock === 0 || addToCart.isPending}
                className="bg-orange-500 hover:bg-orange-600 disabled:bg-gray-300 text-white text-[11px] font-bold px-3 py-1.5 rounded-full inline-flex items-center gap-1"
                data-testid={`button-buy-now-${reel.id}`}
              >
                <Zap className="h-3 w-3" /> Buy Now
              </button>
              <button
                onClick={handleAddToCart}
                disabled={reel.product.stock === 0 || addToCart.isPending}
                className="border border-orange-500 text-orange-600 text-[11px] font-bold px-3 py-1.5 rounded-full inline-flex items-center gap-1"
                data-testid={`button-add-cart-${reel.id}`}
              >
                <ShoppingCart className="h-3 w-3" /> Add
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function CommentsSheet({ reelId, onClose }: { reelId: number; onClose: () => void }) {
  const { isAuthenticated, user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [comments, setComments] = useState<Comment[]>([]);
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetch(`${BASE}/reels/${reelId}/comments`)
      .then((r) => r.json())
      .then((d) => setComments(Array.isArray(d) ? d : []))
      .catch(() => {});
  }, [reelId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    if (!text.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch(`${BASE}/reels/${reelId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ text }),
      });
      if (res.ok) {
        const newComment: Comment = await res.json();
        setComments((c) => [newComment, ...c]);
        setText("");
      } else {
        toast({ title: "Failed to post comment", variant: "destructive" });
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50" />
      <div
        className="relative bg-white w-full max-w-md max-h-[70vh] rounded-t-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-3 border-b">
          <h3 className="font-bold">{comments.length} Comments</h3>
          <button onClick={onClose} className="p-1" data-testid="button-close-comments">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {comments.length === 0 ? (
            <p className="text-center text-sm text-gray-500 py-8">Be the first to comment</p>
          ) : (
            comments.map((c) => (
              <div key={c.id} className="flex gap-2">
                <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-xs font-bold text-orange-600 flex-shrink-0">
                  {c.user.name?.[0]?.toUpperCase() ?? "U"}
                </div>
                <div className="flex-1">
                  <div className="text-xs font-semibold">{c.user.name}</div>
                  <div className="text-sm">{c.text}</div>
                </div>
              </div>
            ))
          )}
        </div>
        <form onSubmit={handleSubmit} className="p-3 border-t flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-xs font-bold text-orange-600 flex-shrink-0">
            {(user?.name?.[0] ?? "U").toUpperCase()}
          </div>
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={isAuthenticated ? "Add a comment..." : "Sign in to comment"}
            className="flex-1 border rounded-full px-3 py-1.5 text-sm outline-none focus:border-orange-500"
            data-testid="input-comment-text"
          />
          <button
            type="submit"
            disabled={submitting || !text.trim()}
            className="bg-orange-500 disabled:bg-gray-300 text-white p-2 rounded-full"
            data-testid="button-submit-comment"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
