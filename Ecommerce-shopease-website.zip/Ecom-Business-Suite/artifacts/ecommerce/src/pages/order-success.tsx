import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import { CheckCircle, Download, ShoppingBag, Package, MapPin, Phone } from "lucide-react";
import { useGetOrder, useGetOrderBill, getGetOrderQueryKey, getGetOrderBillQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function OrderSuccessPage() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] || "");
  const orderId = parseInt(params.get("orderId") || "0", 10);

  const { data: order } = useGetOrder(orderId, {
    query: { enabled: !!orderId, queryKey: getGetOrderQueryKey(orderId) }
  });
  const { data: bill } = useGetOrderBill(orderId, {
    query: { enabled: !!orderId, queryKey: getGetOrderBillQueryKey(orderId) }
  });

  const handleDownloadBill = () => {
    if (!bill || !order) return;

    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Invoice - ${order.orderNumber}</title>
        <style>
          body { font-family: Arial, sans-serif; max-width: 600px; margin: 20px auto; padding: 20px; color: #333; }
          .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #f97316; padding-bottom: 16px; }
          .store-name { font-size: 24px; font-weight: bold; color: #f97316; }
          table { width: 100%; border-collapse: collapse; margin: 16px 0; }
          th { background: #f3f4f6; padding: 8px; text-align: left; font-size: 13px; }
          td { padding: 8px; border-bottom: 1px solid #e5e7eb; font-size: 13px; }
          .total { font-weight: bold; font-size: 15px; }
          .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
          @media print { button { display: none; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="store-name">${bill.storeName}</div>
          <div style="font-size:12px; color:#666; margin-top: 4px;">${bill.storeAddress}</div>
          <div style="font-size:12px; color:#666;">Phone: ${bill.storePhone} | Email: ${bill.storeEmail}</div>
          <div style="font-size:12px; color:#666;">GST: ${bill.gstNumber}</div>
        </div>
        <h2 style="font-size:16px; margin-bottom:4px;">TAX INVOICE</h2>
        <div style="font-size:13px; color:#666; margin-bottom:12px;">
          <strong>Order No:</strong> ${order.orderNumber}<br>
          <strong>Date:</strong> ${new Date(bill.billDate).toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" })}<br>
          <strong>Payment:</strong> ${order.paymentMethod.toUpperCase()}
        </div>
        <div style="background:#f9fafb; padding:10px; border-radius:8px; margin-bottom:12px; font-size:13px;">
          <strong>Deliver To:</strong><br>
          ${order.address.name} | ${order.address.phone}<br>
          ${order.address.addressLine1}${order.address.addressLine2 ? ", " + order.address.addressLine2 : ""}<br>
          ${order.address.city}, ${order.address.state} - ${order.address.pincode}
        </div>
        <table>
          <thead>
            <tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>
          </thead>
          <tbody>
            ${order.items.map((item: any) => `
              <tr>
                <td>${item.productName}</td>
                <td>${item.quantity}</td>
                <td>Rs.${item.price.toLocaleString()}</td>
                <td>Rs.${item.total.toLocaleString()}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
        <div style="text-align:right; margin-top:12px; font-size:13px;">
          <div>Subtotal: Rs.${order.subtotal.toLocaleString()}</div>
          ${order.discount > 0 ? `<div style="color:green">Discount: -Rs.${order.discount.toFixed(2)}</div>` : ""}
          <div>Delivery: ${order.deliveryFee === 0 ? "FREE" : "Rs." + order.deliveryFee}</div>
          <div class="total" style="font-size:15px; margin-top:6px; color:#f97316;">TOTAL: Rs.${order.total.toLocaleString()}</div>
        </div>
        <div class="footer">
          <p>Thank you for shopping with ${bill.storeName}!</p>
          <p>This is a computer-generated invoice and requires no signature.</p>
        </div>
        <div style="text-align:center; margin-top:16px;">
          <button onclick="window.print()" style="background:#f97316; color:white; border:none; padding:8px 20px; border-radius:6px; cursor:pointer; font-size:13px;">Print / Save PDF</button>
        </div>
      </body>
      </html>
    `);
    win.document.close();
  };

  return (
    <div className="max-w-lg mx-auto px-4 py-8 pb-24 text-center">
      {/* Success Animation */}
      <div className="mb-6">
        <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4 animate-bounce">
          <CheckCircle className="w-10 h-10 text-green-600" />
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-1">Order Placed!</h1>
        <p className="text-muted-foreground text-sm">Your order has been successfully placed</p>
      </div>

      {order ? (
        <>
          {/* Order Details */}
          <div className="bg-white rounded-xl border border-border p-4 mb-4 text-left">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-xs text-muted-foreground">Order Number</p>
                <p className="font-bold text-base" data-testid="text-order-number">{order.orderNumber}</p>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                order.status === "confirmed" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
              }`}>
                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
              </span>
            </div>

            {/* Items */}
            <div className="space-y-2 mb-3 border-b pb-3">
              {order.items.map((item: any) => (
                <div key={item.id} className="flex items-center gap-2 text-sm" data-testid={`order-item-${item.id}`}>
                  <img src={item.productImage || "https://placehold.co/40x40"} alt="" className="w-10 h-10 rounded-lg object-cover" />
                  <div className="flex-1 text-left">
                    <p className="font-medium line-clamp-1">{item.productName}</p>
                    <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                  </div>
                  <span className="font-medium">Rs.{item.total.toLocaleString()}</span>
                </div>
              ))}
            </div>

            {/* Delivery Address */}
            <div className="flex items-start gap-2 text-xs text-muted-foreground mb-3">
              <MapPin className="w-3.5 h-3.5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium text-foreground">{order.address.name}</p>
                <p>{order.address.addressLine1}, {order.address.city}, {order.address.state} - {order.address.pincode}</p>
              </div>
            </div>

            <div className="flex justify-between font-bold text-base border-t pt-3">
              <span>Total Paid</span>
              <span className="text-primary" data-testid="order-total">Rs.{order.total.toLocaleString()}</span>
            </div>

            {order.estimatedDelivery && (
              <div className="flex items-center gap-2 mt-3 text-xs text-green-600 bg-green-50 rounded-lg p-2">
                <Package className="w-3.5 h-3.5" />
                <span>Expected delivery by {new Date(order.estimatedDelivery).toLocaleDateString("en-IN", { weekday: "long", month: "short", day: "numeric" })}</span>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button
              className="w-full h-11 font-semibold"
              onClick={handleDownloadBill}
              variant="outline"
              data-testid="btn-download-bill"
            >
              <Download className="w-4 h-4 mr-2" /> Download Bill / Invoice
            </Button>

            <Link href="/">
              <Button className="w-full h-11 font-semibold" data-testid="btn-continue-shopping">
                <ShoppingBag className="w-4 h-4 mr-2" /> Continue Shopping
              </Button>
            </Link>

            <Link href="/orders" className="block">
              <Button variant="ghost" size="sm" className="w-full text-sm" data-testid="btn-view-orders">
                View All Orders
              </Button>
            </Link>
          </div>
        </>
      ) : (
        <div className="space-y-3">
          <Skeleton className="h-48 rounded-xl" />
          <Skeleton className="h-11 rounded-lg" />
        </div>
      )}
    </div>
  );
}
