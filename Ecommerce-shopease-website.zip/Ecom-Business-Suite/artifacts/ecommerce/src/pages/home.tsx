import { Link } from "wouter";
import { ChevronRight } from "lucide-react";
import { useSettings } from "@/hooks/useSettings";
import { useGetFeaturedProducts, useGetDealsProducts, useGetCategories, getGetFeaturedProductsQueryKey, getGetDealsProductsQueryKey, getGetCategoriesQueryKey } from "@workspace/api-client-react";
import { HeroCarousel } from "@/components/home/HeroCarousel";
import { ReelsCarousel } from "@/components/home/ReelsCarousel";
import { ProductCard } from "@/components/products/ProductCard";
import { Skeleton } from "@/components/ui/skeleton";

export default function HomePage() {
  const settings = useSettings();
  const footerBg = settings?.footerBg ?? "#111827";
  const footerTextColor = settings?.footerTextColor ?? "#9ca3af";
  const footerText = settings?.footerText ?? "Your trusted online shopping destination";
  const storeName = settings?.storeName ?? "ShopEase";
  const supportEmail = settings?.supportEmail ?? "support@shopease.com";
  const supportPhone = settings?.supportPhone ?? "+91 98765 43210";

  const { data: featured, isLoading: featuredLoading } = useGetFeaturedProducts({
    query: { queryKey: getGetFeaturedProductsQueryKey() }
  });
  const { data: deals, isLoading: dealsLoading } = useGetDealsProducts({
    query: { queryKey: getGetDealsProductsQueryKey() }
  });
  const { data: categories } = useGetCategories({
    query: { queryKey: getGetCategoriesQueryKey() }
  });

  return (
    <div className="pb-20 sm:pb-6">
      {/* Category chips */}
      <div className="bg-white border-b border-border px-3 sm:px-4 py-2">
        <div className="flex gap-2 overflow-x-auto no-scrollbar max-w-7xl mx-auto">
          <Link href="/products">
            <button className="flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium bg-primary text-primary-foreground whitespace-nowrap">
              All Products
            </button>
          </Link>
          {categories?.map((cat) => (
            <Link key={cat.id} href={`/products?categoryId=${cat.id}`}>
              <button className="flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium bg-muted hover:bg-accent hover:text-accent-foreground transition-colors whitespace-nowrap" data-testid={`category-chip-${cat.id}`}>
                {cat.name}
              </button>
            </Link>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-3 sm:px-4 space-y-6 mt-4">
        {/* Hero Carousel */}
        <HeroCarousel />

        {/* Reels */}
        <ReelsCarousel />

        {/* Today's Deals */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-foreground">Today's Deals</h2>
              <p className="text-xs text-muted-foreground">Limited time offers</p>
            </div>
            <Link href="/products?sort=discount" className="flex items-center text-primary text-xs font-medium hover:underline" data-testid="link-see-all-deals">
              See all <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
            {dealsLoading
              ? Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex-shrink-0 w-40 sm:w-44">
                    <Skeleton className="aspect-square rounded-xl mb-2" />
                    <Skeleton className="h-3 w-3/4 mb-1 rounded" />
                    <Skeleton className="h-4 w-1/2 rounded" />
                  </div>
                ))
              : deals?.map((product) => (
                  <div key={product.id} className="flex-shrink-0 w-40 sm:w-44">
                    <ProductCard product={product} />
                  </div>
                ))}
          </div>
        </section>

        {/* Categories */}
        {categories && categories.length > 0 && (
          <section>
            <h2 className="text-base sm:text-lg font-bold mb-3 text-foreground">Shop by Category</h2>
            <div className="grid grid-cols-4 sm:grid-cols-4 md:grid-cols-8 gap-2 sm:gap-3">
              {categories.map((cat) => (
                <Link key={cat.id} href={`/products?categoryId=${cat.id}`} data-testid={`category-grid-${cat.id}`}>
                  <div className="flex flex-col items-center gap-1.5 p-2 rounded-xl hover:bg-accent transition-colors cursor-pointer">
                    <div className="w-11 h-11 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-muted">
                      <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[10px] sm:text-xs font-medium text-center leading-tight line-clamp-2">{cat.name}</span>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Featured Products */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-foreground">Featured Products</h2>
              <p className="text-xs text-muted-foreground">Handpicked for you</p>
            </div>
            <Link href="/products?featured=true" className="flex items-center text-primary text-xs font-medium hover:underline" data-testid="link-see-all-featured">
              See all <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {featuredLoading
              ? Array.from({ length: 6 }).map((_, i) => (
                  <div key={i}>
                    <Skeleton className="aspect-square rounded-xl mb-2" />
                    <Skeleton className="h-3 w-3/4 mb-1 rounded" />
                    <Skeleton className="h-4 w-1/2 rounded" />
                  </div>
                ))
              : featured?.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
          </div>
        </section>

        {/* Offer Banner */}
        <div className="rounded-xl overflow-hidden bg-gradient-to-r from-indigo-600 to-purple-600 p-5 text-white text-center">
          <p className="text-xs font-semibold uppercase tracking-widest mb-1 text-white/80">Special Offer</p>
          <h3 className="text-lg sm:text-xl font-bold mb-1">Get 10% Off Your First Order</h3>
          <p className="text-sm text-white/90 mb-3">Use code <span className="font-bold bg-white/20 px-2 py-0.5 rounded">WELCOME10</span> at checkout</p>
          <Link href="/products">
            <button className="bg-white text-indigo-700 font-semibold px-5 py-2 rounded-full text-sm hover:bg-gray-100 transition-colors" data-testid="offer-banner-cta">
              Shop Now
            </button>
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer
        className="mt-8 text-xs"
        style={{ backgroundColor: footerBg, color: footerTextColor }}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-4 pt-8 pb-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mb-6">
            <div>
              <h4 className="font-semibold mb-2" style={{ color: "#fff" }}>{storeName}</h4>
              <p>{footerText}</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2" style={{ color: "#fff" }}>Customer Service</h4>
              <ul className="space-y-1.5">
                <li>Help Center</li>
                <li>Return Policy</li>
                <li>Track Order</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2" style={{ color: "#fff" }}>Quick Links</h4>
              <ul className="space-y-1.5">
                <li><Link href="/products" className="hover:opacity-80">All Products</Link></li>
                <li><Link href="/orders" className="hover:opacity-80">My Orders</Link></li>
                <li><Link href="/profile" className="hover:opacity-80">My Profile</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2" style={{ color: "#fff" }}>Contact</h4>
              <ul className="space-y-1.5">
                <li>{supportEmail}</li>
                <li>{supportPhone}</li>
                <li>Mon–Sat 9am–6pm</li>
              </ul>
            </div>
          </div>
          <div className="text-center py-3 border-t" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
            © {new Date().getFullYear()} {storeName}. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
