import { useEffect, useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { adminFetch } from "@/lib/admin-api";
import { useToast } from "@/hooks/use-toast";
import { Eye } from "lucide-react";

interface OrderUser {
  id: number;
  name: string;
  email: string;
  phone: string;
}

interface OrderItem {
  productId?: number;
  name: string;
  price: string | number;
  quantity: number;
  image?: string;
}

interface AddressSnapshot {
  name?: string;
  phone?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  pincode?: string;
}

interface Order {
  id: number;
  orderNumber: string;
  status: string;
  paymentStatus: string;
  paymentMethod: string;
  total: string;
  subtotal: string;
  discount: string;
  deliveryFee: string;
  itemsSnapshot: OrderItem[];
  addressSnapshot: AddressSnapshot;
  createdAt: string;
  user: OrderUser | null;
}

const STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled"];
const PAYMENT_STATUSES = ["pending", "paid", "failed", "refunded"];

const statusColor = (s: string) => {
  switch (s) {
    case "pending": return "bg-yellow-100 text-yellow-700";
    case "confirmed": return "bg-blue-100 text-blue-700";
    case "shipped": return "bg-indigo-100 text-indigo-700";
    case "delivered": return "bg-green-100 text-green-700";
    case "cancelled": return "bg-red-100 text-red-700";
    case "paid": return "bg-green-100 text-green-700";
    case "failed": return "bg-red-100 text-red-700";
    default: return "bg-gray-100 text-gray-700";
  }
};

export default function AdminOrders() {
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [viewing, setViewing] = useState<Order | null>(null);

  const load = () => {
    const q = filter !== "all" ? `?status=${filter}` : "";
    adminFetch<Order[]>(`/admin/orders${q}`).then(setOrders).catch(() => {});
  };

  useEffect(load, [filter]);

  const updateOrder = async (id: number, updates: Partial<Order>) => {
    try {
      await adminFetch(`/admin/orders/${id}`, {
        method: "PUT",
        body: JSON.stringify(updates),
      });
      toast({ title: "Order updated" });
      load();
      if (viewing?.id === id) {
        setViewing({ ...viewing, ...updates });
      }
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Orders</h1>
          <p className="text-gray-500 text-sm">{orders.length} orders</p>
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-44">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {STATUSES.map((s) => (
              <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr className="text-left text-gray-600">
                <th className="px-4 py-3">Order #</th>
                <th className="px-4 py-3 hidden md:table-cell">Customer</th>
                <th className="px-4 py-3">Total</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 hidden sm:table-cell">Payment</th>
                <th className="px-4 py-3 hidden lg:table-cell">Date</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium">{o.orderNumber}</td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <div className="text-gray-900">{o.user?.name ?? "—"}</div>
                    <div className="text-xs text-gray-500">{o.user?.phone}</div>
                  </td>
                  <td className="px-4 py-3 font-medium">
                    Rs. {parseFloat(o.total).toLocaleString("en-IN")}
                  </td>
                  <td className="px-4 py-3">
                    <Select value={o.status} onValueChange={(v) => updateOrder(o.id, { status: v })}>
                      <SelectTrigger className={`w-32 h-8 text-xs ${statusColor(o.status)}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STATUSES.map((s) => (
                          <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className={`px-2 py-0.5 rounded text-xs font-medium capitalize ${statusColor(o.paymentStatus)}`}>
                      {o.paymentStatus}
                    </span>
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell text-gray-500">
                    {new Date(o.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => setViewing(o)}
                      className="p-2 hover:bg-gray-100 rounded text-gray-600"
                      data-testid={`button-view-order-${o.id}`}
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center text-gray-500 py-8">No orders found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Dialog open={!!viewing} onOpenChange={(o) => !o && setViewing(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Order {viewing?.orderNumber}</DialogTitle>
          </DialogHeader>
          {viewing && (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-gray-500">Customer</div>
                  <div className="font-medium">{viewing.user?.name}</div>
                  <div className="text-xs text-gray-500">{viewing.user?.email}</div>
                  <div className="text-xs text-gray-500">{viewing.user?.phone}</div>
                </div>
                <div>
                  <div className="text-gray-500">Date</div>
                  <div className="font-medium">{new Date(viewing.createdAt).toLocaleString("en-IN")}</div>
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="text-gray-500 mb-1">Delivery Address</div>
                <div className="font-medium">{viewing.addressSnapshot.name}</div>
                <div className="text-gray-700">
                  {viewing.addressSnapshot.addressLine1}
                  {viewing.addressSnapshot.addressLine2 && `, ${viewing.addressSnapshot.addressLine2}`}
                </div>
                <div className="text-gray-700">
                  {viewing.addressSnapshot.city}, {viewing.addressSnapshot.state} - {viewing.addressSnapshot.pincode}
                </div>
                <div className="text-gray-700">Phone: {viewing.addressSnapshot.phone}</div>
              </div>

              <div className="border-t pt-4">
                <div className="text-gray-500 mb-2">Items</div>
                <div className="space-y-2">
                  {viewing.itemsSnapshot.map((item, i) => (
                    <div key={i} className="flex items-center justify-between gap-3 bg-gray-50 p-2 rounded">
                      <div className="flex items-center gap-2 min-w-0">
                        {item.image && <img src={item.image} alt="" className="w-10 h-10 rounded object-cover" />}
                        <div className="min-w-0">
                          <div className="font-medium truncate">{item.name}</div>
                          <div className="text-xs text-gray-500">Qty: {item.quantity}</div>
                        </div>
                      </div>
                      <div className="font-medium">
                        Rs. {(parseFloat(String(item.price)) * item.quantity).toLocaleString("en-IN")}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4 space-y-1">
                <div className="flex justify-between"><span className="text-gray-500">Subtotal</span><span>Rs. {parseFloat(viewing.subtotal).toLocaleString("en-IN")}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Discount</span><span>- Rs. {parseFloat(viewing.discount).toLocaleString("en-IN")}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Delivery</span><span>Rs. {parseFloat(viewing.deliveryFee).toLocaleString("en-IN")}</span></div>
                <div className="flex justify-between font-semibold text-base pt-1 border-t">
                  <span>Total</span><span>Rs. {parseFloat(viewing.total).toLocaleString("en-IN")}</span>
                </div>
              </div>

              <div className="border-t pt-4 grid grid-cols-2 gap-3">
                <div>
                  <div className="text-gray-500 mb-1">Order Status</div>
                  <Select value={viewing.status} onValueChange={(v) => updateOrder(viewing.id, { status: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <div className="text-gray-500 mb-1">Payment Status</div>
                  <Select value={viewing.paymentStatus} onValueChange={(v) => updateOrder(viewing.id, { paymentStatus: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {PAYMENT_STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="text-xs text-gray-500">
                Payment Method: <span className="font-medium uppercase">{viewing.paymentMethod}</span>
              </div>

              <div className="flex justify-end pt-2">
                <Button variant="outline" onClick={() => setViewing(null)}>Close</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
