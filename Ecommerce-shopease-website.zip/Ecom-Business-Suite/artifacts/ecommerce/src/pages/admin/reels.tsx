import { useEffect, useMemo, useRef, useState } from "react";
import { Plus, Pencil, Trash2, Search, Video, Eye, Heart, MessageCircle, Link2, Play } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { adminFetch } from "@/lib/admin-api";
import { useToast } from "@/hooks/use-toast";

interface ProductLite {
  id: number;
  name: string;
  slug: string;
  price: string;
  images: string[];
}

interface Reel {
  id: number;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string | null;
  productId: number | null;
  likeCount: number;
  commentCount: number;
  viewCount: number;
  shareCount: number;
  isActive: boolean;
  sortOrder: number;
  product?: ProductLite | null;
}

const empty = {
  title: "",
  description: "",
  videoUrl: "",
  thumbnailUrl: "",
  productId: "",
  isActive: true,
  sortOrder: 0,
};

export default function AdminReels() {
  const { toast } = useToast();
  const [reels, setReels] = useState<Reel[]>([]);
  const [products, setProducts] = useState<ProductLite[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Reel | null>(null);
  const [form, setForm] = useState({ ...empty });

  const load = () => {
    adminFetch<Reel[]>("/admin/reels").then(setReels).catch(() => {});
  };

  useEffect(() => {
    load();
    adminFetch<{ products: ProductLite[] }>("/products").then((r) => setProducts(r.products ?? [])).catch(() => {});
  }, []);

  const startCreate = () => {
    setEditing(null);
    setForm({ ...empty });
    setOpen(true);
  };

  const startEdit = (r: Reel) => {
    setEditing(r);
    setForm({
      title: r.title,
      description: r.description,
      videoUrl: r.videoUrl,
      thumbnailUrl: r.thumbnailUrl ?? "",
      productId: r.productId ? String(r.productId) : "",
      isActive: r.isActive,
      sortOrder: r.sortOrder,
    });
    setOpen(true);
  };

  const handleSave = async () => {
    if (!form.videoUrl) {
      toast({ title: "Video URL is required", variant: "destructive" });
      return;
    }
    const payload = {
      title: form.title,
      description: form.description,
      videoUrl: form.videoUrl,
      thumbnailUrl: form.thumbnailUrl || null,
      productId: form.productId ? Number(form.productId) : null,
      isActive: form.isActive,
      sortOrder: Number(form.sortOrder) || 0,
    };
    try {
      if (editing) {
        await adminFetch(`/admin/reels/${editing.id}`, { method: "PUT", body: JSON.stringify(payload) });
      } else {
        await adminFetch("/admin/reels", { method: "POST", body: JSON.stringify(payload) });
      }
      toast({ title: editing ? "Reel updated" : "Reel created" });
      setOpen(false);
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleDelete = async (r: Reel) => {
    if (!confirm(`Delete reel "${r.title || `#${r.id}`}"?`)) return;
    try {
      await adminFetch(`/admin/reels/${r.id}`, { method: "DELETE" });
      toast({ title: "Reel deleted" });
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">vidview</h1>
          <p className="text-gray-500 text-sm">{reels.length} short videos · linked to products</p>
        </div>
        <Button onClick={startCreate} className="bg-orange-500 hover:bg-orange-600" data-testid="button-create-reel">
          <Plus className="h-4 w-4 mr-2" /> New Reel
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {reels.map((r) => (
          <div key={r.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <div className="relative aspect-[9/16] bg-gray-900">
              {r.thumbnailUrl ? (
                <img src={r.thumbnailUrl} alt="" className="w-full h-full object-cover" />
              ) : (
                <video src={r.videoUrl} className="w-full h-full object-cover" muted preload="metadata" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-center justify-center">
                <Play className="h-10 w-10 text-white/80" />
              </div>
              {!r.isActive && (
                <div className="absolute top-2 left-2 bg-red-500 text-white text-[10px] px-2 py-0.5 rounded">HIDDEN</div>
              )}
            </div>
            <div className="p-3">
              <div className="font-medium text-sm line-clamp-1">{r.title || `Reel #${r.id}`}</div>
              {r.product ? (
                <div className="text-xs text-gray-500 mt-0.5 flex items-center gap-1">
                  <Link2 className="h-3 w-3" /> <span className="truncate">{r.product.name}</span>
                </div>
              ) : (
                <div className="text-xs text-orange-600 mt-0.5">No product linked</div>
              )}
              <div className="flex items-center gap-3 text-xs text-gray-500 mt-2">
                <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> {r.viewCount}</span>
                <span className="flex items-center gap-1"><Heart className="h-3 w-3" /> {r.likeCount}</span>
                <span className="flex items-center gap-1"><MessageCircle className="h-3 w-3" /> {r.commentCount}</span>
              </div>
              <div className="flex gap-1 mt-3">
                <button onClick={() => startEdit(r)} className="flex-1 text-xs py-1.5 rounded bg-gray-100 hover:bg-gray-200 inline-flex items-center justify-center gap-1" data-testid={`button-edit-reel-${r.id}`}>
                  <Pencil className="h-3 w-3" /> Edit
                </button>
                <button onClick={() => handleDelete(r)} className="flex-1 text-xs py-1.5 rounded bg-red-50 hover:bg-red-100 text-red-600 inline-flex items-center justify-center gap-1" data-testid={`button-delete-reel-${r.id}`}>
                  <Trash2 className="h-3 w-3" /> Delete
                </button>
              </div>
            </div>
          </div>
        ))}
        {reels.length === 0 && (
          <div className="col-span-full text-center text-gray-500 py-16 bg-white rounded-xl border border-gray-200">
            <Video className="h-12 w-12 mx-auto text-gray-300 mb-3" />
            <p className="font-medium">No reels yet</p>
            <p className="text-sm">Click "New Reel" to add your first video</p>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Reel" : "New Reel"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Title</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Summer collection" />
            </div>
            <div>
              <Label>Video URL *</Label>
              <Input
                value={form.videoUrl}
                onChange={(e) => setForm({ ...form, videoUrl: e.target.value })}
                placeholder="https://example.com/video.mp4"
                data-testid="input-reel-video"
              />
              <p className="text-xs text-gray-500 mt-1">Direct .mp4 / .webm URL. For uploads use a CDN like Cloudinary/Mux.</p>
            </div>
            <div>
              <Label>Thumbnail URL (optional)</Label>
              <Input
                value={form.thumbnailUrl}
                onChange={(e) => setForm({ ...form, thumbnailUrl: e.target.value })}
                placeholder="https://example.com/thumb.jpg"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Caption shown under the video"
              />
            </div>
            <div>
              <Label>Linked Product (drives Add to Cart / Buy Now)</Label>
              <ProductPicker
                products={products}
                value={form.productId}
                onChange={(v) => setForm({ ...form, productId: v })}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Sort Order</Label>
                <Input
                  type="number"
                  value={form.sortOrder}
                  onChange={(e) => setForm({ ...form, sortOrder: Number(e.target.value) })}
                />
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.isActive}
                    onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                    className="w-4 h-4 accent-orange-500"
                  />
                  Active (visible to customers)
                </label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} className="bg-orange-500 hover:bg-orange-600" data-testid="button-save-reel">
              {editing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}

function ProductPicker({
  products,
  value,
  onChange,
}: {
  products: ProductLite[];
  value: string;
  onChange: (v: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const selected = products.find((p) => String(p.id) === value);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products.slice(0, 50);
    return products.filter((p) => p.name.toLowerCase().includes(q) || p.slug.toLowerCase().includes(q)).slice(0, 50);
  }, [query, products]);

  return (
    <div ref={ref} className="relative">
      <div
        onClick={() => setOpen(true)}
        className="border rounded px-3 py-2 cursor-text bg-white flex items-center gap-2"
        data-testid="product-picker"
      >
        <Search className="h-4 w-4 text-gray-400 flex-shrink-0" />
        {selected && !open ? (
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {selected.images?.[0] && <img src={selected.images[0]} alt="" className="w-6 h-6 rounded object-cover" />}
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{selected.name}</div>
              <div className="text-xs text-gray-500">Rs. {parseFloat(selected.price).toLocaleString("en-IN")}</div>
            </div>
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); onChange(""); setQuery(""); }}
              className="text-xs text-red-600 px-2"
            >
              Clear
            </button>
          </div>
        ) : (
          <input
            type="text"
            autoFocus={open}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={selected ? "Search to change product..." : "Search products by name..."}
            className="flex-1 outline-none text-sm bg-transparent"
            data-testid="input-product-search"
          />
        )}
      </div>
      {open && (
        <div className="absolute z-50 mt-1 w-full bg-white border rounded shadow-lg max-h-72 overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="px-3 py-4 text-sm text-gray-500 text-center">No products found</div>
          ) : (
            filtered.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => { onChange(String(p.id)); setOpen(false); setQuery(""); }}
                className={`w-full px-3 py-2 hover:bg-orange-50 flex items-center gap-2 text-left ${
                  String(p.id) === value ? "bg-orange-100" : ""
                }`}
                data-testid={`product-option-${p.id}`}
              >
                {p.images?.[0] ? (
                  <img src={p.images[0]} alt="" className="w-8 h-8 rounded object-cover flex-shrink-0" />
                ) : (
                  <div className="w-8 h-8 rounded bg-gray-100 flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{p.name}</div>
                  <div className="text-xs text-gray-500">Rs. {parseFloat(p.price).toLocaleString("en-IN")}</div>
                </div>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
