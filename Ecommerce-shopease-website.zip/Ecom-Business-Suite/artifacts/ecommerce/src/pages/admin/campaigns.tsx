import { useState } from "react";
import { Megaphone, MessageCircle, Mail, Send, Copy, Check } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { adminFetch } from "@/lib/admin-api";
import { useToast } from "@/hooks/use-toast";
import { useSettings } from "@/hooks/useSettings";

type Channel = "whatsapp" | "email" | "notification";

const TEMPLATES = [
  {
    label: "Flash Sale",
    title: "Flash Sale — Limited Time Only!",
    body: "🔥 Don't miss our exclusive flash sale! Up to 50% off on selected items. Shop now and save big. Offer ends today midnight!",
  },
  {
    label: "New Arrivals",
    title: "New Products Just Dropped!",
    body: "✨ Check out our latest arrivals — fresh styles, new categories, and best-in-class quality. Be the first to grab them!",
  },
  {
    label: "Discount Code",
    title: "Exclusive Offer for You",
    body: "🎁 Here's a special discount just for you! Use code SAVE20 to get 20% off your next order. Valid for 48 hours only.",
  },
  {
    label: "Order Reminder",
    title: "Items Left in Your Cart!",
    body: "🛒 You left some great items in your cart. Complete your order now before they sell out!",
  },
];

export default function AdminCampaigns() {
  const { toast } = useToast();
  const settings = useSettings();
  const [channel, setChannel] = useState<Channel>("whatsapp");
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [subject, setSubject] = useState("");
  const [copied, setCopied] = useState(false);
  const [sending, setSending] = useState(false);

  const applyTemplate = (t: (typeof TEMPLATES)[0]) => {
    setTitle(t.title);
    setMessage(t.body);
    setSubject(t.title);
  };

  const waNumber = settings?.whatsappNumber ?? "919876543210";
  const waLink = `https://wa.me/${waNumber}?text=${encodeURIComponent(message)}`;

  const copyWaLink = async () => {
    await navigator.clipboard.writeText(waLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "WhatsApp link copied!" });
  };

  const publishAsNotification = async () => {
    if (!title || !message) {
      toast({ title: "Title and message are required", variant: "destructive" });
      return;
    }
    setSending(true);
    try {
      await adminFetch("/admin/notifications", {
        method: "POST",
        body: JSON.stringify({ title, body: message, type: "offer" }),
      });
      toast({ title: "Notification published to all customers!" });
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Campaigns & Marketing</h1>
        <p className="text-gray-500 text-sm">
          Build promotional messages and send them via WhatsApp, Email, or in-app notifications
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Message builder */}
        <div className="lg:col-span-2 space-y-5">
          {/* Channel selector */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <Label className="mb-3 block">Choose Channel</Label>
            <div className="grid grid-cols-3 gap-3">
              {(
                [
                  { id: "whatsapp" as Channel, label: "WhatsApp", Icon: MessageCircle, color: "text-green-600 bg-green-50 border-green-200" },
                  { id: "email" as Channel, label: "Email", Icon: Mail, color: "text-blue-600 bg-blue-50 border-blue-200" },
                  { id: "notification" as Channel, label: "In-App", Icon: Megaphone, color: "text-orange-600 bg-orange-50 border-orange-200" },
                ] as const
              ).map(({ id, label, Icon, color }) => (
                <button
                  key={id}
                  onClick={() => setChannel(id)}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                    channel === id ? color : "border-gray-200 text-gray-500 hover:border-gray-300"
                  }`}
                >
                  <Icon className="h-6 w-6" />
                  <span className="text-sm font-medium">{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Message form */}
          <div className="bg-white rounded-xl border border-gray-200 p-5 space-y-4">
            <h2 className="font-semibold text-gray-900">Message</h2>

            {channel === "email" && (
              <div>
                <Label>Email Subject</Label>
                <Input
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Big Sale — Up to 50% off!"
                />
              </div>
            )}

            {channel !== "whatsapp" && (
              <div>
                <Label>Notification Title</Label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Short, attention-grabbing headline"
                />
              </div>
            )}

            <div>
              <Label>Message Body</Label>
              <Textarea
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Write your promotional message here..."
              />
              <p className="text-xs text-gray-400 mt-1">{message.length} characters</p>
            </div>

            {/* Actions */}
            {channel === "whatsapp" && (
              <div className="space-y-3">
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-xs font-medium text-green-700 mb-1">WhatsApp Share Link</p>
                  <p className="text-xs text-green-600 break-all font-mono">{waLink.slice(0, 80)}…</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={copyWaLink}
                    disabled={!message}
                  >
                    {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
                    {copied ? "Copied!" : "Copy Link"}
                  </Button>
                  <a
                    href={waLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex-1 ${!message ? "pointer-events-none opacity-50" : ""}`}
                  >
                    <Button variant="outline" className="w-full border-green-300 text-green-700">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Open WhatsApp
                    </Button>
                  </a>
                </div>
                <p className="text-xs text-gray-500">
                  Paste this link in your browser, WhatsApp Web, or share it with your team to send the campaign message from your WhatsApp Business number.
                </p>
              </div>
            )}

            {channel === "email" && (
              <div className="space-y-3">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-700">
                  <p className="font-medium mb-1">Email Marketing</p>
                  <p className="text-xs">
                    To send bulk emails, configure your SMTP credentials in your server environment variables
                    (<code className="bg-blue-100 px-1 rounded">SMTP_HOST</code>, <code className="bg-blue-100 px-1 rounded">SMTP_USER</code>, <code className="bg-blue-100 px-1 rounded">SMTP_PASS</code>).
                    Once configured, email campaigns will be sent to all registered customers.
                  </p>
                </div>
                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled
                >
                  <Send className="h-4 w-4 mr-2" /> Send Email Campaign (configure SMTP first)
                </Button>
              </div>
            )}

            {channel === "notification" && (
              <div className="space-y-2">
                <Button
                  className="w-full bg-orange-500 hover:bg-orange-600"
                  onClick={publishAsNotification}
                  disabled={sending || !title || !message}
                >
                  <Send className="h-4 w-4 mr-2" />
                  {sending ? "Publishing..." : "Publish to All Customers"}
                </Button>
                <p className="text-xs text-gray-500">
                  This will create a notification visible to all customers in the app immediately.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Right: Templates */}
        <div>
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="font-semibold text-gray-900 mb-4">Quick Templates</h2>
            <div className="space-y-2">
              {TEMPLATES.map((t) => (
                <button
                  key={t.label}
                  onClick={() => applyTemplate(t)}
                  className="w-full text-left p-3 rounded-lg border border-gray-200 hover:border-orange-300 hover:bg-orange-50 transition-all group"
                >
                  <div className="font-medium text-sm text-gray-900 group-hover:text-orange-700">
                    {t.label}
                  </div>
                  <div className="text-xs text-gray-500 line-clamp-2 mt-0.5">{t.body}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Preview */}
          {message && (
            <div className="mt-4 bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="font-semibold text-gray-900 mb-3 text-sm">Preview</h2>
              <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
                {title && <div className="font-semibold text-sm text-gray-900 mb-1">{title}</div>}
                <div className="text-xs text-gray-600 whitespace-pre-wrap">{message}</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
