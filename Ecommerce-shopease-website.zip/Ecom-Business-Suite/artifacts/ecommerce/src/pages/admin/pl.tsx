import { useEffect, useState } from "react";
import { TrendingUp, TrendingDown, IndianRupee, ShoppingBag, Percent } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { adminFetch } from "@/lib/admin-api";

interface PL {
  days: number;
  totalRevenue: string;
  totalCogs: string;
  grossProfit: string;
  margin: string;
  totalDiscount: string;
  totalDelivery: string;
  cancelledRevenue: string;
  orderCount: number;
  daily: Array<{ day: string; revenue: number; cogs: number; profit: number; orders: number }>;
  topProducts: Array<{ productId: number; name: string; qty: number; revenue: number; cogs: number; profit: number }>;
}

const formatRs = (v: string | number) => {
  const n = typeof v === "string" ? parseFloat(v) : v;
  return `Rs. ${n.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`;
};

export default function AdminPL() {
  const [pl, setPL] = useState<PL | null>(null);
  const [days, setDays] = useState("30");

  useEffect(() => {
    adminFetch<PL>(`/admin/pl?days=${days}`).then(setPL).catch(() => {});
  }, [days]);

  const maxVal = pl?.daily.length
    ? Math.max(...pl.daily.flatMap((d) => [d.revenue, d.cogs, d.profit]))
    : 1;

  const profitColor = pl && parseFloat(pl.grossProfit) >= 0 ? "text-green-600" : "text-red-600";
  const ProfitIcon = pl && parseFloat(pl.grossProfit) >= 0 ? TrendingUp : TrendingDown;

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Profit & Loss</h1>
          <p className="text-gray-500 text-sm">Set product costs to see accurate profit data</p>
        </div>
        <Select value={days} onValueChange={setDays}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
            <SelectItem value="365">Last year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!pl ? (
        <div className="text-gray-500">Loading...</div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <KPI label="Revenue" value={formatRs(pl.totalRevenue)} icon={IndianRupee} color="bg-green-500" />
            <KPI label="Cost of Goods" value={formatRs(pl.totalCogs)} icon={ShoppingBag} color="bg-red-500" />
            <KPI label="Gross Profit" value={formatRs(pl.grossProfit)} icon={ProfitIcon} color="bg-orange-500" valueClass={profitColor} />
            <KPI label="Margin" value={`${pl.margin}%`} icon={Percent} color="bg-indigo-500" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <SmallKPI label="Total Orders" value={String(pl.orderCount)} />
            <SmallKPI label="Total Discounts Given" value={formatRs(pl.totalDiscount)} />
            <SmallKPI label="Cancelled Revenue" value={formatRs(pl.cancelledRevenue)} />
          </div>

          {/* Chart */}
          <div className="bg-white rounded-xl border border-gray-200 p-5 mb-6">
            <h2 className="font-semibold text-gray-900 mb-4">Revenue vs Profit ({days} days)</h2>
            {pl.daily.length === 0 ? (
              <div className="text-center text-gray-500 py-12 text-sm">No data for this period</div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-end gap-1 h-56 overflow-x-auto">
                  {pl.daily.map((d) => {
                    const rH = (d.revenue / maxVal) * 100;
                    const cH = (d.cogs / maxVal) * 100;
                    const pH = (Math.max(d.profit, 0) / maxVal) * 100;
                    return (
                      <div key={d.day} className="flex-1 min-w-[40px] flex flex-col items-center gap-1">
                        <div className="flex items-end gap-0.5 w-full" style={{ height: "85%" }}>
                          <div className="flex-1 bg-green-400 rounded-t" style={{ height: `${rH}%` }} title={`Revenue ${formatRs(d.revenue)}`} />
                          <div className="flex-1 bg-red-400 rounded-t" style={{ height: `${cH}%` }} title={`Cost ${formatRs(d.cogs)}`} />
                          <div className="flex-1 bg-orange-500 rounded-t" style={{ height: `${pH}%` }} title={`Profit ${formatRs(d.profit)}`} />
                        </div>
                        <div className="text-[10px] text-gray-500">
                          {new Date(d.day).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="flex gap-4 text-xs text-gray-600 justify-center">
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-green-400 rounded" /> Revenue</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-red-400 rounded" /> Cost</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-orange-500 rounded" /> Profit</span>
                </div>
              </div>
            )}
          </div>

          {/* Top products */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="font-semibold text-gray-900 mb-4">Top Products by Profit</h2>
            {pl.topProducts.length === 0 ? (
              <div className="text-center text-gray-500 py-8 text-sm">No sales yet</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-gray-500 border-b">
                      <th className="pb-2">Product</th>
                      <th className="pb-2 text-right">Sold</th>
                      <th className="pb-2 text-right">Revenue</th>
                      <th className="pb-2 text-right hidden sm:table-cell">Cost</th>
                      <th className="pb-2 text-right">Profit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pl.topProducts.map((p) => (
                      <tr key={p.productId} className="border-b border-gray-100">
                        <td className="py-2 font-medium">{p.name}</td>
                        <td className="py-2 text-right">{p.qty}</td>
                        <td className="py-2 text-right">{formatRs(p.revenue)}</td>
                        <td className="py-2 text-right hidden sm:table-cell text-gray-600">{formatRs(p.cogs)}</td>
                        <td className={`py-2 text-right font-semibold ${p.profit >= 0 ? "text-green-600" : "text-red-600"}`}>
                          {formatRs(p.profit)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </AdminLayout>
  );
}

function KPI({ label, value, icon: Icon, color, valueClass }: { label: string; value: string; icon: React.ElementType; color: string; valueClass?: string }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-sm text-gray-500">{label}</div>
          <div className={`text-2xl font-bold mt-1 ${valueClass ?? "text-gray-900"}`}>{value}</div>
        </div>
        <div className={`p-2.5 rounded-lg ${color}`}>
          <Icon className="h-5 w-5 text-white" />
        </div>
      </div>
    </div>
  );
}

function SmallKPI({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-4">
      <div className="text-xs text-gray-500">{label}</div>
      <div className="text-lg font-semibold text-gray-900 mt-0.5">{value}</div>
    </div>
  );
}
