import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { adminFetch } from "@/lib/admin-api";
import { useToast } from "@/hooks/use-toast";

interface Coupon {
  id: number;
  code: string;
  discount: string;
  discountType: string;
  minOrderValue: string | null;
  maxDiscount: string | null;
  isActive: boolean;
  expiresAt: string | null;
}

const empty = {
  code: "",
  discount: "",
  discountType: "percentage",
  minOrderValue: "0",
  maxDiscount: "",
  isActive: true,
  expiresAt: "",
};

export default function AdminCoupons() {
  const { toast } = useToast();
  const [items, setItems] = useState<Coupon[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Coupon | null>(null);
  const [form, setForm] = useState<typeof empty>(empty);
  const [loading, setLoading] = useState(false);

  const load = () => {
    adminFetch<Coupon[]>("/admin/coupons").then(setItems).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => {
    setEditing(null);
    setForm(empty);
    setOpen(true);
  };

  const openEdit = (c: Coupon) => {
    setEditing(c);
    setForm({
      code: c.code,
      discount: c.discount,
      discountType: c.discountType,
      minOrderValue: c.minOrderValue ?? "0",
      maxDiscount: c.maxDiscount ?? "",
      isActive: c.isActive,
      expiresAt: c.expiresAt ? c.expiresAt.split("T")[0] : "",
    });
    setOpen(true);
  };

  const handleSubmit = async () => {
    if (!form.code || !form.discount) {
      toast({ title: "Code and discount are required", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const payload = {
        code: form.code.toUpperCase(),
        discount: form.discount,
        discountType: form.discountType,
        minOrderValue: form.minOrderValue || "0",
        maxDiscount: form.maxDiscount || null,
        isActive: form.isActive,
        expiresAt: form.expiresAt ? new Date(form.expiresAt).toISOString() : null,
      };
      if (editing) {
        await adminFetch(`/admin/coupons/${editing.id}`, {
          method: "PUT",
          body: JSON.stringify(payload),
        });
        toast({ title: "Coupon updated" });
      } else {
        await adminFetch("/admin/coupons", { method: "POST", body: JSON.stringify(payload) });
        toast({ title: "Coupon created" });
      }
      setOpen(false);
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (c: Coupon) => {
    if (!confirm(`Delete coupon "${c.code}"?`)) return;
    try {
      await adminFetch(`/admin/coupons/${c.id}`, { method: "DELETE" });
      toast({ title: "Coupon deleted" });
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Coupons</h1>
          <p className="text-gray-500 text-sm">{items.length} coupons</p>
        </div>
        <Button onClick={openCreate} className="bg-orange-500 hover:bg-orange-600">
          <Plus className="h-4 w-4 mr-2" /> Add Coupon
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((c) => (
          <div key={c.id} className="bg-white rounded-xl border border-gray-200 p-5">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="font-mono font-bold text-lg text-orange-600">{c.code}</div>
                <div className="text-sm text-gray-700 mt-1">
                  {c.discountType === "percentage"
                    ? `${parseFloat(c.discount)}% OFF`
                    : `Rs. ${parseFloat(c.discount)} OFF`}
                </div>
              </div>
              <span
                className={`px-2 py-0.5 rounded text-xs font-medium ${
                  c.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"
                }`}
              >
                {c.isActive ? "Active" : "Inactive"}
              </span>
            </div>
            <div className="text-xs text-gray-500 space-y-1">
              {c.minOrderValue && parseFloat(c.minOrderValue) > 0 && (
                <div>Min order: Rs. {parseFloat(c.minOrderValue)}</div>
              )}
              {c.maxDiscount && (
                <div>Max discount: Rs. {parseFloat(c.maxDiscount)}</div>
              )}
              {c.expiresAt && (
                <div>Expires: {new Date(c.expiresAt).toLocaleDateString("en-IN")}</div>
              )}
            </div>
            <div className="flex gap-2 mt-4 pt-3 border-t">
              <button
                onClick={() => openEdit(c)}
                className="flex-1 inline-flex items-center justify-center gap-1 py-1.5 text-sm text-gray-700 hover:bg-gray-50 rounded"
              >
                <Pencil className="h-3.5 w-3.5" /> Edit
              </button>
              <button
                onClick={() => handleDelete(c)}
                className="flex-1 inline-flex items-center justify-center gap-1 py-1.5 text-sm text-red-600 hover:bg-red-50 rounded"
              >
                <Trash2 className="h-3.5 w-3.5" /> Delete
              </button>
            </div>
          </div>
        ))}
        {items.length === 0 && (
          <div className="col-span-full text-center text-gray-500 py-12">
            No coupons yet. Create your first one!
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Coupon" : "Add Coupon"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Code *</Label>
              <Input
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                placeholder="WELCOME10"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Discount Type</Label>
                <Select value={form.discountType} onValueChange={(v) => setForm({ ...form, discountType: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage</SelectItem>
                    <SelectItem value="fixed">Fixed Amount</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Discount Value *</Label>
                <Input
                  type="number"
                  value={form.discount}
                  onChange={(e) => setForm({ ...form, discount: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Min Order Value (Rs.)</Label>
                <Input
                  type="number"
                  value={form.minOrderValue}
                  onChange={(e) => setForm({ ...form, minOrderValue: e.target.value })}
                />
              </div>
              <div>
                <Label>Max Discount (Rs.)</Label>
                <Input
                  type="number"
                  value={form.maxDiscount}
                  onChange={(e) => setForm({ ...form, maxDiscount: e.target.value })}
                />
              </div>
            </div>
            <div>
              <Label>Expires At</Label>
              <Input
                type="date"
                value={form.expiresAt}
                onChange={(e) => setForm({ ...form, expiresAt: e.target.value })}
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="active"
                checked={form.isActive}
                onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
              />
              <Label htmlFor="active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={loading} className="bg-orange-500 hover:bg-orange-600">
              {loading ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
