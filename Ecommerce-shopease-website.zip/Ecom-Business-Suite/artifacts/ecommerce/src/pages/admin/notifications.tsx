import { useEffect, useState } from "react";
import { Plus, Trash2, Bell, ToggleLeft, ToggleRight, ExternalLink } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { adminFetch } from "@/lib/admin-api";
import { useToast } from "@/hooks/use-toast";

interface Notification {
  id: number;
  title: string;
  body: string;
  type: string;
  isActive: boolean;
  ctaText: string | null;
  ctaUrl: string | null;
  createdAt: string;
}

const emptyForm = {
  title: "",
  body: "",
  type: "info",
  ctaText: "",
  ctaUrl: "",
};

const TYPE_COLORS: Record<string, string> = {
  info: "bg-blue-100 text-blue-700",
  offer: "bg-orange-100 text-orange-700",
  warning: "bg-yellow-100 text-yellow-700",
  success: "bg-green-100 text-green-700",
};

export default function AdminNotifications() {
  const { toast } = useToast();
  const [items, setItems] = useState<Notification[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Notification | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(false);

  const load = () => {
    adminFetch<Notification[]>("/admin/notifications").then(setItems).catch(() => {});
  };

  useEffect(load, []);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  };

  const openEdit = (n: Notification) => {
    setEditing(n);
    setForm({
      title: n.title,
      body: n.body,
      type: n.type,
      ctaText: n.ctaText ?? "",
      ctaUrl: n.ctaUrl ?? "",
    });
    setOpen(true);
  };

  const handleSave = async () => {
    if (!form.title || !form.body) {
      toast({ title: "Title and message are required", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const payload = {
        title: form.title,
        body: form.body,
        type: form.type,
        ctaText: form.ctaText || null,
        ctaUrl: form.ctaUrl || null,
      };
      if (editing) {
        await adminFetch(`/admin/notifications/${editing.id}`, {
          method: "PUT",
          body: JSON.stringify(payload),
        });
        toast({ title: "Notification updated" });
      } else {
        await adminFetch("/admin/notifications", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        toast({ title: "Notification published" });
      }
      setOpen(false);
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const toggleActive = async (n: Notification) => {
    try {
      await adminFetch(`/admin/notifications/${n.id}`, {
        method: "PUT",
        body: JSON.stringify({ ...n, isActive: !n.isActive }),
      });
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleDelete = async (n: Notification) => {
    if (!confirm(`Delete "${n.title}"?`)) return;
    try {
      await adminFetch(`/admin/notifications/${n.id}`, { method: "DELETE" });
      toast({ title: "Deleted" });
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  const active = items.filter((i) => i.isActive).length;

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
          <p className="text-gray-500 text-sm">
            {active} active · {items.length} total — shown to all customers in the app
          </p>
        </div>
        <Button onClick={openCreate} className="bg-orange-500 hover:bg-orange-600">
          <Plus className="h-4 w-4 mr-2" /> New Notification
        </Button>
      </div>

      {items.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <Bell className="h-10 w-10 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No notifications yet. Create one to show it to customers.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((n) => (
            <div
              key={n.id}
              className={`bg-white rounded-xl border p-4 flex items-start gap-4 ${
                n.isActive ? "border-gray-200" : "border-gray-100 opacity-60"
              }`}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      TYPE_COLORS[n.type] ?? "bg-gray-100 text-gray-600"
                    }`}
                  >
                    {n.type}
                  </span>
                  {!n.isActive && (
                    <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
                      Inactive
                    </span>
                  )}
                  <span className="text-xs text-gray-400 ml-auto">
                    {new Date(n.createdAt).toLocaleDateString("en-IN", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                    })}
                  </span>
                </div>
                <div className="font-semibold text-gray-900">{n.title}</div>
                <div className="text-sm text-gray-600 mt-0.5">{n.body}</div>
                {n.ctaText && n.ctaUrl && (
                  <a
                    href={n.ctaUrl}
                    className="text-xs text-orange-600 flex items-center gap-1 mt-1 hover:underline"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <ExternalLink className="h-3 w-3" /> {n.ctaText}
                  </a>
                )}
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                <button
                  onClick={() => toggleActive(n)}
                  className="p-2 rounded hover:bg-gray-100 text-gray-500"
                  title={n.isActive ? "Deactivate" : "Activate"}
                >
                  {n.isActive ? (
                    <ToggleRight className="h-5 w-5 text-green-500" />
                  ) : (
                    <ToggleLeft className="h-5 w-5" />
                  )}
                </button>
                <button
                  onClick={() => openEdit(n)}
                  className="p-2 rounded hover:bg-gray-100 text-gray-600 text-sm"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(n)}
                  className="p-2 rounded hover:bg-red-50 text-red-500"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Notification" : "New Notification"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="offer">Offer / Promo</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Title *</Label>
              <Input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. Flash Sale — 30% off today!"
              />
            </div>
            <div>
              <Label>Message *</Label>
              <Textarea
                rows={3}
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
                placeholder="Full notification message shown to customers..."
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Button Text (optional)</Label>
                <Input
                  value={form.ctaText}
                  onChange={(e) => setForm({ ...form, ctaText: e.target.value })}
                  placeholder="Shop Now"
                />
              </div>
              <div>
                <Label>Button Link (optional)</Label>
                <Input
                  value={form.ctaUrl}
                  onChange={(e) => setForm({ ...form, ctaUrl: e.target.value })}
                  placeholder="/products"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={loading}
              className="bg-orange-500 hover:bg-orange-600"
            >
              {loading ? "Saving..." : editing ? "Update" : "Publish"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
