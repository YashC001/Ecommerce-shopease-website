import { useEffect, useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { adminFetch } from "@/lib/admin-api";
import { useToast } from "@/hooks/use-toast";
import { Shield, ShieldOff, Search, KeyRound, UserPlus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface AdminUser {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: string;
  createdAt: string;
  orderCount: number;
  totalSpent: string;
}

export default function AdminUsers() {
  const { toast } = useToast();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [search, setSearch] = useState("");
  const [pwdUser, setPwdUser] = useState<AdminUser | null>(null);
  const [newPwd, setNewPwd] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState({ name: "", email: "", phone: "", password: "", role: "admin" });

  const load = () => {
    adminFetch<AdminUser[]>("/admin/users").then(setUsers).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const handleResetPwd = async () => {
    if (!pwdUser || newPwd.length < 6) {
      toast({ title: "Password must be at least 6 characters", variant: "destructive" });
      return;
    }
    try {
      await adminFetch(`/admin/users/${pwdUser.id}/password`, {
        method: "PUT",
        body: JSON.stringify({ password: newPwd }),
      });
      toast({ title: `Password reset for ${pwdUser.name}` });
      setPwdUser(null);
      setNewPwd("");
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleCreate = async () => {
    if (!createForm.name || !createForm.email || createForm.password.length < 6) {
      toast({ title: "Fill all fields (password 6+ chars)", variant: "destructive" });
      return;
    }
    try {
      await adminFetch("/admin/users", {
        method: "POST",
        body: JSON.stringify(createForm),
      });
      toast({ title: `${createForm.role === "admin" ? "Admin" : "User"} created` });
      setCreateOpen(false);
      setCreateForm({ name: "", email: "", phone: "", password: "", role: "admin" });
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  const toggleRole = async (u: AdminUser) => {
    const newRole = u.role === "admin" ? "user" : "admin";
    if (!confirm(`${newRole === "admin" ? "Promote" : "Demote"} ${u.name}?`)) return;
    try {
      await adminFetch(`/admin/users/${u.id}/role`, {
        method: "PUT",
        body: JSON.stringify({ role: newRole }),
      });
      toast({ title: `User ${newRole === "admin" ? "promoted" : "demoted"}` });
      load();
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    }
  };

  const filtered = users.filter(
    (u) =>
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase()) ||
      u.phone.includes(search),
  );

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Users</h1>
          <p className="text-gray-500 text-sm">{users.length} registered customers</p>
        </div>
        <Button onClick={() => setCreateOpen(true)} className="bg-orange-500 hover:bg-orange-600" data-testid="button-create-user">
          <UserPlus className="h-4 w-4 mr-2" /> Create Admin
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4 mb-4">
        <div className="relative max-w-md">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search users..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr className="text-left text-gray-600">
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3 hidden sm:table-cell">Phone</th>
                <th className="px-4 py-3">Orders</th>
                <th className="px-4 py-3">Spent</th>
                <th className="px-4 py-3">Role</th>
                <th className="px-4 py-3 hidden lg:table-cell">Joined</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div className="font-medium text-gray-900">{u.name}</div>
                    <div className="text-xs text-gray-500">{u.email}</div>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell text-gray-700">{u.phone}</td>
                  <td className="px-4 py-3">{u.orderCount}</td>
                  <td className="px-4 py-3 font-medium">
                    Rs. {parseFloat(u.totalSpent).toLocaleString("en-IN")}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-medium capitalize ${
                        u.role === "admin"
                          ? "bg-orange-100 text-orange-700"
                          : "bg-gray-100 text-gray-700"
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell text-gray-500">
                    {new Date(u.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => { setPwdUser(u); setNewPwd(""); }}
                        className="text-indigo-600 hover:bg-indigo-50 p-2 rounded inline-flex items-center gap-1 text-xs font-medium"
                        data-testid={`button-reset-pwd-${u.id}`}
                      >
                        <KeyRound className="h-3.5 w-3.5" /> Password
                      </button>
                      <button
                        onClick={() => toggleRole(u)}
                        className="text-orange-600 hover:bg-orange-50 p-2 rounded inline-flex items-center gap-1 text-xs font-medium"
                        data-testid={`button-toggle-role-${u.id}`}
                      >
                        {u.role === "admin" ? (
                          <><ShieldOff className="h-3.5 w-3.5" /> Demote</>
                        ) : (
                          <><Shield className="h-3.5 w-3.5" /> Make Admin</>
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="text-center text-gray-500 py-8">No users found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reset Password Dialog */}
      <Dialog open={!!pwdUser} onOpenChange={(o) => { if (!o) setPwdUser(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
          </DialogHeader>
          {pwdUser && (
            <div className="space-y-3">
              <p className="text-sm text-gray-600">
                Resetting password for <span className="font-semibold">{pwdUser.name}</span> ({pwdUser.email})
              </p>
              <div>
                <Label>New Password (min 6 characters)</Label>
                <Input
                  type="text"
                  value={newPwd}
                  onChange={(e) => setNewPwd(e.target.value)}
                  placeholder="Enter new password"
                  data-testid="input-new-password"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setPwdUser(null)}>Cancel</Button>
            <Button onClick={handleResetPwd} className="bg-orange-500 hover:bg-orange-600" data-testid="button-confirm-reset-pwd">
              Reset Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Admin Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Name *</Label>
              <Input value={createForm.name} onChange={(e) => setCreateForm({ ...createForm, name: e.target.value })} />
            </div>
            <div>
              <Label>Email *</Label>
              <Input type="email" value={createForm.email} onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })} />
            </div>
            <div>
              <Label>Phone</Label>
              <Input value={createForm.phone} onChange={(e) => setCreateForm({ ...createForm, phone: e.target.value })} />
            </div>
            <div>
              <Label>Password *</Label>
              <Input type="text" value={createForm.password} onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })} />
            </div>
            <div>
              <Label>Role</Label>
              <Select value={createForm.role} onValueChange={(v) => setCreateForm({ ...createForm, role: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="user">Regular User</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} className="bg-orange-500 hover:bg-orange-600" data-testid="button-confirm-create-user">
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
