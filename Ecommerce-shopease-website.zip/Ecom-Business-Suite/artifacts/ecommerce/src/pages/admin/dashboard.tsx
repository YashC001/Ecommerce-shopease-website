import { useEffect, useState } from "react";
import { Link } from "wouter";
import {
  IndianRupee,
  ShoppingBag,
  Users,
  Package,
  Clock,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
} from "recharts";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { adminFetch } from "@/lib/admin-api";

interface Stats {
  orders: { total: number; pending: number; revenue: string };
  users: number;
  products: { total: number; lowStock: number };
  categories: number;
  recentOrders: Array<{
    id: number;
    orderNumber: string;
    status: string;
    total: string;
    createdAt: string;
  }>;
  dailyRevenue: Array<{ day: string; revenue: string; orders: number }>;
}

function formatRs(v: string | number) {
  const n = typeof v === "string" ? parseFloat(v) : v;
  return `Rs. ${n.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`;
}

function shortDay(dayStr: string) {
  const d = new Date(dayStr);
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

function StatCard({
  title,
  value,
  icon: Icon,
  color,
  hint,
  trend,
}: {
  title: string;
  value: string;
  icon: React.ElementType;
  color: string;
  hint?: string;
  trend?: "up" | "down" | null;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <div className="text-sm text-gray-500">{title}</div>
          <div
            className="text-2xl font-bold text-gray-900 mt-1 truncate"
            data-testid={`stat-${title.toLowerCase().replace(/\s+/g, "-")}`}
          >
            {value}
          </div>
          {hint && (
            <div className="text-xs text-gray-500 mt-1 flex items-center gap-1">
              {trend === "up" && <TrendingUp className="h-3 w-3 text-green-500" />}
              {trend === "down" && <TrendingDown className="h-3 w-3 text-red-500" />}
              {hint}
            </div>
          )}
        </div>
        <div className={`p-2.5 rounded-lg flex-shrink-0 ml-2 ${color}`}>
          <Icon className="h-5 w-5 text-white" />
        </div>
      </div>
    </div>
  );
}

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700",
  processing: "bg-blue-100 text-blue-700",
  shipped: "bg-indigo-100 text-indigo-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; name: string }>;
  label?: string;
}

function RevenueTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-lg px-3 py-2 text-xs">
      <div className="font-medium text-gray-700 mb-1">{label}</div>
      {payload.map((p) => (
        <div key={p.name} className="text-gray-600">
          {p.name === "revenue" ? formatRs(p.value) : `${p.value} orders`}
        </div>
      ))}
    </div>
  );
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    adminFetch<Stats>("/admin/stats")
      .then(setStats)
      .catch((e) => setError(e.message));
  }, []);

  const chartData = stats?.dailyRevenue.map((d) => ({
    day: shortDay(d.day),
    revenue: parseFloat(d.revenue),
    orders: d.orders,
  })) ?? [];

  const totalRevenue = stats?.orders.revenue ? parseFloat(stats.orders.revenue) : 0;

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 text-sm">Overview of your store performance</p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-6">
          {error}
        </div>
      )}

      {!stats ? (
        <div className="text-gray-500">Loading...</div>
      ) : (
        <>
          {/* Stat Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard
              title="Total Revenue"
              value={formatRs(totalRevenue)}
              icon={IndianRupee}
              color="bg-green-500"
              hint={`${stats.orders.total} orders total`}
            />
            <StatCard
              title="Orders"
              value={String(stats.orders.total)}
              icon={ShoppingBag}
              color="bg-orange-500"
              hint={`${stats.orders.pending} pending`}
              trend={stats.orders.pending > 0 ? "up" : null}
            />
            <StatCard
              title="Customers"
              value={String(stats.users)}
              icon={Users}
              color="bg-indigo-500"
            />
            <StatCard
              title="Products"
              value={String(stats.products.total)}
              icon={Package}
              color="bg-blue-500"
              hint={
                stats.products.lowStock > 0
                  ? `${stats.products.lowStock} low stock`
                  : `${stats.categories} categories`
              }
              trend={stats.products.lowStock > 0 ? "down" : null}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Revenue & Orders Chart */}
            <div className="lg:col-span-2 space-y-6">
              {/* Bar chart — Revenue */}
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="h-4 w-4 text-orange-500" />
                  <h2 className="font-semibold text-gray-900">Revenue — Last 7 Days</h2>
                </div>
                {chartData.length === 0 ? (
                  <div className="text-center text-gray-500 py-12 text-sm">No data yet</div>
                ) : (
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={chartData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis
                        dataKey="day"
                        tick={{ fontSize: 11, fill: "#6b7280" }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fontSize: 11, fill: "#6b7280" }}
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                        width={45}
                      />
                      <Tooltip content={<RevenueTooltip />} />
                      <Bar
                        dataKey="revenue"
                        fill="#f97316"
                        radius={[4, 4, 0, 0]}
                        name="revenue"
                      />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>

              {/* Line chart — Orders */}
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center gap-2 mb-4">
                  <ShoppingBag className="h-4 w-4 text-indigo-500" />
                  <h2 className="font-semibold text-gray-900">Orders — Last 7 Days</h2>
                </div>
                {chartData.length === 0 ? (
                  <div className="text-center text-gray-500 py-12 text-sm">No data yet</div>
                ) : (
                  <ResponsiveContainer width="100%" height={160}>
                    <LineChart data={chartData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis
                        dataKey="day"
                        tick={{ fontSize: 11, fill: "#6b7280" }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fontSize: 11, fill: "#6b7280" }}
                        axisLine={false}
                        tickLine={false}
                        allowDecimals={false}
                        width={30}
                      />
                      <Tooltip content={<RevenueTooltip />} />
                      <Line
                        type="monotone"
                        dataKey="orders"
                        stroke="#6366f1"
                        strokeWidth={2}
                        dot={{ fill: "#6366f1", r: 4 }}
                        activeDot={{ r: 6 }}
                        name="orders"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>

            {/* Alerts */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 h-fit">
              <h2 className="font-semibold text-gray-900 mb-4">Alerts</h2>
              <div className="space-y-3">
                {stats.orders.pending > 0 && (
                  <Link href="/admin/orders">
                    <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg cursor-pointer hover:bg-orange-100 transition">
                      <Clock className="h-5 w-5 text-orange-600 mt-0.5" />
                      <div>
                        <div className="font-medium text-sm text-gray-900">
                          {stats.orders.pending} pending order{stats.orders.pending > 1 ? "s" : ""}
                        </div>
                        <div className="text-xs text-gray-600">Click to manage</div>
                      </div>
                    </div>
                  </Link>
                )}
                {stats.products.lowStock > 0 && (
                  <Link href="/admin/products">
                    <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg cursor-pointer hover:bg-red-100 transition">
                      <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
                      <div>
                        <div className="font-medium text-sm text-gray-900">
                          {stats.products.lowStock} low stock product{stats.products.lowStock > 1 ? "s" : ""}
                        </div>
                        <div className="text-xs text-gray-600">Restock soon</div>
                      </div>
                    </div>
                  </Link>
                )}
                {stats.orders.pending === 0 && stats.products.lowStock === 0 && (
                  <div className="text-sm text-gray-500 text-center py-6">
                    All clear! No alerts.
                  </div>
                )}
              </div>

              {/* Quick stats summary */}
              <div className="mt-4 pt-4 border-t border-gray-100 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Avg order value</span>
                  <span className="font-medium text-gray-900">
                    {stats.orders.total > 0
                      ? formatRs(totalRevenue / stats.orders.total)
                      : "—"}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Categories</span>
                  <span className="font-medium text-gray-900">{stats.categories}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Recent orders */}
          <div className="mt-6 bg-white rounded-xl border border-gray-200 p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-gray-900">Recent Orders</h2>
              <Link href="/admin/orders">
                <span className="text-sm text-orange-600 hover:underline cursor-pointer">View all</span>
              </Link>
            </div>
            {stats.recentOrders.length === 0 ? (
              <div className="text-sm text-gray-500 text-center py-8">No recent orders</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-gray-500 border-b border-gray-200">
                      <th className="pb-2">Order #</th>
                      <th className="pb-2">Status</th>
                      <th className="pb-2">Total</th>
                      <th className="pb-2 hidden md:table-cell">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats.recentOrders.map((o) => (
                      <tr key={o.id} className="border-b border-gray-100">
                        <td className="py-2.5 font-medium">{o.orderNumber}</td>
                        <td className="py-2.5">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium capitalize ${
                              STATUS_COLORS[o.status] ?? "bg-gray-100 text-gray-600"
                            }`}
                          >
                            {o.status}
                          </span>
                        </td>
                        <td className="py-2.5 font-medium">{formatRs(o.total)}</td>
                        <td className="py-2.5 hidden md:table-cell text-gray-500">
                          {new Date(o.createdAt).toLocaleDateString("en-IN", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </AdminLayout>
  );
}
