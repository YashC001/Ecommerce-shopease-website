import { useEffect, useRef, useState } from "react";
import { Plus, Pencil, Trash2, Search, Upload, X, Link } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { adminFetch } from "@/lib/admin-api";
import { getToken } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

interface Product {
  id: number;
  name: string;
  slug: string;
  description: string;
  price: string;
  originalPrice: string | null;
  discountPercent: number | null;
  images: string[];
  categoryId: number;
  rating: string;
  reviewCount: number;
  stock: number;
  isFeatured: boolean;
  badge: string | null;
}

interface Category {
  id: number;
  name: string;
}

const BASE_STORAGE = `${import.meta.env.BASE_URL}api/storage`;

function objectPathToUrl(objectPath: string): string {
  // objectPath = "/objects/uploads/uuid" → serving URL = BASE_STORAGE + objectPath
  return `${BASE_STORAGE}${objectPath}`;
}

async function uploadImageFile(file: File): Promise<string> {
  const token = getToken();

  const presignRes = await fetch(`${BASE_STORAGE}/uploads/request-url`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({
      name: file.name,
      size: file.size,
      contentType: file.type || "application/octet-stream",
    }),
  });

  if (!presignRes.ok) {
    const err = await presignRes.json().catch(() => ({ error: "Upload failed" }));
    throw new Error(err.error || `HTTP ${presignRes.status}`);
  }

  const { uploadURL, objectPath } = await presignRes.json();

  const uploadRes = await fetch(uploadURL, {
    method: "PUT",
    headers: { "Content-Type": file.type || "application/octet-stream" },
    body: file,
  });

  if (!uploadRes.ok) {
    throw new Error("Failed to upload file to storage");
  }

  return objectPathToUrl(objectPath);
}

interface ImageManagerProps {
  images: string[];
  onChange: (images: string[]) => void;
}

function ImageManager({ images, onChange }: ImageManagerProps) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [urlInput, setUrlInput] = useState("");
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    setUploading(true);
    try {
      const urls = await Promise.all(files.map(uploadImageFile));
      onChange([...images, ...urls]);
    } catch (err) {
      toast({
        title: "Upload failed",
        description: (err as Error).message,
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const addUrl = () => {
    const url = urlInput.trim();
    if (!url) return;
    onChange([...images, url]);
    setUrlInput("");
  };

  const remove = (idx: number) => {
    onChange(images.filter((_, i) => i !== idx));
  };

  return (
    <div className="space-y-3">
      {images.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {images.map((url, i) => (
            <div key={i} className="relative group">
              <img
                src={url}
                alt={`Image ${i + 1}`}
                className="w-20 h-20 object-cover rounded-lg border border-gray-200"
              />
              <button
                type="button"
                onClick={() => remove(i)}
                className="absolute -top-1.5 -right-1.5 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="h-3 w-3" />
              </button>
              {i === 0 && (
                <span className="absolute bottom-0 left-0 right-0 text-center text-[10px] bg-black/50 text-white rounded-b-lg py-0.5">
                  Main
                </span>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="flex gap-2">
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={handleFileChange}
        />
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={uploading}
          onClick={() => fileRef.current?.click()}
          className="flex-shrink-0"
        >
          <Upload className="h-4 w-4 mr-1.5" />
          {uploading ? "Uploading…" : "Upload"}
        </Button>

        <div className="flex flex-1 gap-2">
          <Input
            placeholder="Or paste image URL…"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addUrl())}
            className="flex-1 text-sm"
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addUrl}
            disabled={!urlInput.trim()}
          >
            <Link className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <p className="text-xs text-gray-400">
        First image is the main product photo. Drag to reorder not yet supported.
      </p>
    </div>
  );
}

const emptyForm = {
  name: "",
  slug: "",
  description: "",
  price: "",
  cost: "0",
  originalPrice: "",
  images: [] as string[],
  categoryId: "",
  stock: "0",
  isFeatured: false,
  badge: "",
};

export default function AdminProducts() {
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Product | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<typeof emptyForm>(emptyForm);
  const [loading, setLoading] = useState(false);

  const load = () => {
    adminFetch<Product[]>("/admin/products").then(setProducts).catch(() => {});
    adminFetch<Category[]>("/admin/categories").then(setCategories).catch(() => {});
  };

  useEffect(load, []);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditing(p);
    setForm({
      name: p.name,
      slug: p.slug,
      description: p.description,
      price: p.price,
      cost: (p as { cost?: string }).cost ?? "0",
      originalPrice: p.originalPrice ?? "",
      images: p.images,
      categoryId: String(p.categoryId),
      stock: String(p.stock),
      isFeatured: p.isFeatured,
      badge: p.badge ?? "",
    });
    setOpen(true);
  };

  const handleSubmit = async () => {
    if (!form.name || !form.price || !form.categoryId) {
      toast({ title: "Missing required fields", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const slug =
        form.slug ||
        form.name
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-|-$/g, "");
      const orig = form.originalPrice ? parseFloat(form.originalPrice) : null;
      const price = parseFloat(form.price);
      const discountPercent =
        orig && orig > price ? Math.round(((orig - price) / orig) * 100) : null;

      const payload = {
        name: form.name,
        slug,
        description: form.description,
        price: form.price,
        cost: form.cost || "0",
        originalPrice: form.originalPrice || null,
        discountPercent,
        images: form.images,
        categoryId: Number(form.categoryId),
        stock: Number(form.stock),
        isFeatured: form.isFeatured,
        badge: form.badge || null,
      };

      if (editing) {
        await adminFetch(`/admin/products/${editing.id}`, {
          method: "PUT",
          body: JSON.stringify(payload),
        });
        toast({ title: "Product updated" });
      } else {
        await adminFetch("/admin/products", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        toast({ title: "Product created" });
      }
      setOpen(false);
      load();
    } catch (e) {
      toast({
        title: "Error",
        description: (e as Error).message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (p: Product) => {
    if (!confirm(`Delete "${p.name}"? This cannot be undone.`)) return;
    try {
      await adminFetch(`/admin/products/${p.id}`, { method: "DELETE" });
      toast({ title: "Product deleted" });
      load();
    } catch (e) {
      toast({
        title: "Error",
        description: (e as Error).message,
        variant: "destructive",
      });
    }
  };

  const filtered = products.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Products</h1>
          <p className="text-gray-500 text-sm">{products.length} total products</p>
        </div>
        <Button
          onClick={openCreate}
          className="bg-orange-500 hover:bg-orange-600"
          data-testid="button-add-product"
        >
          <Plus className="h-4 w-4 mr-2" /> Add Product
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4 mb-4">
        <div className="relative max-w-md">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
            data-testid="input-search-products"
          />
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr className="text-left text-gray-600">
                <th className="px-4 py-3">Product</th>
                <th className="px-4 py-3">Price</th>
                <th className="px-4 py-3">Stock</th>
                <th className="px-4 py-3 hidden md:table-cell">Category</th>
                <th className="px-4 py-3 hidden md:table-cell">Featured</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => {
                const cat = categories.find((c) => c.id === p.categoryId);
                return (
                  <tr
                    key={p.id}
                    className="border-b border-gray-100 hover:bg-gray-50"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        {p.images[0] && (
                          <img
                            src={p.images[0]}
                            alt={p.name}
                            className="w-10 h-10 rounded object-cover"
                          />
                        )}
                        <div>
                          <div className="font-medium text-gray-900 line-clamp-1">
                            {p.name}
                          </div>
                          <div className="text-xs text-gray-500">{p.slug}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium">
                        Rs. {parseFloat(p.price).toLocaleString("en-IN")}
                      </div>
                      {p.originalPrice && (
                        <div className="text-xs text-gray-400 line-through">
                          Rs.{" "}
                          {parseFloat(p.originalPrice).toLocaleString("en-IN")}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${
                          p.stock < 10
                            ? "bg-red-100 text-red-700"
                            : "bg-green-100 text-green-700"
                        }`}
                      >
                        {p.stock}
                      </span>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell text-gray-600">
                      {cat?.name ?? "—"}
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      {p.isFeatured ? (
                        <span className="text-orange-600 font-medium text-xs">
                          Yes
                        </span>
                      ) : (
                        <span className="text-gray-400 text-xs">No</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openEdit(p)}
                          className="p-2 hover:bg-gray-100 rounded text-gray-600"
                          data-testid={`button-edit-product-${p.id}`}
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(p)}
                          className="p-2 hover:bg-red-50 rounded text-red-600"
                          data-testid={`button-delete-product-${p.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center text-gray-500 py-8">
                    No products found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Product" : "Add Product"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label>Name *</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                data-testid="input-product-name"
              />
            </div>
            <div className="md:col-span-2">
              <Label>Slug (auto if empty)</Label>
              <Input
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: e.target.value })}
              />
            </div>
            <div className="md:col-span-2">
              <Label>Description</Label>
              <Textarea
                rows={3}
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
              />
            </div>
            <div>
              <Label>Price (Rs.) *</Label>
              <Input
                type="number"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                data-testid="input-product-price"
              />
            </div>
            <div>
              <Label>Original Price (Rs.)</Label>
              <Input
                type="number"
                value={form.originalPrice}
                onChange={(e) =>
                  setForm({ ...form, originalPrice: e.target.value })
                }
              />
            </div>
            <div>
              <Label>Cost Price (Rs.) — for P&L</Label>
              <Input
                type="number"
                value={form.cost}
                onChange={(e) => setForm({ ...form, cost: e.target.value })}
                data-testid="input-product-cost"
                placeholder="What you paid"
              />
            </div>
            <div>
              <Label>Stock</Label>
              <Input
                type="number"
                value={form.stock}
                onChange={(e) => setForm({ ...form, stock: e.target.value })}
              />
            </div>
            <div>
              <Label>Category *</Label>
              <Select
                value={form.categoryId}
                onValueChange={(v) => setForm({ ...form, categoryId: v })}
              >
                <SelectTrigger data-testid="select-product-category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Badge (e.g. Best Seller)</Label>
              <Input
                value={form.badge}
                onChange={(e) => setForm({ ...form, badge: e.target.value })}
              />
            </div>
            <div className="flex items-center gap-2 mt-6">
              <input
                type="checkbox"
                id="featured"
                checked={form.isFeatured}
                onChange={(e) =>
                  setForm({ ...form, isFeatured: e.target.checked })
                }
              />
              <Label htmlFor="featured">Featured product</Label>
            </div>
            <div className="md:col-span-2">
              <Label className="mb-2 block">Product Images</Label>
              <ImageManager
                images={form.images}
                onChange={(imgs) => setForm({ ...form, images: imgs })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={loading}
              className="bg-orange-500 hover:bg-orange-600"
              data-testid="button-save-product"
            >
              {loading ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
