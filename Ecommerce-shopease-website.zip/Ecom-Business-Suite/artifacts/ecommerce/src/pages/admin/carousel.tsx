import { useEffect, useState } from "react";
import { Plus, Save, Trash2, ChevronUp, ChevronDown } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { adminFetch } from "@/lib/admin-api";
import { useToast } from "@/hooks/use-toast";
import { refreshSettings, type HeroSlide, type SiteSettings } from "@/hooks/useSettings";

const GRADIENTS = [
  { label: "Indigo → Pink", value: "from-indigo-600 via-purple-600 to-pink-500" },
  { label: "Orange → Pink", value: "from-orange-500 via-rose-500 to-pink-600" },
  { label: "Emerald → Cyan", value: "from-emerald-500 via-teal-500 to-cyan-600" },
  { label: "Amber → Red", value: "from-amber-500 via-orange-500 to-red-500" },
  { label: "Blue → Indigo", value: "from-blue-500 via-indigo-500 to-purple-600" },
  { label: "Slate → Gray", value: "from-slate-700 via-gray-700 to-zinc-800" },
];

function emptySlide(): HeroSlide {
  return {
    id: crypto.randomUUID(),
    title: "New Slide",
    subtitle: "Subtitle here",
    cta: "Shop Now",
    href: "/products",
    gradient: GRADIENTS[0].value,
    image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&q=80",
  };
}

export default function AdminCarousel() {
  const { toast } = useToast();
  const [slides, setSlides] = useState<HeroSlide[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    adminFetch<SiteSettings>("/admin/settings")
      .then((s) => setSlides(s.heroSlides ?? []))
      .catch(() => {});
  }, []);

  const update = (i: number, patch: Partial<HeroSlide>) => {
    setSlides((arr) => arr.map((s, idx) => (idx === i ? { ...s, ...patch } : s)));
  };

  const remove = (i: number) => {
    if (!confirm("Delete this slide?")) return;
    setSlides((arr) => arr.filter((_, idx) => idx !== i));
  };

  const move = (i: number, dir: -1 | 1) => {
    setSlides((arr) => {
      const next = [...arr];
      const j = i + dir;
      if (j < 0 || j >= next.length) return arr;
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await adminFetch("/admin/settings", {
        method: "PUT",
        body: JSON.stringify({ heroSlides: slides }),
      });
      await refreshSettings();
      toast({ title: "Carousel saved" });
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Hero Carousel</h1>
          <p className="text-gray-500 text-sm">{slides.length} slides on your homepage</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setSlides((s) => [...s, emptySlide()])}>
            <Plus className="h-4 w-4 mr-2" /> Add Slide
          </Button>
          <Button onClick={handleSave} disabled={saving} className="bg-orange-500 hover:bg-orange-600">
            <Save className="h-4 w-4 mr-2" /> {saving ? "Saving..." : "Save"}
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        {slides.map((slide, i) => (
          <div key={slide.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            {/* Preview */}
            <div className="relative h-32 overflow-hidden">
              <img src={slide.image} alt="" className="w-full h-full object-cover" />
              <div className={`absolute inset-0 bg-gradient-to-r ${slide.gradient} opacity-75`} />
              <div className="absolute inset-0 flex items-center px-6 text-white">
                <div>
                  <div className="font-bold text-lg">{slide.title}</div>
                  <div className="text-sm">{slide.subtitle}</div>
                </div>
              </div>
              <div className="absolute top-2 right-2 flex gap-1">
                <button onClick={() => move(i, -1)} disabled={i === 0} className="bg-white/80 p-1 rounded disabled:opacity-30">
                  <ChevronUp className="h-4 w-4" />
                </button>
                <button onClick={() => move(i, 1)} disabled={i === slides.length - 1} className="bg-white/80 p-1 rounded disabled:opacity-30">
                  <ChevronDown className="h-4 w-4" />
                </button>
                <button onClick={() => remove(i)} className="bg-white/80 p-1 rounded text-red-600">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Form */}
            <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label>Title</Label>
                <Input value={slide.title} onChange={(e) => update(i, { title: e.target.value })} />
              </div>
              <div>
                <Label>Subtitle</Label>
                <Input value={slide.subtitle} onChange={(e) => update(i, { subtitle: e.target.value })} />
              </div>
              <div>
                <Label>Button Text</Label>
                <Input value={slide.cta} onChange={(e) => update(i, { cta: e.target.value })} />
              </div>
              <div>
                <Label>Button Link</Label>
                <Input value={slide.href} onChange={(e) => update(i, { href: e.target.value })} placeholder="/products" />
              </div>
              <div className="md:col-span-2">
                <Label>Image URL</Label>
                <Textarea rows={2} value={slide.image} onChange={(e) => update(i, { image: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <Label>Background Gradient</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-1">
                  {GRADIENTS.map((g) => (
                    <button
                      key={g.value}
                      type="button"
                      onClick={() => update(i, { gradient: g.value })}
                      className={`h-9 rounded text-xs font-medium text-white bg-gradient-to-r ${g.value} ${
                        slide.gradient === g.value ? "ring-2 ring-orange-500" : ""
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
        {slides.length === 0 && (
          <div className="text-center text-gray-500 py-12 bg-white rounded-xl border border-gray-200">
            No slides. Add your first slide!
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
