import { useEffect, useRef, useState } from "react";
import { Save, Plus, X, Image as ImageIcon, Upload, Palette } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { adminFetch } from "@/lib/admin-api";
import { getToken } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { refreshSettings, type SiteSettings } from "@/hooks/useSettings";

const BASE_STORAGE = `${import.meta.env.BASE_URL}api/storage`;

async function uploadLogo(file: File): Promise<string> {
  const token = getToken();
  const presignRes = await fetch(`${BASE_STORAGE}/uploads/request-url`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type || "image/png" }),
  });
  if (!presignRes.ok) throw new Error("Failed to get upload URL");
  const { uploadURL, objectPath } = await presignRes.json();
  const putRes = await fetch(uploadURL, {
    method: "PUT",
    headers: { "Content-Type": file.type || "image/png" },
    body: file,
  });
  if (!putRes.ok) throw new Error("Upload failed");
  return `${BASE_STORAGE}${objectPath}`;
}

function ColorPicker({ label, value, onChange, hint }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  hint?: string;
}) {
  return (
    <div>
      <Label className="mb-1 block">{label}</Label>
      <div className="flex items-center gap-2">
        <div className="relative">
          <input
            type="color"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-10 h-10 rounded cursor-pointer border border-gray-200 p-0.5"
          />
        </div>
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-32 font-mono text-sm"
          placeholder="#f97316"
        />
        <div
          className="w-8 h-8 rounded-lg border border-gray-200 flex-shrink-0"
          style={{ backgroundColor: value }}
        />
      </div>
      {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
    </div>
  );
}

export default function AdminSettings() {
  const { toast } = useToast();
  const [s, setS] = useState<SiteSettings | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const logoFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    adminFetch<SiteSettings>("/admin/settings")
      .then(setS)
      .catch(() => {});
  }, []);

  const update = <K extends keyof SiteSettings>(key: K, value: SiteSettings[K]) => {
    setS((prev) => (prev ? { ...prev, [key]: value } : prev));
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingLogo(true);
    try {
      const url = await uploadLogo(file);
      update("logoUrl", url);
      toast({ title: "Logo uploaded" });
    } catch (err) {
      toast({ title: "Upload failed", description: (err as Error).message, variant: "destructive" });
    } finally {
      setUploadingLogo(false);
      if (logoFileRef.current) logoFileRef.current.value = "";
    }
  };

  const addOffer = () => {
    if (!s) return;
    update("offerBarTexts", [...s.offerBarTexts, "New offer"]);
  };

  const removeOffer = (i: number) => {
    if (!s) return;
    update("offerBarTexts", s.offerBarTexts.filter((_, idx) => idx !== i));
  };

  const updateOffer = (i: number, value: string) => {
    if (!s) return;
    update("offerBarTexts", s.offerBarTexts.map((t, idx) => (idx === i ? value : t)));
  };

  const handleSave = async () => {
    if (!s) return;
    setSaving(true);
    try {
      await adminFetch("/admin/settings", {
        method: "PUT",
        body: JSON.stringify(s),
      });
      await refreshSettings();
      toast({ title: "Settings saved" });
    } catch (e) {
      toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (!s) {
    return <AdminLayout><div className="text-gray-500">Loading...</div></AdminLayout>;
  }

  return (
    <AdminLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Site Settings</h1>
          <p className="text-gray-500 text-sm">Customize your store's branding and content</p>
        </div>
        <Button onClick={handleSave} disabled={saving} className="bg-orange-500 hover:bg-orange-600">
          <Save className="h-4 w-4 mr-2" /> {saving ? "Saving..." : "Save All"}
        </Button>
      </div>

      <div className="space-y-6">
        {/* Branding */}
        <Section title="Branding">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Store Name</Label>
              <Input value={s.storeName} onChange={(e) => update("storeName", e.target.value)} />
            </div>
            <div>
              <Label>Home Tagline</Label>
              <Input value={s.homeTagline} onChange={(e) => update("homeTagline", e.target.value)} />
            </div>
            <div className="md:col-span-2">
              <Label className="mb-2 block">Logo</Label>
              <div className="flex gap-3 items-start">
                <div className="flex-1">
                  <div className="flex gap-2 mb-2">
                    <input
                      ref={logoFileRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleLogoUpload}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={uploadingLogo}
                      onClick={() => logoFileRef.current?.click()}
                    >
                      <Upload className="h-4 w-4 mr-1.5" />
                      {uploadingLogo ? "Uploading…" : "Upload from Device"}
                    </Button>
                    <span className="text-xs text-gray-400 self-center">or paste a URL below</span>
                  </div>
                  <Input
                    value={s.logoUrl ?? ""}
                    onChange={(e) => update("logoUrl", e.target.value || null)}
                    placeholder="https://yoursite.com/logo.png"
                  />
                </div>
                <div className="flex-shrink-0 border rounded-lg p-2 bg-gray-50 min-w-[64px] min-h-[52px] flex items-center justify-center">
                  {s.logoUrl ? (
                    <img
                      src={s.logoUrl}
                      alt="Logo"
                      className="h-10 w-auto object-contain"
                      onError={(e) => ((e.currentTarget.style.display = "none"))}
                    />
                  ) : (
                    <ImageIcon className="h-8 w-8 text-gray-300" />
                  )}
                </div>
              </div>
            </div>
          </div>
        </Section>

        {/* Theme Colors */}
        <Section title="Theme Colors">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ColorPicker
              label="Primary Color"
              value={s.primaryColor}
              onChange={(v) => update("primaryColor", v)}
              hint="Used for buttons, badges, and highlights"
            />
            <ColorPicker
              label="Secondary / Accent Color"
              value={s.secondaryColor}
              onChange={(v) => update("secondaryColor", v)}
              hint="Used for secondary accents and links"
            />
          </div>
          <div className="mt-4 flex gap-3">
            <div className="flex-1 rounded-lg border p-3 text-sm" style={{ borderColor: s.primaryColor }}>
              <div className="w-full py-2 rounded text-center text-white text-sm font-medium" style={{ backgroundColor: s.primaryColor }}>
                Primary Button
              </div>
            </div>
            <div className="flex-1 rounded-lg border p-3 text-sm" style={{ borderColor: s.secondaryColor }}>
              <div className="w-full py-2 rounded text-center text-white text-sm font-medium" style={{ backgroundColor: s.secondaryColor }}>
                Secondary Button
              </div>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-2">
            <Palette className="h-3 w-3 inline mr-1" />
            Colors apply site-wide after saving. A page refresh may be needed.
          </p>
        </Section>

        {/* Footer */}
        <Section title="Footer Appearance">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
            <ColorPicker
              label="Footer Background"
              value={s.footerBg}
              onChange={(v) => update("footerBg", v)}
              hint="Background color of the footer"
            />
            <ColorPicker
              label="Footer Text Color"
              value={s.footerTextColor}
              onChange={(v) => update("footerTextColor", v)}
              hint="Color of footer body text"
            />
          </div>
          <div>
            <Label>Footer About Text</Label>
            <Textarea
              rows={2}
              value={s.footerText}
              onChange={(e) => update("footerText", e.target.value)}
              placeholder="Short description of your store shown in footer"
            />
          </div>
          {/* Live preview */}
          <div
            className="mt-4 rounded-xl p-4 text-xs"
            style={{ backgroundColor: s.footerBg, color: s.footerTextColor }}
          >
            <div className="font-semibold mb-1" style={{ color: "#fff" }}>{s.storeName}</div>
            <div>{s.footerText}</div>
            <div className="mt-2 pt-2 text-center opacity-60" style={{ borderTop: `1px solid rgba(255,255,255,0.1)` }}>
              © {new Date().getFullYear()} {s.storeName}. All rights reserved.
            </div>
          </div>
        </Section>

        {/* Contact */}
        <Section title="Contact & Support">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>WhatsApp Number (with country code, no +)</Label>
              <Input value={s.whatsappNumber} onChange={(e) => update("whatsappNumber", e.target.value)} placeholder="919876543210" />
            </div>
            <div>
              <Label>WhatsApp Auto-Message</Label>
              <Input value={s.whatsappMessage} onChange={(e) => update("whatsappMessage", e.target.value)} />
            </div>
            <div>
              <Label>Support Email</Label>
              <Input value={s.supportEmail} onChange={(e) => update("supportEmail", e.target.value)} />
            </div>
            <div>
              <Label>Support Phone</Label>
              <Input value={s.supportPhone} onChange={(e) => update("supportPhone", e.target.value)} />
            </div>
            <div className="md:col-span-2">
              <Label>Store Address</Label>
              <Input value={s.storeAddress} onChange={(e) => update("storeAddress", e.target.value)} />
            </div>
          </div>
        </Section>

        {/* Pricing */}
        <Section title="Delivery Pricing">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Free Delivery Threshold (Rs.)</Label>
              <Input type="number" value={s.freeDeliveryThreshold} onChange={(e) => update("freeDeliveryThreshold", e.target.value)} />
            </div>
            <div>
              <Label>Delivery Fee (Rs.)</Label>
              <Input type="number" value={s.deliveryFee} onChange={(e) => update("deliveryFee", e.target.value)} />
            </div>
          </div>
        </Section>

        {/* Offer Bar */}
        <Section title="Offer Bar (scrolling text at top)">
          <div className="space-y-2">
            {s.offerBarTexts.map((offer, i) => (
              <div key={i} className="flex gap-2">
                <Input value={offer} onChange={(e) => updateOffer(i, e.target.value)} />
                <button onClick={() => removeOffer(i)} className="px-2 text-red-600 hover:bg-red-50 rounded">
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={addOffer}>
              <Plus className="h-4 w-4 mr-1" /> Add Offer
            </Button>
          </div>
        </Section>
      </div>

      <div className="mt-6 flex justify-end">
        <Button onClick={handleSave} disabled={saving} className="bg-orange-500 hover:bg-orange-600">
          <Save className="h-4 w-4 mr-2" /> {saving ? "Saving..." : "Save All Settings"}
        </Button>
      </div>
    </AdminLayout>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h2 className="font-semibold text-gray-900 mb-4">{title}</h2>
      {children}
    </div>
  );
}
