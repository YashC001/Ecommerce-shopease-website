import { useEffect, useState } from "react";
import { Mail, KeyRound, Save, Shield } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface Me {
  id: number;
  name: string;
  email: string;
  role: string;
}

const apiUrl = (path: string) => `${import.meta.env.BASE_URL}api${path}`;

async function authFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem("auth_token");
  const res = await fetch(apiUrl(path), {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
    credentials: "include",
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? "Request failed");
  return data as T;
}

export default function AdminAccount() {
  const { toast } = useToast();
  const [me, setMe] = useState<Me | null>(null);
  const [emailForm, setEmailForm] = useState({ email: "", currentPassword: "" });
  const [pwdForm, setPwdForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [savingEmail, setSavingEmail] = useState(false);
  const [savingPwd, setSavingPwd] = useState(false);

  useEffect(() => {
    authFetch<Me>("/auth/me")
      .then((u) => {
        setMe(u);
        setEmailForm((f) => ({ ...f, email: u.email }));
      })
      .catch(() => {});
  }, []);

  const handleSaveEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailForm.email || !emailForm.currentPassword) {
      toast({ title: "Enter new email and current password", variant: "destructive" });
      return;
    }
    setSavingEmail(true);
    try {
      await authFetch("/auth/email", {
        method: "PUT",
        body: JSON.stringify(emailForm),
      });
      toast({ title: "Email updated successfully" });
      setEmailForm((f) => ({ ...f, currentPassword: "" }));
      const updated = await authFetch<Me>("/auth/me");
      setMe(updated);
    } catch (err) {
      toast({ title: "Error", description: (err as Error).message, variant: "destructive" });
    } finally {
      setSavingEmail(false);
    }
  };

  const handleSavePwd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwdForm.newPassword.length < 6) {
      toast({ title: "New password must be at least 6 characters", variant: "destructive" });
      return;
    }
    if (pwdForm.newPassword !== pwdForm.confirm) {
      toast({ title: "Passwords do not match", variant: "destructive" });
      return;
    }
    setSavingPwd(true);
    try {
      await authFetch("/auth/change-password", {
        method: "POST",
        body: JSON.stringify({
          currentPassword: pwdForm.currentPassword,
          newPassword: pwdForm.newPassword,
        }),
      });
      toast({ title: "Password changed successfully" });
      setPwdForm({ currentPassword: "", newPassword: "", confirm: "" });
    } catch (err) {
      toast({ title: "Error", description: (err as Error).message, variant: "destructive" });
    } finally {
      setSavingPwd(false);
    }
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">My Account</h1>
        <p className="text-gray-500 text-sm">Manage your admin email and password</p>
      </div>

      {me && (
        <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-xl p-4 mb-6 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white">
            <Shield className="h-5 w-5" />
          </div>
          <div>
            <div className="font-semibold text-gray-900">{me.name}</div>
            <div className="text-sm text-gray-600">{me.email} · <span className="text-orange-600 font-medium uppercase text-xs">{me.role}</span></div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Email */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-4">
            <Mail className="h-5 w-5 text-orange-500" />
            <h2 className="font-semibold text-gray-900">Change Email</h2>
          </div>
          <form onSubmit={handleSaveEmail} className="space-y-3">
            <div>
              <Label>New Email Address</Label>
              <Input
                type="email"
                value={emailForm.email}
                onChange={(e) => setEmailForm({ ...emailForm, email: e.target.value })}
                required
                data-testid="input-account-email"
              />
            </div>
            <div>
              <Label>Current Password (to confirm)</Label>
              <Input
                type="password"
                value={emailForm.currentPassword}
                onChange={(e) => setEmailForm({ ...emailForm, currentPassword: e.target.value })}
                required
                data-testid="input-email-current-password"
              />
            </div>
            <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600" disabled={savingEmail} data-testid="button-save-email">
              <Save className="h-4 w-4 mr-2" />
              {savingEmail ? "Saving..." : "Update Email"}
            </Button>
          </form>
        </div>

        {/* Password */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-4">
            <KeyRound className="h-5 w-5 text-orange-500" />
            <h2 className="font-semibold text-gray-900">Reset Password</h2>
          </div>
          <form onSubmit={handleSavePwd} className="space-y-3">
            <div>
              <Label>Current Password</Label>
              <Input
                type="password"
                value={pwdForm.currentPassword}
                onChange={(e) => setPwdForm({ ...pwdForm, currentPassword: e.target.value })}
                required
                data-testid="input-account-current-password"
              />
            </div>
            <div>
              <Label>New Password (min 6 chars)</Label>
              <Input
                type="password"
                value={pwdForm.newPassword}
                onChange={(e) => setPwdForm({ ...pwdForm, newPassword: e.target.value })}
                required
                minLength={6}
                data-testid="input-account-new-password"
              />
            </div>
            <div>
              <Label>Confirm New Password</Label>
              <Input
                type="password"
                value={pwdForm.confirm}
                onChange={(e) => setPwdForm({ ...pwdForm, confirm: e.target.value })}
                required
                data-testid="input-account-confirm-password"
              />
            </div>
            <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600" disabled={savingPwd} data-testid="button-save-password">
              <Save className="h-4 w-4 mr-2" />
              {savingPwd ? "Saving..." : "Update Password"}
            </Button>
          </form>
        </div>
      </div>
    </AdminLayout>
  );
}
