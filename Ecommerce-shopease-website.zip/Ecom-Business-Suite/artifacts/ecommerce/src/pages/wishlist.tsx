import { Link, useLocation } from "wouter";
import { Heart, ShoppingBag } from "lucide-react";
import { useGetWishlist, getGetWishlistQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/useAuth";
import { ProductCard } from "@/components/products/ProductCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function WishlistPage() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();

  const { data: wishlist, isLoading } = useGetWishlist({
    query: { enabled: isAuthenticated, queryKey: getGetWishlistQueryKey() }
  });

  if (!isAuthenticated) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12 text-center">
        <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Login to view your wishlist</h2>
        <p className="text-muted-foreground text-sm mb-6">Save items you love</p>
        <Button onClick={() => setLocation("/login")} data-testid="btn-login-for-wishlist">Login / Register</Button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 pb-24 sm:pb-8">
      <h1 className="text-lg font-bold mb-4">My Wishlist ({wishlist?.length || 0} items)</h1>

      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i}>
              <Skeleton className="aspect-square rounded-xl mb-2" />
              <Skeleton className="h-3 w-3/4 mb-1" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </div>
      ) : !wishlist || wishlist.length === 0 ? (
        <div className="text-center py-16">
          <Heart className="w-14 h-14 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-base font-medium mb-1">Your wishlist is empty</h3>
          <p className="text-sm text-muted-foreground mb-4">Save your favourite products here</p>
          <Button onClick={() => setLocation("/products")} data-testid="btn-browse-products">Browse Products</Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {wishlist.map((item) => (
            <ProductCard key={item.id} product={item.product} wishlisted={true} />
          ))}
        </div>
      )}
    </div>
  );
}
