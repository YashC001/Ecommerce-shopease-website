import { useState } from "react";
import { useLocation, Link } from "wouter";
import { ChevronLeft, ChevronRight, Star, ShoppingCart, Zap, Heart, Minus, Plus, Share2, ChevronDown, ChevronUp } from "lucide-react";
import { useGetProduct, useGetProductReviews, useAddToCart, useAddToWishlist, useRemoveFromWishlist, getGetCartQueryKey, getGetWishlistQueryKey, getGetProductQueryKey, getGetProductReviewsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ProductCard } from "@/components/products/ProductCard";

interface Props {
  id: string;
}

export default function ProductDetailPage({ id }: Props) {
  const productId = parseInt(id, 10);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const [imgIndex, setImgIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [wishlisted, setWishlisted] = useState(false);
  const [specsOpen, setSpecsOpen] = useState(false);

  const { data: product, isLoading } = useGetProduct(productId, {
    query: { enabled: !!productId, queryKey: getGetProductQueryKey(productId) }
  });
  const { data: reviews } = useGetProductReviews(productId, {
    query: { enabled: !!productId, queryKey: getGetProductReviewsQueryKey(productId) }
  });

  const addToCart = useAddToCart({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        toast({ title: "Added to cart!", description: product?.name });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      },
    },
  });

  const addToWishlist = useAddToWishlist({
    mutation: {
      onSuccess: () => { setWishlisted(true); queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() }); toast({ title: "Added to wishlist!" }); },
    },
  });

  const removeFromWishlist = useRemoveFromWishlist({
    mutation: {
      onSuccess: () => { setWishlisted(false); queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() }); },
    },
  });

  const handleAddToCart = () => {
    if (!isAuthenticated) { setLocation("/login"); return; }
    addToCart.mutate({ data: { productId, quantity } });
  };

  const handleBuyNow = () => {
    if (!isAuthenticated) { setLocation("/login"); return; }
    addToCart.mutate({ data: { productId, quantity } }, {
      onSuccess: () => setLocation("/cart"),
    });
  };

  const handleWishlist = () => {
    if (!isAuthenticated) { setLocation("/login"); return; }
    if (wishlisted) {
      removeFromWishlist.mutate({ productId: productId });
    } else {
      addToWishlist.mutate({ data: { productId } });
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 pb-28">
        <Skeleton className="h-64 sm:h-80 rounded-xl mb-4" />
        <Skeleton className="h-6 w-3/4 mb-2" />
        <Skeleton className="h-4 w-1/2 mb-4" />
        <Skeleton className="h-10 rounded-lg mb-2" />
        <Skeleton className="h-10 rounded-lg" />
      </div>
    );
  }

  if (!product) return <div className="p-8 text-center">Product not found</div>;

  const images = product.images?.length ? product.images : ["https://placehold.co/600x600?text=No+Image"];
  const specs = product.specifications as Record<string, string> || {};

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-4 py-4 pb-28 sm:pb-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
        <Link href="/" className="hover:text-primary">Home</Link>
        <ChevronRight className="w-3 h-3" />
        <Link href="/products" className="hover:text-primary">Products</Link>
        <ChevronRight className="w-3 h-3" />
        <span className="text-foreground line-clamp-1">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Image Gallery */}
        <div className="space-y-2">
          <div className="relative aspect-square rounded-xl overflow-hidden bg-gray-50 group">
            <img
              src={images[imgIndex]}
              alt={product.name}
              className="w-full h-full object-cover"
              data-testid="img-product-main"
            />
            {images.length > 1 && (
              <>
                <button
                  onClick={() => setImgIndex(i => (i - 1 + images.length) % images.length)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setImgIndex(i => (i + 1) % images.length)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </>
            )}
            {product.discountPercent && (
              <Badge className="absolute top-3 left-3 bg-red-500 text-white font-bold">
                -{product.discountPercent}%
              </Badge>
            )}
          </div>
          {images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto no-scrollbar">
              {images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setImgIndex(i)}
                  className={`flex-shrink-0 w-14 h-14 rounded-lg overflow-hidden border-2 transition-all ${
                    i === imgIndex ? "border-primary" : "border-border"
                  }`}
                  data-testid={`btn-image-thumb-${i}`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="space-y-3">
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">{product.categoryName}</p>
            <h1 className="text-lg sm:text-xl font-bold text-foreground leading-snug" data-testid="text-product-name">{product.name}</h1>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-green-600 text-white text-xs font-bold px-2 py-0.5 rounded">
              {product.rating.toFixed(1)} <Star className="w-3 h-3 fill-white" />
            </div>
            <span className="text-sm text-muted-foreground">{product.reviewCount} reviews</span>
            <span className={`text-xs font-medium ${product.stock > 0 ? "text-green-600" : "text-red-500"}`}>
              {product.stock > 0 ? "In Stock" : "Out of Stock"}
            </span>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-3">
            <span className="text-2xl sm:text-3xl font-bold text-foreground" data-testid="text-price">
              Rs.{product.price.toLocaleString()}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <>
                <span className="text-base text-muted-foreground line-through">
                  Rs.{product.originalPrice.toLocaleString()}
                </span>
                <span className="text-sm font-semibold text-green-600">
                  {product.discountPercent}% off
                </span>
              </>
            )}
          </div>

          <p className="text-sm text-muted-foreground leading-relaxed">{product.description}</p>

          {/* Quantity */}
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium">Quantity:</span>
            <div className="flex items-center border border-border rounded-lg overflow-hidden">
              <button
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="w-9 h-9 flex items-center justify-center hover:bg-muted transition-colors"
                data-testid="btn-quantity-minus"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="w-10 text-center text-sm font-medium" data-testid="text-quantity">{quantity}</span>
              <button
                onClick={() => setQuantity(q => Math.min(q + 1, product.stock))}
                className="w-9 h-9 flex items-center justify-center hover:bg-muted transition-colors"
                data-testid="btn-quantity-plus"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-2">
            <Button
              className="flex-1 h-11 font-semibold"
              onClick={handleAddToCart}
              disabled={addToCart.isPending || product.stock === 0}
              data-testid="btn-add-to-cart"
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              {addToCart.isPending ? "Adding..." : "Add to Cart"}
            </Button>
            <Button
              variant="outline"
              className="flex-1 h-11 font-semibold border-primary text-primary hover:bg-primary hover:text-primary-foreground"
              onClick={handleBuyNow}
              disabled={product.stock === 0}
              data-testid="btn-buy-now"
            >
              <Zap className="w-4 h-4 mr-2" />
              Buy Now
            </Button>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleWishlist}
              className="h-9 gap-2"
              data-testid="btn-wishlist"
            >
              <Heart className={`w-4 h-4 ${wishlisted ? "fill-red-500 text-red-500" : ""}`} />
              {wishlisted ? "Wishlisted" : "Add to Wishlist"}
            </Button>
          </div>

          {/* Delivery info */}
          <div className="bg-muted/50 rounded-xl p-3 text-xs space-y-1.5">
            <p className="font-medium text-sm">Delivery Information</p>
            <p>Free delivery on orders above Rs.499</p>
            <p>Standard delivery: 5-7 business days</p>
            <p>Easy 7-day returns & exchanges</p>
          </div>

          {/* Specifications */}
          {Object.keys(specs).length > 0 && (
            <div className="border border-border rounded-xl overflow-hidden">
              <button
                onClick={() => setSpecsOpen(!specsOpen)}
                className="w-full flex items-center justify-between p-3 text-sm font-medium hover:bg-muted/50 transition-colors"
                data-testid="btn-toggle-specs"
              >
                Specifications
                {specsOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {specsOpen && (
                <div className="border-t border-border">
                  {Object.entries(specs).map(([key, value]) => (
                    <div key={key} className="flex px-3 py-2 text-xs border-b border-border last:border-0">
                      <span className="w-1/3 text-muted-foreground font-medium">{key}</span>
                      <span className="w-2/3 text-foreground">{value}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Reviews */}
      {reviews && reviews.length > 0 && (
        <div className="mt-8">
          <h2 className="text-base font-bold mb-4">Customer Reviews ({reviews.length})</h2>
          <div className="space-y-3">
            {reviews.slice(0, 5).map((review) => (
              <div key={review.id} className="bg-white border border-border rounded-xl p-4" data-testid={`review-${review.id}`}>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-7 h-7 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center">
                    {review.userName?.charAt(0)?.toUpperCase()}
                  </div>
                  <span className="text-sm font-medium">{review.userName}</span>
                  <div className="flex ml-auto">
                    {[1,2,3,4,5].map(s => (
                      <Star key={s} className={`w-3 h-3 ${s <= review.rating ? "star-filled" : "star-empty"}`} />
                    ))}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">{review.comment}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Related Products */}
      {(product as any).relatedProducts?.length > 0 && (
        <div className="mt-8">
          <h2 className="text-base font-bold mb-4">Related Products</h2>
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
            {(product as any).relatedProducts.map((p: any) => (
              <div key={p.id} className="flex-shrink-0 w-40 sm:w-44">
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sticky mobile actions */}
      <div className="fixed bottom-16 sm:bottom-0 left-0 right-0 sm:hidden z-30 bg-white border-t border-border px-4 py-3 flex gap-2 shadow-lg">
        <Button
          variant="outline"
          className="flex-1 h-11 border-primary text-primary"
          onClick={handleAddToCart}
          disabled={addToCart.isPending || product.stock === 0}
          data-testid="btn-add-cart-mobile"
        >
          <ShoppingCart className="w-4 h-4 mr-1.5" /> Add to Cart
        </Button>
        <Button
          className="flex-1 h-11 font-semibold"
          onClick={handleBuyNow}
          disabled={product.stock === 0}
          data-testid="btn-buy-now-mobile"
        >
          <Zap className="w-4 h-4 mr-1.5" /> Buy Now
        </Button>
      </div>
    </div>
  );
}
