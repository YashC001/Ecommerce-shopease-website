import { useState } from "react";
import { Link, useLocation } from "wouter";
import { User, Package, Heart, MapPin, LogOut, ChevronRight, Edit2, Save, X, Phone, Mail, Shield, KeyRound } from "lucide-react";
import { useUpdateProfile, useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function ProfilePage() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated, logout, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "" });
  const [pwdOpen, setPwdOpen] = useState(false);
  const [pwdForm, setPwdForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [pwdSaving, setPwdSaving] = useState(false);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwdForm.newPassword.length < 6) {
      toast({ title: "New password must be at least 6 characters", variant: "destructive" });
      return;
    }
    if (pwdForm.newPassword !== pwdForm.confirm) {
      toast({ title: "Passwords do not match", variant: "destructive" });
      return;
    }
    setPwdSaving(true);
    try {
      const res = await fetch(`${import.meta.env.BASE_URL}api/auth/change-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          currentPassword: pwdForm.currentPassword,
          newPassword: pwdForm.newPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to change password");
      toast({ title: "Password changed successfully" });
      setPwdOpen(false);
      setPwdForm({ currentPassword: "", newPassword: "", confirm: "" });
    } catch (err) {
      toast({ title: "Error", description: (err as Error).message, variant: "destructive" });
    } finally {
      setPwdSaving(false);
    }
  };

  const updateProfile = useUpdateProfile({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        toast({ title: "Profile updated!" });
        setEditing(false);
      },
      onError: (err: any) => {
        toast({ title: "Failed to update", description: err.message, variant: "destructive" });
      },
    },
  });

  if (isLoading) {
    return <div className="p-8 text-center text-muted-foreground">Loading...</div>;
  }

  if (!isAuthenticated || !user) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12 text-center">
        <User className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Welcome to ShopEase</h2>
        <p className="text-muted-foreground text-sm mb-6">Login or create an account to get started</p>
        <div className="flex gap-3 justify-center">
          <Button onClick={() => setLocation("/login")} data-testid="btn-login">Login</Button>
          <Button variant="outline" onClick={() => setLocation("/register")} data-testid="btn-register">Register</Button>
        </div>
      </div>
    );
  }

  const startEdit = () => {
    setForm({ name: user.name || "", phone: user.phone || "" });
    setEditing(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile.mutate({ data: form });
  };

  const isAdmin = (user as { role?: string }).role === "admin";

  const menuItems = [
    { href: "/orders", icon: Package, label: "My Orders", desc: "Track and view your orders" },
    { href: "/wishlist", icon: Heart, label: "Wishlist", desc: "Your saved items" },
    { href: "/checkout", icon: MapPin, label: "Saved Addresses", desc: "Manage delivery addresses" },
    ...(isAdmin ? [{ href: "/admin", icon: Shield, label: "Admin Panel", desc: "Manage your store" }] : []),
  ];

  return (
    <div className="max-w-lg mx-auto px-3 sm:px-4 py-4 pb-24 sm:pb-8">
      <h1 className="text-lg font-bold mb-4">My Profile</h1>

      {/* Profile Card */}
      <div className="bg-white rounded-xl border border-border p-4 mb-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-full bg-primary/10 text-primary font-bold text-xl flex items-center justify-center" data-testid="avatar">
            {user.name?.charAt(0)?.toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-bold text-base" data-testid="user-name">{user.name}</h2>
            <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
              <Mail className="w-3 h-3" />
              <span className="truncate" data-testid="user-email">{user.email}</span>
            </div>
            {user.phone && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                <Phone className="w-3 h-3" />
                <span data-testid="user-phone">{user.phone}</span>
              </div>
            )}
          </div>
          <button onClick={startEdit} className="p-2 rounded-lg hover:bg-muted transition-colors" data-testid="btn-edit-profile">
            <Edit2 className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {editing && (
          <form onSubmit={handleSave} className="space-y-3 border-t pt-4">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Full Name</label>
              <Input
                value={form.name}
                onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))}
                className="h-9 text-sm mt-1"
                required
                data-testid="input-edit-name"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Phone Number</label>
              <Input
                value={form.phone}
                onChange={(e) => setForm(f => ({ ...f, phone: e.target.value }))}
                className="h-9 text-sm mt-1"
                placeholder="+91 99999 99999"
                data-testid="input-edit-phone"
              />
            </div>
            <div className="flex gap-2">
              <Button type="submit" size="sm" disabled={updateProfile.isPending} data-testid="btn-save-profile">
                <Save className="w-3.5 h-3.5 mr-1.5" />
                {updateProfile.isPending ? "Saving..." : "Save"}
              </Button>
              <Button type="button" size="sm" variant="outline" onClick={() => setEditing(false)} data-testid="btn-cancel-edit">
                <X className="w-3.5 h-3.5 mr-1.5" /> Cancel
              </Button>
            </div>
          </form>
        )}
      </div>

      {/* Menu */}
      <div className="bg-white rounded-xl border border-border overflow-hidden mb-4">
        {menuItems.map(({ href, icon: Icon, label, desc }, i) => (
          <Link
            key={href}
            href={href}
            className={`flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors ${i !== menuItems.length - 1 ? "border-b border-border" : ""}`}
            data-testid={`menu-${label.toLowerCase().replace(/\s/g, "-")}`}
          >
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Icon className="w-4 h-4 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">{label}</p>
              <p className="text-xs text-muted-foreground">{desc}</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </Link>
        ))}
      </div>

      {/* Change Password */}
      <button
        onClick={() => setPwdOpen(true)}
        className="w-full flex items-center gap-3 p-4 rounded-xl bg-white border border-border text-sm font-medium hover:bg-muted/50 transition-colors mb-3"
        data-testid="btn-open-change-password"
      >
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <KeyRound className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 text-left">
          <p className="text-sm font-medium">Change Password</p>
          <p className="text-xs text-muted-foreground">Update your account password</p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground" />
      </button>

      {pwdOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setPwdOpen(false)}>
          <div className="bg-white rounded-xl max-w-sm w-full p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base">Change Password</h3>
              <button onClick={() => setPwdOpen(false)} className="p-1 hover:bg-muted rounded">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleChangePassword} className="space-y-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground">Current Password</label>
                <Input
                  type="password"
                  value={pwdForm.currentPassword}
                  onChange={(e) => setPwdForm({ ...pwdForm, currentPassword: e.target.value })}
                  required
                  data-testid="input-current-password"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">New Password</label>
                <Input
                  type="password"
                  value={pwdForm.newPassword}
                  onChange={(e) => setPwdForm({ ...pwdForm, newPassword: e.target.value })}
                  required
                  minLength={6}
                  data-testid="input-new-password"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">Confirm New Password</label>
                <Input
                  type="password"
                  value={pwdForm.confirm}
                  onChange={(e) => setPwdForm({ ...pwdForm, confirm: e.target.value })}
                  required
                  data-testid="input-confirm-password"
                />
              </div>
              <Button type="submit" className="w-full" disabled={pwdSaving} data-testid="btn-submit-change-password">
                {pwdSaving ? "Saving..." : "Update Password"}
              </Button>
            </form>
          </div>
        </div>
      )}

      {/* Logout */}
      <button
        onClick={() => { logout(); setLocation("/"); }}
        className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-red-50 text-red-600 text-sm font-medium hover:bg-red-100 transition-colors"
        data-testid="btn-logout"
      >
        <LogOut className="w-4 h-4" /> Logout
      </button>
    </div>
  );
}
