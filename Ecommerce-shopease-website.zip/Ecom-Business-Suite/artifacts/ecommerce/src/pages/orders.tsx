import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Package, ChevronRight, Download, Eye } from "lucide-react";
import { useGetOrders, useGetOrderBill, getGetOrdersQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700",
  confirmed: "bg-blue-100 text-blue-700",
  processing: "bg-purple-100 text-purple-700",
  shipped: "bg-indigo-100 text-indigo-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

export default function OrdersPage() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const { data: orders, isLoading } = useGetOrders({
    query: { enabled: isAuthenticated, queryKey: getGetOrdersQueryKey() }
  });

  if (!isAuthenticated) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12 text-center">
        <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Login to view your orders</h2>
        <p className="text-muted-foreground text-sm mb-6">Track all your orders in one place</p>
        <Button onClick={() => setLocation("/login")} data-testid="btn-login-for-orders">Login / Register</Button>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4">
        {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl mb-3" />)}
      </div>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12 text-center pb-24">
        <Package className="w-14 h-14 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-base font-medium mb-1">No orders yet</h3>
        <p className="text-sm text-muted-foreground mb-4">Start shopping to see your orders here</p>
        <Button onClick={() => setLocation("/products")} data-testid="btn-start-shopping">Start Shopping</Button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-3 sm:px-4 py-4 pb-24 sm:pb-8">
      <h1 className="text-lg font-bold mb-4">My Orders ({orders.length})</h1>

      <div className="space-y-3">
        {orders.map((order) => (
          <div key={order.id} className="bg-white rounded-xl border border-border overflow-hidden" data-testid={`order-${order.id}`}>
            {/* Order header */}
            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="text-xs text-muted-foreground">Order ID</p>
                  <p className="font-semibold text-sm" data-testid={`order-number-${order.id}`}>{order.orderNumber}</p>
                </div>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${STATUS_COLORS[order.status] || "bg-gray-100 text-gray-700"}`}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </span>
              </div>

              <div className="flex gap-2 overflow-x-auto no-scrollbar mb-2">
                {order.items.slice(0, 3).map((item: any) => (
                  <img
                    key={item.id}
                    src={item.productImage || "https://placehold.co/48x48"}
                    alt=""
                    className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                  />
                ))}
                {order.items.length > 3 && (
                  <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center text-xs font-medium flex-shrink-0">
                    +{order.items.length - 3}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>{order.items.length} item{order.items.length !== 1 ? "s" : ""}</span>
                <span>{new Date(order.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span>
                <span className="font-semibold text-foreground" data-testid={`order-total-${order.id}`}>Rs.{order.total.toLocaleString()}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex border-t border-border">
              <Link href={`/order-success?orderId=${order.id}`} className="flex-1">
                <button className="w-full flex items-center justify-center gap-1.5 py-2.5 text-xs font-medium text-primary hover:bg-primary/5 transition-colors" data-testid={`btn-view-order-${order.id}`}>
                  <Eye className="w-3.5 h-3.5" /> View Details
                </button>
              </Link>
              <div className="w-px bg-border" />
              <button
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-medium text-muted-foreground hover:bg-muted/50 transition-colors"
                onClick={() => setExpandedId(expandedId === order.id ? null : order.id)}
                data-testid={`btn-track-${order.id}`}
              >
                <Package className="w-3.5 h-3.5" /> Track Order
              </button>
            </div>

            {/* Expanded tracking */}
            {expandedId === order.id && (
              <div className="border-t border-border p-4">
                <div className="space-y-3">
                  {[
                    { label: "Order Placed", done: true, date: order.createdAt },
                    { label: "Order Confirmed", done: ["confirmed", "processing", "shipped", "delivered"].includes(order.status) },
                    { label: "Processing", done: ["processing", "shipped", "delivered"].includes(order.status) },
                    { label: "Shipped", done: ["shipped", "delivered"].includes(order.status) },
                    { label: "Delivered", done: order.status === "delivered", date: order.estimatedDelivery },
                  ].map((step, i) => (
                    <div key={i} className="flex items-center gap-3 text-xs">
                      <div className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center ${step.done ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                        {step.done ? "✓" : i + 1}
                      </div>
                      <div className="flex-1">
                        <span className={step.done ? "font-medium text-foreground" : "text-muted-foreground"}>{step.label}</span>
                        {step.date && <span className="ml-2 text-[10px] text-muted-foreground">{new Date(step.date).toLocaleDateString("en-IN")}</span>}
                      </div>
                    </div>
                  ))}
                </div>
                {order.estimatedDelivery && (
                  <p className="text-xs text-green-600 mt-3 font-medium">
                    Expected by: {new Date(order.estimatedDelivery).toLocaleDateString("en-IN", { weekday: "long", month: "long", day: "numeric" })}
                  </p>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
