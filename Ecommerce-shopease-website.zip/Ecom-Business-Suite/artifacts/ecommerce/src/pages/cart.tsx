import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Trash2, Minus, Plus, ShoppingBag, Tag, ArrowRight } from "lucide-react";
import { useGetCart, useUpdateCartItem, useRemoveFromCart, useClearCart, useValidateCoupon, getGetCartQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

export default function CartPage() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number } | null>(null);

  const { data: cart, isLoading } = useGetCart({
    query: { enabled: isAuthenticated, queryKey: getGetCartQueryKey() }
  });

  const updateItem = useUpdateCartItem({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }),
    },
  });

  const removeItem = useRemoveFromCart({
    mutation: {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }); toast({ title: "Item removed" }); },
    },
  });

  const clearCart = useClearCart({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }),
    },
  });

  const validateCoupon = useValidateCoupon({
    mutation: {
      onSuccess: (data: any) => {
        if (data.valid) {
          setAppliedCoupon({ code: couponCode.toUpperCase(), discount: data.discount });
          toast({ title: "Coupon applied!", description: data.message });
        } else {
          toast({ title: "Invalid coupon", description: data.message, variant: "destructive" });
        }
      },
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12 text-center">
        <ShoppingBag className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Login to view your cart</h2>
        <p className="text-muted-foreground text-sm mb-6">Your cart is waiting for you</p>
        <Button onClick={() => setLocation("/login")} data-testid="btn-login-for-cart">Login / Register</Button>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-3 sm:px-4 py-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-xl mb-3" />
        ))}
      </div>
    );
  }

  if (!cart || cart.items.length === 0) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12 text-center pb-24">
        <ShoppingBag className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Your cart is empty</h2>
        <p className="text-muted-foreground text-sm mb-6">Add items to get started</p>
        <Button onClick={() => setLocation("/products")} data-testid="btn-continue-shopping">Continue Shopping</Button>
      </div>
    );
  }

  const couponDiscount = appliedCoupon?.discount || 0;
  const finalTotal = (cart.total - couponDiscount).toFixed(2);

  const handleApplyCoupon = () => {
    if (!couponCode.trim()) return;
    validateCoupon.mutate({ data: { code: couponCode.toUpperCase(), cartTotal: cart.subtotal } });
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-4 py-4 pb-28 sm:pb-8">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-lg font-bold">My Cart ({cart.itemCount} items)</h1>
        <button
          onClick={() => clearCart.mutate({})}
          className="text-xs text-muted-foreground hover:text-destructive transition-colors"
          data-testid="btn-clear-cart"
        >
          Clear All
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-3">
          {cart.items.map((item) => (
            <div key={item.id} className="bg-white rounded-xl border border-border p-3 flex gap-3" data-testid={`cart-item-${item.id}`}>
              <Link href={`/products/${item.productId}`}>
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden bg-gray-50 flex-shrink-0">
                  <img
                    src={item.product.images?.[0] || "https://placehold.co/100x100"}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </Link>
              <div className="flex-1 min-w-0">
                <Link href={`/products/${item.productId}`}>
                  <p className="text-sm font-medium line-clamp-2 hover:text-primary transition-colors" data-testid={`cart-item-name-${item.id}`}>
                    {item.product.name}
                  </p>
                </Link>
                <p className="text-xs text-muted-foreground mt-0.5">{item.product.categoryName}</p>
                <p className="text-base font-bold mt-1" data-testid={`cart-item-price-${item.id}`}>
                  Rs.{item.price.toLocaleString()}
                </p>
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center border border-border rounded-lg overflow-hidden">
                    <button
                      onClick={() => updateItem.mutate({ id: item.id, data: { quantity: item.quantity - 1 } })}
                      disabled={updateItem.isPending}
                      className="w-8 h-7 flex items-center justify-center hover:bg-muted transition-colors"
                      data-testid={`btn-decrease-${item.id}`}
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-8 text-center text-sm font-medium" data-testid={`cart-item-qty-${item.id}`}>{item.quantity}</span>
                    <button
                      onClick={() => updateItem.mutate({ id: item.id, data: { quantity: item.quantity + 1 } })}
                      disabled={updateItem.isPending}
                      className="w-8 h-7 flex items-center justify-center hover:bg-muted transition-colors"
                      data-testid={`btn-increase-${item.id}`}
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                  <button
                    onClick={() => removeItem.mutate({ id: item.id })}
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    data-testid={`btn-remove-${item.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="space-y-3">
          {/* Coupon */}
          <div className="bg-white rounded-xl border border-border p-4">
            <h3 className="text-sm font-semibold mb-2 flex items-center gap-1.5"><Tag className="w-4 h-4" /> Apply Coupon</h3>
            {appliedCoupon ? (
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold bg-green-100 text-green-700 px-2 py-0.5 rounded">{appliedCoupon.code}</span>
                  <p className="text-xs text-green-600 mt-0.5">You saved Rs.{appliedCoupon.discount.toFixed(2)}</p>
                </div>
                <button onClick={() => setAppliedCoupon(null)} className="text-xs text-destructive">Remove</button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Input
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="Enter coupon code"
                  className="h-8 text-xs"
                  data-testid="input-coupon-code"
                />
                <Button size="sm" variant="outline" className="h-8 text-xs" onClick={handleApplyCoupon} disabled={validateCoupon.isPending} data-testid="btn-apply-coupon">
                  Apply
                </Button>
              </div>
            )}
            <p className="text-[10px] text-muted-foreground mt-2">Try: WELCOME10, FLAT50, SAVE20</p>
          </div>

          {/* Summary */}
          <div className="bg-white rounded-xl border border-border p-4 space-y-2">
            <h3 className="text-sm font-semibold mb-3">Order Summary</h3>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal ({cart.itemCount} items)</span>
              <span>Rs.{cart.subtotal.toLocaleString()}</span>
            </div>
            {cart.discount > 0 && (
              <div className="flex justify-between text-sm text-green-600">
                <span>Product Discount</span>
                <span>-Rs.{cart.discount.toFixed(2)}</span>
              </div>
            )}
            {couponDiscount > 0 && (
              <div className="flex justify-between text-sm text-green-600">
                <span>Coupon ({appliedCoupon?.code})</span>
                <span>-Rs.{couponDiscount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Delivery Fee</span>
              <span className={cart.deliveryFee === 0 ? "text-green-600 font-medium" : ""}>
                {cart.deliveryFee === 0 ? "FREE" : `Rs.${cart.deliveryFee}`}
              </span>
            </div>
            <div className="border-t border-border pt-2 flex justify-between font-bold text-base">
              <span>Total</span>
              <span data-testid="cart-total">Rs.{parseFloat(finalTotal).toLocaleString()}</span>
            </div>
            {cart.deliveryFee > 0 && (
              <p className="text-[10px] text-muted-foreground">Add Rs.{(499 - cart.subtotal).toFixed(0)} more for free delivery</p>
            )}
          </div>

          <Button
            className="w-full h-12 font-semibold text-base"
            onClick={() => setLocation("/checkout")}
            data-testid="btn-proceed-checkout"
          >
            Proceed to Checkout <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}
